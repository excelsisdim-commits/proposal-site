import { useEffect, useState } from 'react'
import { signedUrl } from '../lib/upload'
import { IClose } from './Icons'

export default function Attachment({ path }: { path: string }) {
  const [url, setUrl] = useState<string | null>(null)
  const [failed, setFailed] = useState(false)
  const [open, setOpen] = useState(false)
  useEffect(() => { let a = true; signedUrl(path).then((u) => { if (a) (u ? setUrl(u) : setFailed(true)) }); return () => { a = false } }, [path])
  if (failed) return <div className="grid h-32 w-32 place-items-center rounded-2xl bg-sand text-[13px] text-brown">Photo unavailable</div>
  if (!url) return <div className="h-32 w-32 animate-pulse rounded-2xl bg-sand" aria-label="Loading photo" />
  return (
    <>
      <button type="button" onClick={() => setOpen(true)} className="block overflow-hidden rounded-2xl" aria-label="Open photo">
        <img src={url} alt="Photo shared in the chat" loading="lazy" className="h-36 w-36 object-cover sm:h-44 sm:w-44" />
      </button>
      {open && (
        <div role="dialog" aria-modal="true" aria-label="Photo" className="fixed inset-0 z-[60] grid place-items-center bg-black/85 p-3" onClick={() => setOpen(false)}>
          <button className="absolute right-3 top-3 grid h-12 w-12 place-items-center rounded-full bg-white/15 text-white" aria-label="Close photo" style={{ top: 'calc(var(--safe-t) + 12px)' }}><IClose /></button>
          <img src={url} alt="Photo shared in the chat" className="max-h-full max-w-full rounded-xl object-contain" />
        </div>
      )}
    </>
  )
}
