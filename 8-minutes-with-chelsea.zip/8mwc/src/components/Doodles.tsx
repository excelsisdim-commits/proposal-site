export const Star = ({ className = '', size = 22 }: { className?: string; size?: number }) => (
  <svg aria-hidden className={className} width={size} height={size} viewBox="0 0 24 24" fill="currentColor"><path d="M12 1.5l2.2 6.3 6.3 2.2-6.3 2.2L12 18.5l-2.2-6.3L3.5 10l6.3-2.2z" /></svg>
)
export const Cloud = ({ className = '' }: { className?: string }) => (
  <svg aria-hidden className={className} width="64" height="40" viewBox="0 0 64 40" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M16 33a9 9 0 010-18 12 12 0 0122-3 10 10 0 0111 10 8 8 0 01-3 11z" /></svg>
)
export const Squiggle = ({ className = '' }: { className?: string }) => (
  <svg aria-hidden className={className} width="90" height="14" viewBox="0 0 90 14" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round"><path d="M3 8c6-8 11 8 17 0s11 8 17 0 11 8 17 0 11 8 17 0 11 8 14 0" /></svg>
)
export const Moon = ({ className = '', size = 28 }: { className?: string; size?: number }) => (
  <svg aria-hidden className={className} width={size} height={size} viewBox="0 0 24 24" fill="currentColor"><path d="M20 14.5A8.5 8.5 0 019.5 4 8.5 8.5 0 1020 14.5z" /></svg>
)
export const Stars = ({ n = 14 }: { n?: number }) => (
  <div aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden">
    {Array.from({ length: n }).map((_, i) => (
      <span key={i} className="absolute animate-twinkle rounded-full bg-butter" style={{
        width: i % 3 === 0 ? 3 : 2, height: i % 3 === 0 ? 3 : 2,
        left: `${(i * 37 + 11) % 100}%`, top: `${(i * 53 + 7) % 60}%`, animationDelay: `${(i % 5) * 0.7}s`,
      }} />
    ))}
  </div>
)
