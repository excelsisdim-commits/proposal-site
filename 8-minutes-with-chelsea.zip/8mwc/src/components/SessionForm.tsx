import { useEffect, useMemo, useRef, useState } from 'react'
import { Link } from 'react-router-dom'
import { ensureSession, supabase } from '../lib/supabase'
import { Service, METHOD_LABEL } from '../lib/services'
import { prepareImage, PreparedImage } from '../lib/image'
import { uploadChatImage } from '../lib/upload'
import { inWorkHours, loadWorkHours, WorkHour, DEFAULT_HOURS } from '../lib/hours'
import { cx, errMessage, todayISO, uuid, fmtWhen } from '../lib/util'
import { useNotificationPermission } from '../hooks/usePwa'
import { ErrorNote } from './Bits'
import type { Method } from '../lib/types'

const PROFILE_KEY = 'chelsea:profile'
const loadProfile = () => { try { return JSON.parse(localStorage.getItem(PROFILE_KEY) || '{}') } catch { return {} } }
const saveProfile = (p: object) => { try { localStorage.setItem(PROFILE_KEY, JSON.stringify(p)) } catch { /* private mode */ } }

type Errors = Partial<Record<'name' | 'email' | 'subtype' | 'when' | 'message' | 'images', string>>

export default function SessionForm({ service, onSent }: { service: Service; onSent?: () => void }) {
  const profile = useMemo(loadProfile, [])
  const [name, setName] = useState<string>(profile.name ?? '')
  const [email, setEmail] = useState<string>(profile.email ?? '')
  const [anon, setAnon] = useState<boolean>(!!profile.anon)
  const [subtype, setSubtype] = useState('')
  const [method, setMethod] = useState<Method>('web')
  const [when, setWhen] = useState<'now' | 'pick'>(service.key === 'midnight' ? 'pick' : 'now')
  const [date, setDate] = useState(todayISO())
  const [time, setTime] = useState('')
  const [message, setMessage] = useState('')
  const [images, setImages] = useState<PreparedImage[]>([])
  const [errors, setErrors] = useState<Errors>({})
  const [busy, setBusy] = useState<string | null>(null)
  const [submitError, setSubmitError] = useState<string | null>(null)
  const [imgNote, setImgNote] = useState<string | null>(null)
  const [done, setDone] = useState<{ id: string; ref: string; uploadFailed: boolean; pickedWhen: string | null } | null>(null)
  const [hours, setHours] = useState<WorkHour[]>(DEFAULT_HOURS)
  const camRef = useRef<HTMLInputElement>(null)
  const galRef = useRef<HTMLInputElement>(null)
  const notif = useNotificationPermission()

  useEffect(() => { loadWorkHours().then(setHours) }, [])
  const call = method !== 'web'
  useEffect(() => { if (call) setWhen('pick') }, [call])

  const preferred = useMemo(() => {
    if (when !== 'pick' || !date || !time) return null
    const d = new Date(`${date}T${time}`)
    return isNaN(+d) ? null : d
  }, [when, date, time])
  const duringWork = preferred ? inWorkHours(preferred, hours) : false

  async function addFiles(files: FileList | null) {
    if (!files) return
    setImgNote(null)
    for (const f of Array.from(files)) {
      if (images.length >= service.maxImages) { setImgNote(`That's the max (${service.maxImages} photos).`); break }
      try { const p = await prepareImage(f); setImages((x) => [...x, p]) } catch (e: any) { setImgNote(e.message) }
    }
  }
  const removeImg = (id: string) => setImages((x) => { const g = x.find((i) => i.id === id); if (g) URL.revokeObjectURL(g.url); return x.filter((i) => i.id !== id) })
  const moveImg = (i: number, d: -1 | 1) => setImages((x) => { const n = [...x]; const j = i + d; if (j < 0 || j >= n.length) return x; [n[i], n[j]] = [n[j], n[i]]; return n })

  function validate(): Errors {
    const e: Errors = {}
    if (!anon && !name.trim()) e.name = 'Tell me what to call you, or switch on mystery bestie mode.'
    if (email.trim() && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email.trim())) e.email = "That email doesn't look right. Check for a typo."
    if (service.subtypes.length && !subtype) e.subtype = 'Pick the one that fits best. You can say more below.'
    if (when === 'pick') {
      if (!date || !time) e.when = 'Choose a date and an exact time, or switch to "Right now".'
      else if (preferred && +preferred < Date.now() - 60_000) e.when = 'That time has already passed. Pick a time in the future.'
    }
    if (message.trim().length < 2 && !images.length) e.message = service.allowImages ? 'Add a message or at least one photo.' : 'Write at least a few words so I know where to start.'
    return e
  }

  async function submit(ev: React.FormEvent) {
    ev.preventDefault()
    setSubmitError(null)
    const e = validate()
    setErrors(e)
    if (Object.keys(e).length) {
      requestAnimationFrame(() => document.querySelector<HTMLElement>('[data-err="true"]')?.scrollIntoView({ block: 'center', behavior: 'smooth' }))
      return
    }
    try {
      setBusy(service.loading)
      await ensureSession()
      const { data, error } = await supabase.rpc('create_request', {
        p_name: anon ? '' : name.trim(), p_email: email.trim() || null, p_anonymous: anon,
        p_type: service.key, p_subtype: subtype || null, p_method: method,
        p_preferred: preferred ? preferred.toISOString() : null, p_message: message.trim(),
      })
      if (error) throw error
      const convId = data.conversation_id as string
      let uploadFailed = false
      if (images.length) {
        try {
          const paths: string[] = []
          for (let i = 0; i < images.length; i++) {
            paths.push(await uploadChatImage(convId, images[i].blob, (pct) => setBusy(`${service.key === 'outfit' ? 'Uploading outfit' : 'Uploading photos'}... ${Math.round((i * 100 + pct) / images.length)}%`)))
          }
          const { error: mErr } = await supabase.from('messages').insert({ conversation_id: convId, sender: 'guest', body: '', attachment_paths: paths, client_id: uuid() })
          if (mErr) throw mErr
          setBusy(service.key === 'outfit' ? 'Outfit uploaded! 👗' : 'Photos uploaded!')
        } catch { uploadFailed = true }
      }
      saveProfile({ name: anon ? profile.name ?? '' : name.trim(), email: email.trim(), anon })
      images.forEach((i) => URL.revokeObjectURL(i.url))
      setDone({ id: convId, ref: data.ref, uploadFailed, pickedWhen: preferred ? fmtWhen(preferred.toISOString()) : null })
      onSent?.()
    } catch (err) {
      setSubmitError(errMessage(err))
    } finally { setBusy(null) }
  }

  if (done) {
    return (
      <div className="card text-center" role="status">
        <div className="text-5xl" aria-hidden>{done.pickedWhen ? '💌' : '🫶🏽'}</div>
        <h2 className="mt-3 text-[26px] leading-tight">{done.pickedWhen ? 'Request sent!' : 'Okayyy, your request is with me. 🫶🏽'}</h2>
        {done.pickedWhen ? (
          <p className="mt-2 text-[17px] leading-relaxed">I've got your preferred time: <b>{done.pickedWhen}</b>.<br />Chelsea will let you know if she can make it.</p>
        ) : (
          <p className="mt-2 text-[17px] leading-relaxed">Our chat is open. You can keep typing there. I'll see it.</p>
        )}
        {done.uploadFailed && <div className="mt-3"><ErrorNote>Your request went through, but the photos didn't upload. You can send them again inside the chat.</ErrorNote></div>}
        <Link to={`/c/${done.id}`} className="btn-primary mt-5 w-full">Open our chat 💬</Link>
        {notif.supported && notif.perm === 'default' && (
          <button onClick={notif.ask} className="btn-ghost btn-sm mt-3 w-full">🔔 Tell me when Chelsea replies</button>
        )}
        <p className="mt-4 text-[13px] opacity-70">Request ID {done.ref}{email.trim() ? ' · A confirmation is on its way to your email.' : ''}</p>
      </div>
    )
  }

  const E = (k: keyof Errors) => errors[k] ? <p role="alert" className="err">{errors[k]}</p> : null
  const bad = (k: keyof Errors) => (errors[k] ? 'true' : undefined)

  return (
    <form onSubmit={submit} noValidate className="space-y-7" aria-busy={!!busy}>
      {/* identity */}
      <section className="space-y-4">
        <button type="button" role="switch" aria-checked={anon} onClick={() => setAnon((a) => !a)}
          className={cx('flex min-h-[56px] w-full items-center justify-between gap-3 rounded-2xl px-4 text-left ring-2 transition', anon ? 'bg-ink text-paper ring-ink' : 'bg-white/70 ring-sand')}>
          <span className="text-[16px] font-semibold">{anon ? 'Mystery bestie mode: ON 🕵🏽‍♀️' : 'Keep me anonymous'}</span>
          <span aria-hidden className={cx('relative h-7 w-12 shrink-0 rounded-full transition', anon ? 'bg-butter' : 'bg-sand')}>
            <span className={cx('absolute top-0.5 h-6 w-6 rounded-full bg-white shadow transition-all', anon ? 'left-[22px]' : 'left-0.5')} />
          </span>
        </button>
        {anon && <p className="-mt-2 text-[14px] opacity-80">I won't see your name or email in our chat. If you add an email, it stays private and is only used to send you updates.</p>}

        {!anon && (
          <div data-err={bad('name')}>
            <label className="label" htmlFor="f-name">What should I call you?</label>
            <input id="f-name" className="field" value={name} onChange={(e) => setName(e.target.value)} autoComplete="given-name" autoCapitalize="words" maxLength={60}
              placeholder="Your name" aria-invalid={!!errors.name} aria-describedby={errors.name ? 'e-name' : undefined} />
            {errors.name && <p id="e-name" role="alert" className="err">{errors.name}</p>}
          </div>
        )}
        <div data-err={bad('email')}>
          <label className="label" htmlFor="f-email">Email <span className="font-normal opacity-70">(optional)</span></label>
          <input id="f-email" className="field" type="email" inputMode="email" autoComplete="email" autoCapitalize="none" spellCheck={false}
            value={email} onChange={(e) => setEmail(e.target.value)} placeholder="your@email.com" aria-invalid={!!errors.email} />
          <p className="mt-1.5 text-[13px] opacity-70">Add it and I can email you when I reply, and you can pick the chat back up from any device.</p>
          {E('email')}
        </div>
      </section>

      {/* what */}
      {service.subtypes.length > 0 && (
        <section data-err={bad('subtype')}>
          <label className="label" htmlFor="f-sub">{service.subtypeLabel}</label>
          <div className="relative">
            <select id="f-sub" className="field appearance-none pr-10" value={subtype} onChange={(e) => setSubtype(e.target.value)} aria-invalid={!!errors.subtype}>
              <option value="">Choose one…</option>
              {service.subtypes.map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
            <span aria-hidden className="pointer-events-none absolute right-4 top-1/2 -translate-y-1/2">▾</span>
          </div>
          {E('subtype')}
        </section>
      )}
      {service.intro && <p className="hand text-[26px]">{service.intro}</p>}

      {/* how */}
      {service.allowCalls && (
        <fieldset>
          <legend className="label">How would you like to connect?</legend>
          <div role="radiogroup" className="grid gap-2">
            {(['web', 'snapchat', 'whatsapp'] as Method[]).map((m) => (
              <button key={m} type="button" role="radio" aria-checked={method === m} onClick={() => setMethod(m)}
                className={cx('flex min-h-[56px] items-center justify-between rounded-2xl px-4 text-left text-[17px] font-semibold ring-2 transition', method === m ? 'bg-ink text-paper ring-ink' : 'bg-white/70 ring-sand')}>
                {METHOD_LABEL[m]}
                <span aria-hidden>{method === m ? '●' : '○'}</span>
              </button>
            ))}
          </div>
          {call && <p className="mt-2 text-[13px] opacity-75">I'll confirm first, then you'll get the {method === 'snapchat' ? 'Snapchat' : 'WhatsApp'} link here. No need to message me anywhere yet.</p>}
        </fieldset>
      )}

      {/* when */}
      <fieldset data-err={bad('when')}>
        <legend className="label">When would you like to talk?</legend>
        <div role="radiogroup" className="grid grid-cols-2 gap-2">
          {([['now', 'Right now'], ['pick', 'Pick a time']] as const).map(([v, l]) => (
            <button key={v} type="button" role="radio" aria-checked={when === v} disabled={v === 'now' && call}
              onClick={() => setWhen(v)}
              className={cx('min-h-[52px] rounded-2xl px-3 text-[16px] font-semibold ring-2 transition disabled:opacity-40', when === v ? 'bg-ink text-paper ring-ink' : 'bg-white/70 ring-sand')}>{l}</button>
          ))}
        </div>
        {when === 'pick' && (
          <div className="mt-3 grid grid-cols-2 gap-3">
            <div>
              <label className="label" htmlFor="f-date">📅 Date</label>
              <input id="f-date" type="date" className="field" min={todayISO()} value={date} onChange={(e) => setDate(e.target.value)} />
            </div>
            <div>
              <label className="label" htmlFor="f-time">🕐 Exact time</label>
              <input id="f-time" type="time" className="field" value={time} onChange={(e) => setTime(e.target.value)} />
            </div>
          </div>
        )}
        {when === 'pick' && <p className="mt-2 text-[13px] opacity-75">You're requesting this time. It's not confirmed until I say yes.</p>}
        {duringWork && (
          <p role="note" className="mt-3 rounded-2xl bg-butter-soft px-4 py-3 text-[14px] font-medium text-brown">
            ⚠️ This is during Chelsea's work hours. Text requests are still okay, but calls may take a little longer to confirm.
          </p>
        )}
        {E('when')}
      </fieldset>

      {/* photos */}
      {service.allowImages && (
        <section data-err={bad('images')}>
          <span className="label">{service.key === 'outfit' ? 'Show me the options' : 'Add photos'}</span>
          <input ref={camRef} type="file" accept="image/*" capture="environment" className="hidden" onChange={(e) => { addFiles(e.target.files); e.target.value = '' }} />
          <input ref={galRef} type="file" accept="image/*,.heic,.heif" multiple className="hidden" onChange={(e) => { addFiles(e.target.files); e.target.value = '' }} />
          <div className="grid grid-cols-2 gap-2">
            <button type="button" className="btn-soft" onClick={() => camRef.current?.click()} disabled={images.length >= service.maxImages}>📷 Take photo</button>
            <button type="button" className="btn-soft" onClick={() => galRef.current?.click()} disabled={images.length >= service.maxImages}>🖼️ From gallery</button>
          </div>
          {images.length > 0 && (
            <ul className="mt-3 grid grid-cols-3 gap-2">
              {images.map((im, i) => (
                <li key={im.id} className="relative overflow-hidden rounded-2xl bg-white ring-1 ring-brown/10">
                  <img src={im.url} alt={`Option ${String.fromCharCode(65 + i)}`} className="aspect-[3/4] w-full object-cover" />
                  <span className="absolute left-1.5 top-1.5 rounded-full bg-ink px-2 py-0.5 text-[12px] font-bold text-paper">{String.fromCharCode(65 + i)}</span>
                  <button type="button" onClick={() => removeImg(im.id)} aria-label={`Remove option ${String.fromCharCode(65 + i)}`} className="absolute right-1 top-1 grid h-9 w-9 place-items-center rounded-full bg-ink/85 text-paper">✕</button>
                  <div className="flex">
                    <button type="button" disabled={i === 0} onClick={() => moveImg(i, -1)} aria-label="Move earlier" className="min-h-[44px] flex-1 disabled:opacity-25">←</button>
                    <button type="button" disabled={i === images.length - 1} onClick={() => moveImg(i, 1)} aria-label="Move later" className="min-h-[44px] flex-1 disabled:opacity-25">→</button>
                  </div>
                </li>
              ))}
            </ul>
          )}
          {images.length > 0 && images.length < service.maxImages && <button type="button" className="chip mt-2" onClick={() => galRef.current?.click()}>+ Add another</button>}
          {imgNote && <p role="alert" className="err">{imgNote}</p>}
          <p className="mt-2 text-[13px] opacity-70">Photos are shrunk on your phone first and stored privately. Only you and Chelsea can see them.</p>
        </section>
      )}

      {/* message */}
      <section data-err={bad('message')}>
        <label className="label" htmlFor="f-msg">{service.key === 'midnight' ? 'You can tell me anything' : "Tell me what's going on"}</label>
        <textarea id="f-msg" className="field min-h-[160px] resize-y leading-relaxed" value={message} onChange={(e) => setMessage(e.target.value)} maxLength={4000}
          placeholder={service.placeholder} aria-invalid={!!errors.message} />
        {E('message')}
      </section>

      {submitError && <ErrorNote>{submitError}</ErrorNote>}

      <div>
        <button type="submit" className="btn-primary w-full text-[18px]" disabled={!!busy}>
          {busy ?? 'Send Request 💌'}
        </button>
        <p className="mt-3 text-center text-[13px] opacity-70">{busy ? '' : "Okay bestie, I got you."}</p>
      </div>
    </form>
  )
}
