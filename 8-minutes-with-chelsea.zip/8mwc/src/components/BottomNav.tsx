import { NavLink } from 'react-router-dom'
import { cx } from '../lib/util'

export interface NavItem { to: string; label: string; icon: JSX.Element; badge?: number; end?: boolean }

export default function BottomNav({ items, dark }: { items: NavItem[]; dark?: boolean }) {
  return (
    <nav aria-label="Main"
      className={cx(
        'fixed inset-x-0 bottom-0 z-30 border-t px-2 pt-1.5 backdrop-blur-md md:inset-x-auto md:left-1/2 md:top-4 md:bottom-auto md:-translate-x-1/2 md:rounded-full md:border md:px-3 md:py-1.5 md:shadow-soft',
        dark ? 'border-white/10 bg-night/90 text-cream' : 'border-brown/10 bg-paper/92 text-ink'
      )}
      style={{ paddingBottom: 'calc(var(--safe-b) + 6px)' }}>
      <ul className="mx-auto flex max-w-md items-stretch justify-between gap-1 md:max-w-none md:gap-2">
        {items.map((it) => (
          <li key={it.to} className="flex-1 md:flex-none">
            <NavLink to={it.to} end={it.end ?? it.to === '/'}
              className={({ isActive }) => cx(
                'relative flex min-h-[56px] flex-col items-center justify-center gap-0.5 rounded-2xl px-3 text-[12px] font-semibold transition md:min-h-[44px] md:flex-row md:gap-2 md:px-4 md:text-[15px]',
                isActive ? (dark ? 'bg-white/12 text-butter' : 'bg-sage-soft text-ink') : (dark ? 'text-cream/70' : 'text-brown-soft')
              )}>
              {it.icon}
              <span>{it.label}</span>
              {!!it.badge && (
                <span aria-label={`${it.badge} unread`} className="absolute right-3 top-1.5 grid min-h-[18px] min-w-[18px] place-items-center rounded-full bg-brick px-1 text-[11px] font-bold text-white md:static md:ml-1">
                  {it.badge > 9 ? '9+' : it.badge}
                </span>
              )}
            </NavLink>
          </li>
        ))}
      </ul>
    </nav>
  )
}
