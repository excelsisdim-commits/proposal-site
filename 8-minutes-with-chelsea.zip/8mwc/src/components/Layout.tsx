import { Outlet, useLocation } from 'react-router-dom'
import BottomNav from './BottomNav'
import { IHome, IChat, IDecide, IPot, IMore } from './Icons'
import { useUnread } from '../hooks/useUnread'
import { useOnline } from '../hooks/usePwa'

export default function Layout() {
  const { pathname } = useLocation()
  const unread = useUnread()
  const online = useOnline()
  const dark = pathname.startsWith('/midnight') || pathname === '/s/midnight'
  const items = [
    { to: '/', label: 'Home', icon: <IHome /> },
    { to: '/talk', label: 'Talk', icon: <IChat /> },
    { to: '/decide', label: 'Decide', icon: <IDecide /> },
    { to: '/cook', label: 'Cook', icon: <IPot /> },
    { to: '/more', label: 'More', icon: <IMore />, badge: unread },
  ]
  return (
    <div className={dark ? 'night min-h-[100dvh]' : 'min-h-[100dvh]'}>
      {!online && (
        <div role="status" className="sticky top-0 z-40 bg-butter px-4 py-2 text-center text-[14px] font-semibold text-ink safe-pt">
          Looks like the internet wandered off. We'll keep trying.
        </div>
      )}
      <main className="mx-auto w-full max-w-5xl px-4 pb-32 pt-5 md:pb-16 md:pt-24">
        <div key={pathname} className="page-in"><Outlet /></div>
      </main>
      <BottomNav items={items} dark={dark} />
    </div>
  )
}
