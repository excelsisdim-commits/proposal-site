import { useState } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { LINKS, METHOD_LABEL, STATUS_COPY, TYPE_EMOJI, TYPE_LABEL } from '../lib/services'
import { fmtWhen, timeAgo, errMessage } from '../lib/util'
import type { RequestRow, AdminRequest } from '../lib/types'

type Req = RequestRow & Partial<AdminRequest>

export function StatusBadge({ status }: { status: string }) {
  const s = STATUS_COPY[status]
  return <span className={`inline-flex items-center gap-1 rounded-full px-3 py-1 text-[13px] font-semibold ${s.tone}`}><span aria-hidden>{s.icon}</span>{s.label}</span>
}

const toLocalInput = (iso?: string | null) => {
  const d = iso ? new Date(iso) : new Date(Date.now() + 3600_000)
  d.setMinutes(d.getMinutes() - d.getTimezoneOffset())
  return d.toISOString().slice(0, 16)
}

export default function RequestCard({ req, admin, onChange, showChatLink }: { req: Req; admin?: boolean; onChange?: () => void; showChatLink?: boolean }) {
  const [busy, setBusy] = useState(false)
  const [suggesting, setSuggesting] = useState(false)
  const [alt, setAlt] = useState(toLocalInput(req.suggested_at ?? req.preferred_at))
  const [err, setErr] = useState<string | null>(null)

  async function setStatus(patch: Record<string, unknown>) {
    setBusy(true); setErr(null)
    const { error } = await supabase.from('requests').update(patch).eq('id', req.id)
    setBusy(false)
    if (error) return setErr(errMessage(error))
    setSuggesting(false); onChange?.()
  }
  async function accept() {
    setBusy(true); setErr(null)
    const { error } = await supabase.rpc('accept_suggestion', { p_request: req.id })
    setBusy(false)
    if (error) return setErr(errMessage(error))
    onChange?.()
  }

  const call = req.contact_method !== 'web'
  const link = req.contact_method === 'snapchat' ? LINKS.snapchat : LINKS.whatsapp

  return (
    <article className="card !p-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2 text-[16px] font-semibold">
          <span aria-hidden className="text-xl">{TYPE_EMOJI[req.type]}</span>{TYPE_LABEL[req.type] ?? req.type}
        </div>
        <StatusBadge status={req.status} />
      </div>

      <dl className="mt-3 grid grid-cols-[auto,1fr] gap-x-4 gap-y-1.5 text-[15px]">
        {admin && <><dt className="text-brown-soft">ID</dt><dd className="font-mono text-[14px]">{req.ref}</dd></>}
        {admin && <><dt className="text-brown-soft">Name</dt><dd>{req.display_name}{req.is_anonymous && ' 🕵🏽‍♀️'}</dd></>}
        {admin && <><dt className="text-brown-soft">Email</dt><dd className="break-all">{req.is_anonymous ? 'Hidden (anonymous)' : req.email ?? 'Not provided'}</dd></>}
        {req.subtype && <><dt className="text-brown-soft">About</dt><dd>{req.subtype}</dd></>}
        <dt className="text-brown-soft">When</dt><dd>{fmtWhen(req.preferred_at)}</dd>
        <dt className="text-brown-soft">How</dt><dd>{METHOD_LABEL[req.contact_method]}</dd>
        {req.status === 'ALTERNATIVE_TIME' && req.suggested_at && <><dt className="text-brown-soft">New time</dt><dd className="font-semibold">{fmtWhen(req.suggested_at)}</dd></>}
        {admin && <><dt className="text-brown-soft">Sent</dt><dd>{timeAgo(req.created_at)}</dd></>}
      </dl>

      {admin && req.message && <p className="mt-3 line-clamp-4 rounded-2xl bg-cream px-4 py-3 text-[15px]">{req.message}</p>}
      {admin && req.in_work_hours && <p className="mt-2 text-[13px] text-brown-soft">⚠️ Falls in your work hours</p>}

      {/* guest view */}
      {!admin && req.status === 'PENDING' && <p className="mt-3 text-[15px] text-brown">I've got your preferred time. Chelsea will let you know if she can make it.</p>}
      {!admin && req.status === 'CONFIRMED' && (
        <div className="mt-4 rounded-2xl bg-sage-soft p-4 text-center">
          <p className="font-display text-xl">You're all set 🫶🏽</p>
          <p className="mt-1 text-[16px] font-semibold">{fmtWhen(req.preferred_at)}</p>
          {call ? (
            <a href={link} target="_blank" rel="noopener noreferrer" className="btn-primary btn-sm mt-3 w-full">
              {req.contact_method === 'snapchat' ? 'Open Snapchat 👻' : 'Open WhatsApp 💚'}
            </a>
          ) : <p className="mt-1 text-[14px]">We'll talk right here in this chat.</p>}
        </div>
      )}
      {!admin && req.status === 'ALTERNATIVE_TIME' && (
        <div className="mt-4 rounded-2xl bg-dusty-soft p-4">
          <p className="text-[15px]">Chelsea can't make that exact time, but she suggested <b>{fmtWhen(req.suggested_at)}</b>.</p>
          <button disabled={busy} onClick={accept} className="btn-primary btn-sm mt-3 w-full">That works 🫶</button>
          <p className="mt-2 text-[13px] text-brown">Doesn't work? Just tell her in the chat.</p>
        </div>
      )}
      {!admin && req.status === 'DECLINED' && <p className="mt-3 text-[15px] text-brown">Chelsea can't make this one. Feel free to message her or send a new request.</p>}

      {/* admin actions */}
      {admin && (
        <div className="mt-4 space-y-3">
          <div className="flex flex-wrap gap-2">
            {req.status !== 'CONFIRMED' && req.status !== 'COMPLETED' && <button disabled={busy} onClick={() => setStatus({ status: 'CONFIRMED' })} className="btn-primary btn-sm">Confirm</button>}
            {req.status !== 'COMPLETED' && req.status !== 'DECLINED' && <button disabled={busy} onClick={() => setSuggesting((v) => !v)} className="btn-soft btn-sm">Suggest another time</button>}
            {req.status !== 'DECLINED' && req.status !== 'COMPLETED' && <button disabled={busy} onClick={() => confirm('Decline this request?') && setStatus({ status: 'DECLINED' })} className="btn-ghost btn-sm">Decline</button>}
            {req.status === 'CONFIRMED' && <button disabled={busy} onClick={() => setStatus({ status: 'COMPLETED' })} className="btn-soft btn-sm">Mark completed</button>}
            {showChatLink !== false && <Link to={`/chelsea/inbox/${req.conversation_id}`} className="btn-ghost btn-sm">Open chat{req.unread_admin ? ` (${req.unread_admin})` : ''}</Link>}
          </div>
          {suggesting && (
            <div className="rounded-2xl bg-cream p-3">
              <label className="label" htmlFor={`alt-${req.id}`}>Suggest this time</label>
              <input id={`alt-${req.id}`} type="datetime-local" className="field" value={alt} onChange={(e) => setAlt(e.target.value)} />
              <button disabled={busy || !alt} onClick={() => setStatus({ status: 'ALTERNATIVE_TIME', suggested_at: new Date(alt).toISOString() })} className="btn-primary btn-sm mt-3 w-full">Send suggestion</button>
            </div>
          )}
        </div>
      )}
      {err && <p role="alert" className="err">{err}</p>}
    </article>
  )
}
