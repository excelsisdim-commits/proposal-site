import { useCallback, useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'
import type { RequestRow } from '../lib/types'
import RequestCard, { StatusBadge } from './RequestCard'
import { TYPE_LABEL } from '../lib/services'
import { fmtWhen } from '../lib/util'

/** Collapsible strip above a chat showing the request + live status. Updates in real time. */
export default function RequestPanel({ conversationId, admin }: { conversationId: string; admin?: boolean }) {
  const [reqs, setReqs] = useState<RequestRow[]>([])
  const [open, setOpen] = useState(false)

  const load = useCallback(async () => {
    const { data } = await supabase.from('requests').select('*').eq('conversation_id', conversationId).order('created_at', { ascending: false })
    setReqs((data ?? []) as RequestRow[])
  }, [conversationId])

  useEffect(() => {
    load()
    const ch = supabase.channel(`req:${conversationId}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'requests', filter: `conversation_id=eq.${conversationId}` }, load)
      .subscribe()
    return () => { supabase.removeChannel(ch) }
  }, [conversationId, load])

  // open automatically when something needs the guest's attention
  useEffect(() => {
    if (!admin && reqs.some((r) => r.status === 'ALTERNATIVE_TIME' || r.status === 'CONFIRMED')) setOpen(true)
  }, [reqs, admin])

  if (!reqs.length) return null
  const r = reqs[0]
  return (
    <div className="border-b border-brown/10 bg-paper px-3 py-2">
      <button onClick={() => setOpen((o) => !o)} aria-expanded={open} className="flex min-h-[44px] w-full items-center justify-between gap-2 text-left">
        <span className="min-w-0 truncate text-[14px] font-semibold">{TYPE_LABEL[r.type]} · {fmtWhen(r.preferred_at)}</span>
        <span className="flex shrink-0 items-center gap-2"><StatusBadge status={r.status} /><span aria-hidden>{open ? '▴' : '▾'}</span></span>
      </button>
      {open && <div className="max-h-[50vh] overflow-y-auto pb-2">{reqs.map((x) => <RequestCard key={x.id} req={x} admin={admin} onChange={load} showChatLink={false} />)}</div>}
    </div>
  )
}
