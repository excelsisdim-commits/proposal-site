import { ReactNode, useCallback, useEffect, useLayoutEffect, useRef, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useChat } from '../hooks/useChat'
import { useVisualViewportHeight } from '../hooks/usePwa'
import { prepareImage, PreparedImage } from '../lib/image'
import { uploadChatImage } from '../lib/upload'
import { cx, fmtDay, fmtTime } from '../lib/util'
import type { Message, Role } from '../lib/types'
import { IBack, IClose, IPlus, ISend, ITick } from './Icons'
import Attachment from './Attachment'
import { Spinner } from './Bits'

interface Props {
  conversationId: string
  role: Role
  title: string
  status: string | ((peerHere: boolean) => string)   // e.g. "🟢 Chelsea is online"
  backTo?: string | false
  embedded?: boolean        // inside the admin split view
  topSlot?: ReactNode       // request card etc.
  headerRight?: ReactNode
  peerName: string          // "Chelsea" or the guest's display name (for "x is typing...")
}

function Ticks({ m }: { m: Message }) {
  if (m._status === 'sending') return <span className="text-[12px] opacity-70">Sending…</span>
  if (m.read_at) return <span className="inline-flex items-center gap-1 text-dusty-deep" aria-label="Read"><ITick double /><span className="text-[11px] font-semibold">Read</span></span>
  if (m.delivered_at) return <span className="inline-flex items-center text-brown-soft" aria-label="Delivered"><ITick double /></span>
  return <span className="inline-flex items-center text-brown-soft" aria-label="Sent"><ITick /></span>
}

export default function ChatView({ conversationId, role, title, status, backTo = '/c', embedded, topSlot, headerRight, peerName }: Props) {
  useVisualViewportHeight()
  const nav = useNavigate()
  const chat = useChat(conversationId, role)
  const { messages, mySender } = chat
  const scroller = useRef<HTMLDivElement>(null)
  const nearBottom = useRef(true)
  const [newBelow, setNewBelow] = useState(false)
  const [text, setText] = useState('')
  const [pending, setPending] = useState<PreparedImage[]>([])
  const [uploadPct, setUploadPct] = useState<number | null>(null)
  const [attachErr, setAttachErr] = useState<string | null>(null)
  const [backOnline, setBackOnline] = useState(false)
  const prevConn = useRef(chat.connection)
  const taRef = useRef<HTMLTextAreaElement>(null)
  const fileRef = useRef<HTMLInputElement>(null)
  const firstScroll = useRef(true)

  const toBottom = useCallback((smooth = true) => {
    const el = scroller.current
    if (!el) return
    el.scrollTo({ top: el.scrollHeight, behavior: smooth ? 'smooth' : 'auto' })
    setNewBelow(false)
  }, [])

  // auto-scroll: always for my own messages, only when already near the bottom for theirs
  const lastLen = useRef(0)
  useLayoutEffect(() => {
    if (!messages.length) return
    const last = messages[messages.length - 1]
    if (firstScroll.current) { toBottom(false); firstScroll.current = false; lastLen.current = messages.length; return }
    if (messages.length !== lastLen.current) {
      if (last.sender === mySender || nearBottom.current) toBottom()
      else setNewBelow(true)
      lastLen.current = messages.length
    }
  }, [messages, mySender, toBottom])
  useEffect(() => { if (chat.peerTyping && nearBottom.current) toBottom() }, [chat.peerTyping, toBottom])
  useEffect(() => { firstScroll.current = true; lastLen.current = 0 }, [conversationId])

  // keep the latest message visible when the keyboard opens
  useEffect(() => {
    const vv = window.visualViewport
    const h = () => { if (nearBottom.current) toBottom(false) }
    vv?.addEventListener('resize', h)
    return () => vv?.removeEventListener('resize', h)
  }, [toBottom])

  useEffect(() => {
    if (prevConn.current !== 'live' && chat.connection === 'live' && prevConn.current !== 'connecting') {
      setBackOnline(true); const t = setTimeout(() => setBackOnline(false), 2500); return () => clearTimeout(t)
    }
    prevConn.current = chat.connection
  }, [chat.connection])
  useEffect(() => { prevConn.current = chat.connection })

  function onScroll() {
    const el = scroller.current!
    nearBottom.current = el.scrollHeight - el.scrollTop - el.clientHeight < 120
    if (nearBottom.current) setNewBelow(false)
  }

  function autoGrow() {
    const t = taRef.current
    if (!t) return
    t.style.height = 'auto'
    t.style.height = Math.min(t.scrollHeight, 140) + 'px'
  }

  async function onPick(e: React.ChangeEvent<HTMLInputElement>) {
    const files = Array.from(e.target.files ?? [])
    e.target.value = ''
    setAttachErr(null)
    for (const f of files.slice(0, Math.max(0, 6 - pending.length))) {
      try { const p = await prepareImage(f); setPending((x) => [...x, p]) }
      catch (err: any) { setAttachErr(err.message) }
    }
  }
  const removePending = (id: string) => setPending((p) => { const g = p.find((x) => x.id === id); if (g) URL.revokeObjectURL(g.url); return p.filter((x) => x.id !== id) })

  async function submit() {
    if (uploadPct !== null) return
    const body = text
    if (!body.trim() && !pending.length) return
    let paths: string[] = []
    if (pending.length) {
      try {
        setAttachErr(null)
        for (let i = 0; i < pending.length; i++) {
          setUploadPct(0)
          paths.push(await uploadChatImage(conversationId, pending[i].blob, (pct) => setUploadPct(Math.round((i * 100 + pct) / pending.length))))
        }
      } catch {
        setUploadPct(null); setAttachErr("That didn't send 😭 The photo upload failed. Try again.")
        return
      }
      pending.forEach((p) => URL.revokeObjectURL(p.url)); setPending([]); setUploadPct(null)
    }
    setText(''); requestAnimationFrame(autoGrow)
    chat.send(body, paths)
    taRef.current?.focus()
  }

  function onKey(e: React.KeyboardEvent<HTMLTextAreaElement>) {
    // Enter sends on desktop; Shift+Enter = new line. On phones Enter stays a new line (the ➤ button sends).
    const coarse = window.matchMedia('(pointer: coarse)').matches
    if (e.key === 'Enter' && !e.shiftKey && !coarse && !e.nativeEvent.isComposing) { e.preventDefault(); submit() }
  }

  // group by day
  let lastDay = ''
  const connBanner =
    chat.connection === 'offline' ? 'Looks like the internet wandered off.' :
    chat.connection === 'reconnecting' ? 'Reconnecting…' : null

  return (
    <section
      className={cx('flex flex-col bg-cream', embedded ? 'h-full min-h-0 overflow-hidden rounded-[28px] ring-1 ring-brown/10' : 'fixed inset-x-0 top-0 z-40')}
      style={embedded ? undefined : { height: 'var(--vvh)' }} aria-label={`Conversation with ${peerName}`}>
      <header className="flex items-center gap-2 border-b border-brown/10 bg-paper px-2 py-2 safe-pt">
        {backTo !== false && (
          <button onClick={() => nav(backTo)} className="grid h-12 w-12 place-items-center rounded-full active:bg-sand" aria-label="Back"><IBack /></button>
        )}
        <div className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-sage font-display text-lg text-ink" aria-hidden>{peerName.slice(0, 1).toUpperCase()}</div>
        <div className="min-w-0 flex-1">
          <h1 className="truncate font-display text-[18px] leading-tight">{title}</h1>
          <p className="truncate text-[13px] text-brown-soft" aria-live="polite">{typeof status === 'function' ? status(chat.peerHere) : status}</p>
        </div>
        {headerRight}
      </header>

      {(connBanner || backOnline) && (
        <div role="status" className={cx('px-4 py-1.5 text-center text-[13px] font-semibold', backOnline ? 'bg-sage-soft text-sage-deep' : 'bg-butter text-ink')}>
          {backOnline ? '🟢 Back online' : connBanner}
        </div>
      )}

      {topSlot}

      <div ref={scroller} onScroll={onScroll} className="relative min-h-0 flex-1 overflow-y-auto overscroll-contain px-3 py-3" role="log" aria-live="polite" aria-label="Messages">
        {chat.loading ? <Spinner /> : chat.loadError ? (
          <div className="py-10 text-center"><p>{chat.loadError}</p><button className="btn-soft btn-sm mt-3" onClick={() => location.reload()}>Try again</button></div>
        ) : messages.length === 0 ? (
          <div className="grid h-full place-items-center text-center text-brown-soft"><p className="max-w-[16rem]">It's quiet here... send something when you're ready ☁️</p></div>
        ) : (
          <>
            {chat.hasMore && <div className="mb-3 text-center"><button onClick={chat.loadEarlier} className="chip">Load earlier messages</button></div>}
            <ul className="space-y-1.5">
              {messages.map((m) => {
                const mine = m.sender === mySender
                const day = fmtDay(m.created_at)
                const showDay = day !== lastDay; lastDay = day
                return (
                  <li key={m.client_id ?? m.id}>
                    {showDay && <div className="my-3 text-center text-[12px] font-semibold text-brown-soft">{day}</div>}
                    <div className={cx('flex flex-col', mine ? 'items-end' : 'items-start')}>
                      {m.attachment_paths?.length > 0 && (
                        <div className={cx('mb-1 flex max-w-[85%] flex-wrap gap-1.5', mine && 'justify-end')}>
                          {m.attachment_paths.map((p) => <Attachment key={p} path={p} />)}
                        </div>
                      )}
                      {m.body && (
                        <div className={cx('max-w-[82%] px-4 py-2.5 text-[16px] leading-snug sm:max-w-[70%]', mine ? 'bubble-me' : 'bubble-them', m._status === 'failed' && 'opacity-60')}>
                          <p className="msg-text">{m.body}</p>
                        </div>
                      )}
                      <div className="mt-0.5 flex items-center gap-2 px-1 text-[12px] text-brown-soft">
                        <time dateTime={m.created_at}>{fmtTime(m.created_at)}</time>
                        {mine && m._status !== 'failed' && <Ticks m={m} />}
                        {mine && m._status === 'failed' && (
                          <span className="flex items-center gap-2 font-semibold text-brick">That didn't send 😭
                            <button onClick={() => chat.retry(m.client_id!)} className="min-h-[36px] rounded-full bg-brick px-3 text-white">Try again</button>
                          </span>
                        )}
                      </div>
                    </div>
                  </li>
                )
              })}
            </ul>
            {chat.peerTyping && (
              <div className="mt-2 flex items-center gap-2 text-[13px] text-brown-soft" aria-live="polite">
                <span className="bubble-them inline-flex gap-1 px-3 py-2.5" aria-hidden>
                  {[0, 1, 2].map((i) => <span key={i} className="h-1.5 w-1.5 animate-dot rounded-full bg-brown-soft" style={{ animationDelay: `${i * 0.2}s` }} />)}
                </span>
                {peerName} is typing...
              </div>
            )}
          </>
        )}
        {newBelow && (
          <button onClick={() => toBottom()} className="sticky bottom-2 left-1/2 mx-auto mt-2 block -translate-x-0 rounded-full bg-ink px-4 py-2 text-[14px] font-semibold text-paper shadow-soft">New messages ↓</button>
        )}
      </div>

      <div className="border-t border-brown/10 bg-paper px-2 pt-2" style={{ paddingBottom: 'calc(var(--safe-b) + 8px)' }}>
        {pending.length > 0 && (
          <ul className="mb-2 flex gap-2 overflow-x-auto px-1 pb-1">
            {pending.map((p) => (
              <li key={p.id} className="relative shrink-0">
                <img src={p.url} alt="Photo ready to send" className="h-16 w-16 rounded-xl object-cover" />
                <button onClick={() => removePending(p.id)} aria-label="Remove photo" className="absolute -right-1.5 -top-1.5 grid h-7 w-7 place-items-center rounded-full bg-ink text-paper"><IClose /></button>
              </li>
            ))}
          </ul>
        )}
        {uploadPct !== null && <p role="status" className="mb-1 px-2 text-[13px] font-semibold text-brown">Uploading… {uploadPct}%</p>}
        {attachErr && <p role="alert" className="mb-1 px-2 text-[13px] font-semibold text-brick">{attachErr}</p>}
        <div className="flex items-end gap-2">
          <input ref={fileRef} type="file" accept="image/*" multiple className="hidden" onChange={onPick} />
          <button onClick={() => fileRef.current?.click()} aria-label="Add a photo" className="grid h-12 w-12 shrink-0 place-items-center rounded-full bg-sand text-ink active:scale-95"><IPlus /></button>
          <label htmlFor="composer" className="sr-only">Type a message</label>
          <textarea id="composer" ref={taRef} rows={1} value={text} enterKeyHint="enter"
            onChange={(e) => { setText(e.target.value); autoGrow(); if (e.target.value) chat.sendTyping() }}
            onKeyDown={onKey} maxLength={4000} placeholder="Type something..."
            className="max-h-[140px] min-h-[48px] flex-1 resize-none rounded-3xl border-2 border-sand bg-white px-4 py-[11px] text-[16px] leading-snug focus:border-dusty-deep focus:outline-none" />
          <button onClick={submit} disabled={(!text.trim() && !pending.length) || uploadPct !== null} aria-label="Send message"
            className="grid h-12 w-12 shrink-0 place-items-center rounded-full bg-ink text-paper transition active:scale-95 disabled:opacity-35"><ISend /></button>
        </div>
      </div>
    </section>
  )
}
