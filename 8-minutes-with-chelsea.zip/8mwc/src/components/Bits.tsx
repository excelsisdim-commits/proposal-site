import { Link } from 'react-router-dom'
import { ReactNode } from 'react'
import { DISCLAIMER } from '../lib/services'
import { IBack } from './Icons'

export const Disclaimer = ({ className = '' }: { className?: string }) => (
  <p className={`text-[13px] leading-relaxed text-brown-soft ${className}`}>{DISCLAIMER}</p>
)

export function PageHeader({ title, sub, back = '/', emoji, hand }: { title: string; sub?: string; back?: string | false; emoji?: string; hand?: string }) {
  return (
    <header className="mb-6">
      {back !== false && (
        <Link to={back} className="-ml-2 mb-2 inline-flex min-h-[44px] items-center gap-1 rounded-full px-2 text-[15px] font-semibold opacity-80">
          <IBack /> Back
        </Link>
      )}
      <h1 className="text-[32px] leading-[1.1] md:text-5xl">{emoji && <span className="mr-2">{emoji}</span>}{title}</h1>
      {hand && <p className="hand mt-2 text-[26px]">{hand}</p>}
      {sub && <p className="mt-2 max-w-md text-[17px] leading-relaxed opacity-80">{sub}</p>}
    </header>
  )
}

export function Empty({ emoji = '☁️', children, action }: { emoji?: string; children: ReactNode; action?: ReactNode }) {
  return (
    <div className="grid place-items-center rounded-[28px] border-2 border-dashed border-sand px-6 py-12 text-center">
      <div className="mb-2 text-4xl" aria-hidden>{emoji}</div>
      <p className="max-w-xs text-[17px] text-brown">{children}</p>
      {action && <div className="mt-4">{action}</div>}
    </div>
  )
}

export function Spinner({ label = "waittt, I'm coming 😭" }: { label?: string }) {
  return (
    <div role="status" className="grid place-items-center py-16 text-brown-soft">
      <div className="mb-3 h-8 w-8 animate-spin rounded-full border-[3px] border-sand border-t-sage-deep motion-reduce:animate-none" />
      <p>{label}</p>
    </div>
  )
}

export const ErrorNote = ({ children }: { children: ReactNode }) => (
  <p role="alert" className="rounded-2xl bg-brick/10 px-4 py-3 text-[15px] font-medium text-brick">{children}</p>
)
