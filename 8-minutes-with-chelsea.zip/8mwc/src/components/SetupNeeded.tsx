export default function SetupNeeded() {
  return (
    <main className="mx-auto grid min-h-[100dvh] max-w-md place-items-center p-6">
      <div className="card text-[16px] leading-relaxed">
        <h1 className="mb-2 text-2xl">Almost there 🌱</h1>
        <p>This app needs to be connected to Supabase first.</p>
        <ol className="mt-3 list-decimal space-y-1 pl-5">
          <li>Copy <code>.env.example</code> to <code>.env</code></li>
          <li>Fill in <code>VITE_SUPABASE_URL</code> and <code>VITE_SUPABASE_ANON_KEY</code></li>
          <li>Restart <code>npm run dev</code> (or redeploy)</li>
        </ol>
        <p className="mt-3 text-brown-soft">Full steps are in README.md.</p>
      </div>
    </main>
  )
}
