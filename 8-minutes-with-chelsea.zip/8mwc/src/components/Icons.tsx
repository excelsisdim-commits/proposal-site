const base = { width: 26, height: 26, viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', strokeWidth: 2, strokeLinecap: 'round', strokeLinejoin: 'round', 'aria-hidden': true } as const
export const IHome = () => <svg {...base}><path d="M3 11l9-7 9 7v9a1 1 0 01-1 1h-5v-6H9v6H4a1 1 0 01-1-1z" /></svg>
export const IChat = () => <svg {...base}><path d="M21 12a8 8 0 01-11.6 7.1L4 20.5l1.5-4.6A8 8 0 1121 12z" /></svg>
export const IDecide = () => <svg {...base}><rect x="4" y="4" width="16" height="16" rx="4" /><circle cx="9" cy="9" r="1" fill="currentColor" /><circle cx="15" cy="15" r="1" fill="currentColor" /><circle cx="15" cy="9" r="1" fill="currentColor" /><circle cx="9" cy="15" r="1" fill="currentColor" /></svg>
export const IPot = () => <svg {...base}><path d="M4 11h16v4a5 5 0 01-5 5H9a5 5 0 01-5-5z" /><path d="M2 11h20M9 4c-1 1.2 1 2 0 3M14 4c-1 1.2 1 2 0 3" /></svg>
export const IMore = () => <svg {...base}><circle cx="5" cy="12" r="1.3" fill="currentColor" /><circle cx="12" cy="12" r="1.3" fill="currentColor" /><circle cx="19" cy="12" r="1.3" fill="currentColor" /></svg>
export const IBack = () => <svg {...base} width={24} height={24}><path d="M15 5l-7 7 7 7" /></svg>
export const IPlus = () => <svg {...base} width={24} height={24}><path d="M12 5v14M5 12h14" /></svg>
export const ISend = () => <svg {...base} width={22} height={22}><path d="M5 12l14-7-5 14-2.5-5.5z" fill="currentColor" /></svg>
export const IClose = () => <svg {...base} width={20} height={20}><path d="M6 6l12 12M18 6L6 18" /></svg>
export const IGrid = () => <svg {...base}><rect x="3" y="3" width="7" height="7" rx="2" /><rect x="14" y="3" width="7" height="7" rx="2" /><rect x="3" y="14" width="7" height="7" rx="2" /><rect x="14" y="14" width="7" height="7" rx="2" /></svg>
export const IList = () => <svg {...base}><path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01" /></svg>
export const IBars = () => <svg {...base}><path d="M5 20V10M12 20V4M19 20v-7" /></svg>
export const ITick = ({ double }: { double?: boolean }) => (
  <svg width={double ? 18 : 14} height="12" viewBox={double ? '0 0 18 12' : '0 0 14 12'} fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
    <path d="M1.5 6.5l3.5 3.5L12.5 2" />{double && <path d="M7.5 9.5l.9.9L15.8 2" />}
  </svg>
)
