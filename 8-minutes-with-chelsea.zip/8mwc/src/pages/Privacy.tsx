import { PageHeader, Disclaimer } from '../components/Bits'

export default function Privacy() {
  const items = [
    ['Who reads my messages?', 'Chelsea, and only Chelsea. Your conversation is private to you and her. Nobody else using this site can see it.'],
    ['What does anonymous mean?', "Chelsea sees you as “Anonymous” in the chat and in her dashboard. If you give an email anyway, it's kept private and only used to send you updates. It doesn't mean the internet itself is anonymous: your device and network can still be seen by the services that run this site."],
    ['My photos', 'Photos are shrunk on your phone, stored privately, and shown only to you and Chelsea through short-lived links.'],
    ['Why ask for an email?', "Totally optional. It lets me email you when I reply, and lets you open the same chat on another phone."],
    ['Coming back later', 'This browser remembers you. If you open the chat from the email link on a different device, it will find your conversation there too.'],
    ['Notifications', 'You choose. Email is the reliable one. Browser notifications are an extra, only if you switch them on.'],
  ]
  return (
    <div className="mx-auto max-w-xl">
      <PageHeader title="Help & privacy" back="/more" />
      <div className="space-y-3">{items.map(([q, a]) => <details key={q} className="card !p-4"><summary className="min-h-[44px] cursor-pointer py-2 text-[17px] font-semibold">{q}</summary><p className="pb-2 text-[16px] leading-relaxed">{a}</p></details>)}</div>
      <div className="mt-6 rounded-[24px] bg-butter-soft p-5"><Disclaimer /></div>
    </div>
  )
}
