import { useEffect, useState } from 'react'
import { Navigate, useNavigate, useParams, useSearchParams } from 'react-router-dom'
import { ensureSession, supabase } from '../lib/supabase'
import { useAuth } from '../hooks/useAuth'
import { useChelseaStatus } from '../hooks/useChelseaStatus'
import { useNotificationPermission } from '../hooks/usePwa'
import ChatView from '../components/ChatView'
import RequestPanel from '../components/RequestPanel'
import { Empty, Spinner } from '../components/Bits'
import type { Conversation } from '../lib/types'

export default function ConversationPage() {
  const { id } = useParams()
  const [sp] = useSearchParams()
  const nav = useNavigate()
  const { isAdmin, ready } = useAuth()
  const st = useChelseaStatus()
  const notif = useNotificationPermission()
  const [conv, setConv] = useState<Conversation | null | undefined>(undefined)

  useEffect(() => {
    let alive = true
    ;(async () => {
      try {
        const token = sp.get('t')
        if (token) {
          await ensureSession()   // email link on a new device: sign in silently, then claim the conversation
          await supabase.rpc('claim_conversation', { p_id: id, p_token: token })
          nav(`/c/${id}`, { replace: true })
        }
        const { data: s } = await supabase.auth.getSession()
        if (!s.session) { if (alive) setConv(null); return }
        const { data } = await supabase.from('conversations').select('*').eq('id', id!).maybeSingle()
        if (alive) setConv((data as Conversation) ?? null)
      } catch { if (alive) setConv(null) }
    })()
    return () => { alive = false }
  }, [id])

  if (!ready || conv === undefined) return <div className="fixed inset-0 z-40 grid place-items-center bg-cream"><Spinner /></div>
  if (isAdmin) return <Navigate to={`/chelsea/inbox/${id}`} replace />
  if (!conv) return (
    <div className="mx-auto max-w-md pt-10">
      <Empty emoji="🔒" action={<button className="btn-soft btn-sm" onClick={() => nav('/c')}>See my chats</button>}>
        I can't find that conversation here. If you opened it from an email, use the button in that email on this device.
      </Empty>
    </div>
  )
  return (
    <ChatView
      conversationId={conv.id} role="guest" peerName="Chelsea"
      title="Chelsea" status={`${st.icon} ${st.label}`}
      topSlot={<RequestPanel conversationId={conv.id} />}
      headerRight={notif.supported && notif.perm === 'default' ? (
        <button onClick={notif.ask} aria-label="Turn on notifications" className="grid h-12 w-12 place-items-center rounded-full text-xl active:bg-sand">🔔</button>
      ) : undefined}
    />
  )
}
