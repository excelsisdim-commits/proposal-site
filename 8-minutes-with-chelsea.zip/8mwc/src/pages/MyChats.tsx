import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { useAuth } from '../hooks/useAuth'
import { Empty, PageHeader, Spinner } from '../components/Bits'
import { StatusBadge } from '../components/RequestCard'
import { TYPE_EMOJI, TYPE_LABEL } from '../lib/services'
import { timeAgo } from '../lib/util'
import type { Conversation } from '../lib/types'

export default function MyChats() {
  const { session, ready } = useAuth()
  const [items, setItems] = useState<Conversation[] | null>(null)
  useEffect(() => {
    if (!ready) return
    if (!session) { setItems([]); return }
    const load = () => supabase.from('conversations').select('*, requests(*)').order('last_message_at', { ascending: false })
      .then(({ data }) => setItems((data ?? []) as Conversation[]))
    load()
    const ch = supabase.channel('mychats').on('postgres_changes', { event: '*', schema: 'public', table: 'conversations' }, load).subscribe()
    return () => { supabase.removeChannel(ch) }
  }, [session?.user.id, ready])

  return (
    <div className="mx-auto max-w-xl">
      <PageHeader title="My chats" emoji="💬" back="/more" />
      {items === null ? <Spinner /> : items.length === 0 ? (
        <Empty emoji="☁️" action={<Link to="/talk" className="btn-primary btn-sm">Come sit with me</Link>}>It's quiet here... send something when you're ready ☁️</Empty>
      ) : (
        <ul className="space-y-3">
          {items.map((c) => (
            <li key={c.id}>
              <Link to={`/c/${c.id}`} className="card flex min-h-[72px] items-center gap-3 !p-4 transition active:scale-[.98]">
                <span className="text-3xl" aria-hidden>{TYPE_EMOJI[c.topic] ?? '💬'}</span>
                <span className="min-w-0 flex-1">
                  <b className="block truncate text-[17px]">{TYPE_LABEL[c.topic] ?? 'Chat'}</b>
                  <span className="text-[13px] text-brown-soft">{timeAgo(c.last_message_at)}</span>
                </span>
                {c.requests?.[0] && <StatusBadge status={c.requests[0].status} />}
                {c.unread_guest > 0 && <span aria-label={`${c.unread_guest} unread`} className="grid h-6 min-w-[24px] place-items-center rounded-full bg-brick px-1.5 text-[12px] font-bold text-white">{c.unread_guest}</span>}
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}
