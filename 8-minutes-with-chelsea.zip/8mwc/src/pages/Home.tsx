import { Link } from 'react-router-dom'
import { Star, Cloud, Squiggle, Moon, Stars } from '../components/Doodles'
import { Disclaimer } from '../components/Bits'
import { useChelseaStatus } from '../hooks/useChelseaStatus'

const tiles = [
  { to: '/s/talk', e: '🫂', t: 'I need to talk', c: 'bg-sage-soft', r: '-rotate-1' },
  { to: '/s/advice', e: '💗', t: 'I need advice', c: 'bg-butter-soft', r: 'rotate-1' },
  { to: '/s/outfit', e: '👗', t: 'Pick my outfit', c: 'bg-dusty-soft', r: 'rotate-[.6deg]' },
  { to: '/s/hype', e: '🎀', t: 'Hype me up', c: 'bg-sand', r: '-rotate-[.8deg]' },
  { to: '/distract', e: '😂', t: 'Distract me', c: 'bg-sage-soft', r: '-rotate-[.5deg]' },
  { to: '/s/decide', e: '💄', t: 'Help me decide', c: 'bg-butter-soft', r: 'rotate-[.8deg]' },
]

export default function Home() {
  const st = useChelseaStatus()
  return (
    <div className="space-y-10">
      <section className="relative pt-2">
        <Star className="absolute right-3 top-2 animate-twinkle text-butter" size={26} />
        <Star className="absolute right-12 top-14 animate-twinkle text-sage" size={14} />
        <Cloud className="absolute -left-1 top-0 text-dusty" />
        <div className="relative pt-12">
          <h1 className="leading-[.9]">
            <span className="block text-[88px] md:text-[150px]">8 minutes</span>
          </h1>
          <p className="hand -mt-1 ml-1 -rotate-2 text-[44px] text-sage-deep md:text-[64px]">with Chelsea</p>
          <Squiggle className="mt-1 text-butter" />
        </div>
        <p className="mt-6 max-w-sm text-[19px] leading-relaxed">
          Maybe you need to rant.<br />Maybe you need advice.<br />Maybe you just don't want to feel alone for a little while.
        </p>
        <p className="mt-3 max-w-sm text-[17px] text-brown">You don't have to know exactly what you need. Just come sit with me.</p>
        <div className="mt-6 flex max-w-sm flex-col gap-3 sm:flex-row">
          <Link to="/talk" className="btn-primary flex-1 text-[18px]">Come Sit With Me 💌</Link>
          <Link to="/midnight" className="btn-soft flex-1 !bg-night !text-cream hover:!bg-night-2">It's one of those nights? 🌙</Link>
        </div>
        <p className="mt-4 inline-flex items-center gap-2 rounded-full bg-white/70 px-3 py-1.5 text-[14px] ring-1 ring-brown/10" aria-live="polite">
          <span aria-hidden>{st.icon}</span>{st.label}
        </p>
        <p className="hand mt-4 rotate-1 text-[28px]">Okayyy, tell me everything.</p>
      </section>

      <section aria-labelledby="need">
        <h2 id="need" className="mb-4 text-[26px]">What do you need today?</h2>
        <ul className="grid grid-cols-2 gap-3 md:grid-cols-3">
          {tiles.map((t) => (
            <li key={t.to}>
              <Link to={t.to} className={`flex min-h-[116px] flex-col justify-between rounded-[26px] p-4 shadow-soft ring-1 ring-brown/10 transition active:scale-[.97] ${t.c} ${t.r}`}>
                <span className="text-3xl" aria-hidden>{t.e}</span>
                <span className="text-[17px] font-semibold leading-tight">{t.t}</span>
              </Link>
            </li>
          ))}
          <li className="col-span-2 md:col-span-3">
            <Link to="/s/chat" className="flex min-h-[72px] items-center gap-3 rounded-[26px] bg-white/80 p-4 shadow-soft ring-1 ring-brown/10 transition active:scale-[.98]">
              <span className="text-3xl" aria-hidden>☕</span>
              <span><b className="block text-[17px]">Just chat</b><span className="text-[15px] text-brown-soft">You don't need a reason. Come talk to me.</span></span>
            </Link>
          </li>
        </ul>
      </section>

      <section className="night relative overflow-hidden rounded-[32px] p-6">
        <Stars n={18} />
        <Moon className="relative text-butter" size={34} />
        <h2 className="relative mt-3 text-[28px]">It's one of those nights?</h2>
        <p className="relative mt-2 max-w-xs text-[17px] opacity-85">You don't need advice. You just need somebody there.</p>
        <Link to="/midnight" className="btn-primary relative mt-5 w-full sm:w-auto">Come sit with me</Link>
      </section>

      <section className="rounded-[32px] bg-sage-soft p-6">
        <div className="text-3xl" aria-hidden>🍝</div>
        <h2 className="mt-2 text-[26px]">What's in your kitchen?</h2>
        <p className="mt-2 max-w-xs text-[17px]">Tell me what you've got. I'll tell you what to make.</p>
        <Link to="/cook" className="btn-primary mt-5 w-full sm:w-auto">Let's cook</Link>
      </section>

      <section className="grid gap-3 md:grid-cols-2">
        <Link to="/little-things" className="card flex items-center gap-4 !p-5 transition active:scale-[.98]">
          <span className="text-3xl" aria-hidden>🫶</span>
          <span><b className="block text-[18px]">Little Things</b><span className="text-[15px] text-brown-soft">Leave me a small note. No session needed.</span></span>
        </Link>
        <Link to="/about" className="card flex items-center gap-4 !p-5 transition active:scale-[.98]">
          <span className="text-3xl" aria-hidden>☁️</span>
          <span><b className="block text-[18px]">Who's Chelsea?</b><span className="text-[15px] text-brown-soft">A tiny corner of the internet, explained.</span></span>
        </Link>
      </section>

      <Disclaimer className="mx-auto max-w-md text-center" />
    </div>
  )
}
