import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { PageHeader, Disclaimer } from '../components/Bits'
import { Cloud, Star } from '../components/Doodles'

const FALLBACK = `Hi, I'm Chelsea.

I'm the person people come to when they need to talk, need someone to help them decide, need a little encouragement, or just want somebody around.

So I made a tiny corner of the internet for exactly that.

You don't have to come here with a big problem.

You can come because you had a weird day.
You need an outfit opinion.
You don't know what to cook.
You need to rant.
Or it's midnight and you just want somebody to listen.

Whatever it is...

come talk to me.`

export default function About() {
  const [text, setText] = useState(FALLBACK)
  useEffect(() => { supabase.from('site_content').select('value').eq('key', 'about').maybeSingle().then(({ data }) => { if (data?.value) setText(data.value) }) }, [])
  return (
    <div className="mx-auto max-w-xl">
      <PageHeader title="About" back="/more" />
      <div className="relative rounded-[32px] bg-white/80 p-6 shadow-soft ring-1 ring-brown/10">
        <Cloud className="absolute -top-4 right-4 text-dusty" /><Star className="absolute right-20 top-1 text-butter" size={18} />
        <p className="whitespace-pre-line text-[18px] leading-[1.75]">{text}</p>
      </div>
      <Link to="/talk" className="btn-primary mt-6 w-full">Come sit with me 🤍</Link>
      <Disclaimer className="mt-8" />
    </div>
  )
}
