import { useState } from 'react'
import { ensureSession, supabase } from '../lib/supabase'
import { ErrorNote, PageHeader } from '../components/Bits'
import { errMessage } from '../lib/util'

const PROMPTS = [
  { p: 'Tell me something good that happened today.', c: 'bg-butter-soft', r: '-rotate-1' },
  { p: 'Leave Chelsea a compliment.', c: 'bg-sage-soft', r: 'rotate-1' },
  { p: "Tell me something you're proud of.", c: 'bg-dusty-soft', r: '-rotate-[.6deg]' },
  { p: 'Tell me one thing you need to hear today.', c: 'bg-sand', r: 'rotate-[.8deg]' },
]

export default function LittleThings() {
  const [open, setOpen] = useState<number | null>(null)
  const [body, setBody] = useState('')
  const [name, setName] = useState('')
  const [busy, setBusy] = useState(false)
  const [err, setErr] = useState<string | null>(null)
  const [sent, setSent] = useState(false)

  async function send(e: React.FormEvent) {
    e.preventDefault()
    if (open === null) return
    if (!body.trim()) { setErr('Write a few words first. Even one line is perfect.'); return }
    setBusy(true); setErr(null)
    try {
      await ensureSession()
      const { error } = await supabase.from('little_things').insert({ prompt: PROMPTS[open].p, body: body.trim(), display_name: name.trim() || null })
      if (error) throw error
      setSent(true); setBody('')
    } catch (e) { setErr(errMessage(e)) } finally { setBusy(false) }
  }

  if (sent) return (
    <div className="mx-auto max-w-xl">
      <PageHeader title="Little Things" emoji="🫶" back="/more" />
      <div className="card text-center"><div className="text-5xl" aria-hidden>💌</div><h2 className="mt-3 text-[24px]">Tucked into my pocket.</h2><p className="mt-2 text-[17px]">Thank you for telling me. I'll read it privately.</p>
        <button className="btn-soft mt-5 w-full" onClick={() => { setSent(false); setOpen(null) }}>Leave another one</button></div>
    </div>
  )

  return (
    <div className="mx-auto max-w-xl">
      <PageHeader title="Little Things" emoji="🫶" hand="No session needed. Just leave me a note." sub="Only I can read these. Add your name if you want me to know it's you." back="/more" />
      {open === null ? (
        <ul className="grid gap-4">
          {PROMPTS.map((p, i) => (
            <li key={p.p}><button onClick={() => setOpen(i)} className={`min-h-[96px] w-full rounded-[10px] p-5 text-left shadow-soft ring-1 ring-brown/10 transition active:scale-[.98] ${p.c} ${p.r}`}>
              <span className="hand block text-[28px] leading-tight">{p.p}</span><span className="mt-2 block text-[14px] text-brown-soft">Tap to write your note</span></button></li>
          ))}
        </ul>
      ) : (
        <form onSubmit={send} className="space-y-4" noValidate>
          <div className={`rounded-[10px] p-5 shadow-soft ${PROMPTS[open].c}`}><p className="hand text-[28px] leading-tight">{PROMPTS[open].p}</p></div>
          <div><label htmlFor="lt-body" className="label">Your note</label>
            <textarea id="lt-body" className="field min-h-[150px]" value={body} onChange={(e) => setBody(e.target.value)} maxLength={1500} autoFocus /></div>
          <div><label htmlFor="lt-name" className="label">Name <span className="font-normal opacity-70">(optional)</span></label>
            <input id="lt-name" className="field" value={name} onChange={(e) => setName(e.target.value)} maxLength={60} autoComplete="given-name" /></div>
          {err && <ErrorNote>{err}</ErrorNote>}
          <button className="btn-primary w-full" disabled={busy}>{busy ? 'Tucking it in…' : 'Send my note 🫶'}</button>
          <button type="button" className="btn-ghost w-full" onClick={() => { setOpen(null); setErr(null) }}>Pick a different prompt</button>
        </form>
      )}
    </div>
  )
}
