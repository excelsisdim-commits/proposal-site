import { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { recipeImageUrl } from '../lib/upload'
import { CATEGORY_EMOJI } from '../lib/cooking'
import type { Recipe as R } from '../lib/types'
import { Empty, PageHeader, Spinner } from '../components/Bits'

export default function Recipe() {
  const { id } = useParams()
  const [r, setR] = useState<R | null | undefined>(undefined)
  const [checked, setChecked] = useState<Record<number, boolean>>({})
  useEffect(() => { supabase.from('recipes').select('*').eq('id', id!).maybeSingle().then(({ data }) => setR((data as R) ?? null)) }, [id])
  if (r === undefined) return <Spinner />
  if (r === null) return <Empty emoji="🥄">I can't find that recipe.</Empty>
  const img = recipeImageUrl(r.image_path)
  return (
    <article className="mx-auto max-w-2xl">
      <PageHeader title={r.name} back="/cook" />
      <div className="mb-5 grid aspect-[16/10] place-items-center overflow-hidden rounded-[28px] bg-sage-soft text-7xl">
        {img ? <img src={img} alt={r.name} className="h-full w-full object-cover" /> : <span aria-hidden>{CATEGORY_EMOJI[r.category] ?? '🍽️'}</span>}
      </div>
      <p className="text-[18px] leading-relaxed">{r.description}</p>
      <p className="mt-3 flex flex-wrap gap-2 text-[14px]">
        <span className="chip">⏱ {r.minutes} min</span><span className="chip">⭐ {r.difficulty}</span><span className="chip">{CATEGORY_EMOJI[r.category]} {r.category}</span>
        {r.tags?.map((t) => <span key={t} className="chip">#{t}</span>)}
      </p>
      <h2 className="mb-3 mt-8 text-[24px]">What you need</h2>
      <ul className="space-y-1">
        {r.ingredients.map((i, k) => (
          <li key={k}>
            <label className="flex min-h-[48px] items-center gap-3 rounded-xl px-1 text-[17px]">
              <input type="checkbox" className="h-6 w-6 accent-[#55735A]" checked={!!checked[k]} onChange={() => setChecked((c) => ({ ...c, [k]: !c[k] }))} />
              <span className={checked[k] ? 'line-through opacity-50' : ''}>{i.qty ? <b>{i.qty} </b> : null}{i.name}{i.staple && <span className="text-brown-soft"> (pantry)</span>}</span>
            </label>
          </li>
        ))}
      </ul>
      <h2 className="mb-3 mt-8 text-[24px]">How to make it</h2>
      <ol className="space-y-4">
        {r.steps.map((s, k) => (
          <li key={k} className="flex gap-3"><span className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-ink font-bold text-paper" aria-hidden>{k + 1}</span><p className="pt-0.5 text-[17px] leading-relaxed">{s}</p></li>
        ))}
      </ol>
    </article>
  )
}
