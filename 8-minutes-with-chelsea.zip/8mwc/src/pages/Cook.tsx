import { useEffect, useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { ensureSession, supabase } from '../lib/supabase'
import { CATEGORIES, CATEGORY_EMOJI, COMMON_CHIPS, Match, matchRecipes, parseIngredients } from '../lib/cooking'
import { recipeImageUrl } from '../lib/upload'
import type { Recipe } from '../lib/types'
import { Empty, ErrorNote, PageHeader, Spinner } from '../components/Bits'
import { cx } from '../lib/util'

export function RecipeCard({ r, note }: { r: Recipe; note?: string }) {
  const img = recipeImageUrl(r.image_path)
  return (
    <Link to={`/cook/${r.id}`} className="flex gap-3 rounded-[26px] bg-white/80 p-3 shadow-soft ring-1 ring-brown/10 transition active:scale-[.98]">
      <div className="grid h-24 w-24 shrink-0 place-items-center overflow-hidden rounded-2xl bg-sage-soft text-4xl">
        {img ? <img src={img} alt="" loading="lazy" className="h-full w-full object-cover" /> : <span aria-hidden>{CATEGORY_EMOJI[r.category] ?? '🍽️'}</span>}
      </div>
      <div className="min-w-0 flex-1 py-1">
        <h3 className="font-display text-[18px] leading-tight">{r.name}</h3>
        <p className="mt-1 text-[14px] text-brown-soft">⏱ {r.minutes} min · ⭐ {r.difficulty}</p>
        {note && <p className="mt-1 text-[14px] font-semibold text-sage-deep">{note}</p>}
      </div>
    </Link>
  )
}

export default function Cook() {
  const [recipes, setRecipes] = useState<Recipe[] | null>(null)
  const [loadErr, setLoadErr] = useState(false)
  const [chips, setChips] = useState<string[]>([])
  const [text, setText] = useState('')
  const [results, setResults] = useState<Match[] | null>(null)
  const [cat, setCat] = useState<string>('All')

  useEffect(() => {
    supabase.from('recipes').select('*').eq('is_published', true).order('created_at', { ascending: false })
      .then(({ data, error }) => { if (error) setLoadErr(true); else setRecipes((data ?? []) as Recipe[]) })
  }, [])

  const toggle = (c: string) => setChips((x) => (x.includes(c) ? x.filter((y) => y !== c) : [...x, c]))
  const have = useMemo(() => Array.from(new Set([...chips, ...parseIngredients(text)])), [chips, text])

  async function feed(e: React.FormEvent) {
    e.preventDefault()
    if (!recipes || !have.length) return
    setResults(matchRecipes(recipes, have))
    // anonymous usage count for the dashboard; failure here must never matter
    try { await ensureSession(); await supabase.from('cook_searches').insert({ ingredients: have.slice(0, 30) }) } catch { /* ignore */ }
    requestAnimationFrame(() => document.getElementById('results')?.scrollIntoView({ behavior: 'smooth', block: 'start' }))
  }

  const ready = results?.filter((m) => m.missing.length === 0) ?? []
  const almost = results?.filter((m) => m.missing.length > 0 && m.missing.length <= 2) ?? []
  const more = results?.filter((m) => m.missing.length > 2) ?? []
  const shown = (recipes ?? []).filter((r) => cat === 'All' || r.category === cat)

  return (
    <div className="mx-auto max-w-2xl">
      <PageHeader title="What's in your kitchen?" emoji="🍝" hand="Tell me what you've got." back="/" />

      <form onSubmit={feed} className="card space-y-4">
        <div>
          <label htmlFor="ing" className="label">What do you have?</label>
          <input id="ing" className="field" value={text} onChange={(e) => setText(e.target.value)} placeholder="chicken, rice, tomato..." autoCapitalize="none" autoCorrect="off" enterKeyHint="go" />
          <p className="mt-1.5 text-[13px] text-brown-soft">Separate with commas, or tap the ones below.</p>
        </div>
        <div className="flex flex-wrap gap-2" role="group" aria-label="Common ingredients">
          {COMMON_CHIPS.map((c) => (
            <button key={c} type="button" onClick={() => toggle(c)} aria-pressed={chips.includes(c)} className={cx('chip', chips.includes(c) && 'chip-on')}>{chips.includes(c) ? '✓' : '+'} {c}</button>
          ))}
        </div>
        <button className="btn-primary w-full" disabled={!have.length || !recipes}>Feed Me An Idea 🍝</button>
      </form>

      {recipes === null && !loadErr && <Spinner />}
      {loadErr && <div className="mt-6"><ErrorNote>Couldn't load recipes. Check your connection and refresh.</ErrorNote></div>}

      {results && (
        <section id="results" className="mt-8 scroll-mt-4 space-y-6" aria-live="polite">
          {results.length === 0 ? (
            <Empty emoji="🥲" action={<Link to="/s/chat" className="btn-soft btn-sm">Ask me instead</Link>}>
              Nothing matches yet. Try adding one more ingredient, or browse everything below.
            </Empty>
          ) : (
            <>
              {ready.length > 0 && <div><h2 className="mb-3 text-[22px]">You can make these now</h2><ul className="space-y-3">{ready.map((m) => <li key={m.recipe.id}><RecipeCard r={m.recipe} note={`You have everything (${m.have.length}/${m.have.length})`} /></li>)}</ul></div>}
              {almost.length > 0 && <div><h2 className="mb-3 text-[22px]">So close</h2><ul className="space-y-3">{almost.map((m) => <li key={m.recipe.id}><RecipeCard r={m.recipe} note={`Missing: ${m.missing.join(', ')}`} /></li>)}</ul></div>}
              {more.length > 0 && <div><h2 className="mb-3 text-[22px]">If you pick up a few things</h2><ul className="space-y-3">{more.slice(0, 6).map((m) => <li key={m.recipe.id}><RecipeCard r={m.recipe} note={`Missing ${m.missing.length}: ${m.missing.slice(0, 3).join(', ')}${m.missing.length > 3 ? '…' : ''}`} /></li>)}</ul></div>}
            </>
          )}
        </section>
      )}

      <section className="mt-12" aria-labelledby="recipes-h">
        <h2 id="recipes-h" className="text-[26px]">Chelsea's recipes</h2>
        <div className="-mx-4 mt-3 flex gap-2 overflow-x-auto px-4 pb-2" role="group" aria-label="Recipe categories">
          {['All', ...CATEGORIES].map((c) => (
            <button key={c} onClick={() => setCat(c)} aria-pressed={cat === c} className={cx('chip shrink-0', cat === c && 'chip-on')}>{c !== 'All' && <span aria-hidden>{CATEGORY_EMOJI[c]}</span>}{c}</button>
          ))}
        </div>
        {recipes && (shown.length ? (
          <ul className="mt-3 grid gap-3 md:grid-cols-2">{shown.map((r) => <li key={r.id}><RecipeCard r={r} /></li>)}</ul>
        ) : <div className="mt-3"><Empty emoji="🍳">Nothing in this category yet. I'm still cooking.</Empty></div>)}
      </section>
    </div>
  )
}
