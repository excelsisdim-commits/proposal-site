import { Link } from 'react-router-dom'
import { PageHeader } from '../components/Bits'
import { SERVICES, ServiceKey } from '../lib/services'

function Hub({ title, sub, hand, keys, extra }: { title: string; sub: string; hand?: string; keys: ServiceKey[]; extra?: { to: string; e: string; t: string; d: string }[] }) {
  return (
    <div>
      <PageHeader title={title} sub={sub} hand={hand} />
      <ul className="grid gap-3 md:grid-cols-2">
        {keys.map((k) => {
          const s = SERVICES[k]
          return (
            <li key={k}>
              <Link to={k === 'midnight' ? '/midnight' : k === 'distract' ? '/distract' : `/s/${k}`} className={`flex min-h-[88px] items-center gap-4 rounded-[26px] p-4 shadow-soft ring-1 ring-brown/10 transition active:scale-[.98] ${k === 'midnight' ? 'bg-night text-cream' : s.tint}`}>
                <span className="text-4xl" aria-hidden>{s.emoji}</span>
                <span><b className="block text-[18px] leading-tight">{s.title}</b><span className="text-[15px] opacity-80">{s.tagline}</span></span>
              </Link>
            </li>
          )
        })}
        {extra?.map((x) => (
          <li key={x.to}><Link to={x.to} className="flex min-h-[88px] items-center gap-4 rounded-[26px] bg-white/80 p-4 shadow-soft ring-1 ring-brown/10 transition active:scale-[.98]">
            <span className="text-4xl" aria-hidden>{x.e}</span><span><b className="block text-[18px] leading-tight">{x.t}</b><span className="text-[15px] text-brown-soft">{x.d}</span></span></Link></li>
        ))}
      </ul>
    </div>
  )
}

export const TalkHub = () => <Hub title="Let's talk" sub="Pick whatever feels closest. You can say more once we start." hand="Come sit with me." keys={['talk', 'advice', 'hype', 'chat', 'midnight']} />
export const DecideHub = () => <Hub title="Help me choose" sub="Two photos, a long list, or just vibes. I'll pick." hand="Don't fight me on this 😭" keys={['outfit', 'decide', 'distract']} />
