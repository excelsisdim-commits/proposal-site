import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from '../../lib/supabase'
import { StatusPicker } from './AdminShell'
import { ErrorNote } from '../../components/Bits'

const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
type Day = { on: boolean; start: string; end: string }

export function AdminMore() {
  return (
    <div className="mx-auto max-w-xl space-y-3">
      <h1 className="mb-2 text-[30px]">More</h1>
      {[['/chelsea/recipes', '🍳', 'Recipes'], ['/chelsea/notes', '🫶', 'Little notes'], ['/chelsea/settings', '⚙️', 'About, hours & status'], ['/', '🌐', 'View the site']].map(([to, e, t]) => (
        <Link key={to} to={to} className="card flex min-h-[64px] items-center gap-4 !p-4"><span className="text-3xl" aria-hidden>{e}</span><b className="text-[17px]">{t}</b></Link>
      ))}
      <button className="btn-ghost w-full" onClick={() => supabase.auth.signOut().then(() => (location.href = '/'))}>Sign out</button>
    </div>
  )
}

export default function Settings() {
  const [about, setAbout] = useState(''); const [savedAbout, setSavedAbout] = useState(false)
  const [days, setDays] = useState<Day[]>(DAYS.map(() => ({ on: false, start: '08:00', end: '18:00' })))
  const [savedHours, setSavedHours] = useState(false); const [err, setErr] = useState<string | null>(null)

  useEffect(() => {
    supabase.from('site_content').select('value').eq('key', 'about').maybeSingle().then(({ data }) => setAbout(data?.value ?? ''))
    supabase.from('work_hours').select('*').then(({ data }) => {
      const d = DAYS.map(() => ({ on: false, start: '08:00', end: '18:00' }))
      ;(data ?? []).forEach((r: any) => { d[r.weekday - 1] = { on: true, start: String(r.start_time).slice(0, 5), end: String(r.end_time).slice(0, 5) } })
      setDays(d)
    })
  }, [])

  async function saveAbout() {
    setErr(null)
    const { error } = await supabase.from('site_content').upsert({ key: 'about', value: about, updated_at: new Date().toISOString() })
    if (error) return setErr(error.message)
    setSavedAbout(true); setTimeout(() => setSavedAbout(false), 2000)
  }
  async function saveHours() {
    setErr(null)
    const rows = days.map((d, i) => ({ weekday: i + 1, start_time: d.start, end_time: d.end, on: d.on })).filter((r) => r.on).map(({ on, ...r }) => r)
    const del = await supabase.from('work_hours').delete().gte('weekday', 1)
    if (del.error) return setErr(del.error.message)
    if (rows.length) { const ins = await supabase.from('work_hours').insert(rows); if (ins.error) return setErr(ins.error.message) }
    setSavedHours(true); setTimeout(() => setSavedHours(false), 2000)
  }

  return (
    <div className="mx-auto max-w-xl space-y-8">
      <h1 className="text-[30px]">Settings</h1>
      <section><h2 className="mb-3 text-[20px]">My status</h2><StatusPicker /></section>
      <section>
        <h2 className="mb-1 text-[20px]">Work hours</h2>
        <p className="mb-3 text-[14px] text-brown-soft">Times are Lagos time. These never block requests. They only show people a gentle heads-up.</p>
        <ul className="space-y-2">{days.map((d, i) => (
          <li key={i} className="flex flex-wrap items-center gap-3 rounded-2xl bg-white/70 p-3 ring-1 ring-brown/10">
            <label className="flex min-h-[44px] w-32 items-center gap-2"><input type="checkbox" className="h-6 w-6 accent-[#55735A]" checked={d.on} onChange={(e) => setDays(days.map((x, j) => (j === i ? { ...x, on: e.target.checked } : x)))} />{DAYS[i]}</label>
            {d.on && <><input aria-label={`${DAYS[i]} start`} type="time" className="field !min-h-[44px] !w-auto" value={d.start} onChange={(e) => setDays(days.map((x, j) => (j === i ? { ...x, start: e.target.value } : x)))} /><span>to</span>
              <input aria-label={`${DAYS[i]} end`} type="time" className="field !min-h-[44px] !w-auto" value={d.end} onChange={(e) => setDays(days.map((x, j) => (j === i ? { ...x, end: e.target.value } : x)))} /></>}
          </li>))}</ul>
        <button className="btn-primary btn-sm mt-3" onClick={saveHours}>{savedHours ? 'Saved ✓' : 'Save hours'}</button>
      </section>
      <section>
        <h2 className="mb-3 text-[20px]">About text</h2>
        <label htmlFor="about" className="sr-only">About text</label>
        <textarea id="about" className="field min-h-[260px] leading-relaxed" value={about} onChange={(e) => setAbout(e.target.value)} />
        <button className="btn-primary btn-sm mt-3" onClick={saveAbout}>{savedAbout ? 'Saved ✓' : 'Save about'}</button>
      </section>
      {err && <ErrorNote>{err}</ErrorNote>}
    </div>
  )
}
