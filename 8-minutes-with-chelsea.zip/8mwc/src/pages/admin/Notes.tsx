import { useCallback, useEffect, useState } from 'react'
import { supabase } from '../../lib/supabase'
import { Empty, Spinner } from '../../components/Bits'
import { timeAgo } from '../../lib/util'
import type { LittleThing } from '../../lib/types'

export default function Notes() {
  const [items, setItems] = useState<LittleThing[] | null>(null)
  const load = useCallback(() => supabase.from('little_things').select('*').order('created_at', { ascending: false }).then(({ data }) => setItems((data ?? []) as LittleThing[])), [])
  useEffect(() => {
    load()
    const ch = supabase.channel('admin-notes').on('postgres_changes', { event: '*', schema: 'public', table: 'little_things' }, load).subscribe()
    return () => { supabase.removeChannel(ch) }
  }, [load])
  const toggle = async (n: LittleThing) => { await supabase.from('little_things').update({ is_read: !n.is_read }).eq('id', n.id); load() }
  const del = async (n: LittleThing) => { if (confirm('Delete this note?')) { await supabase.from('little_things').delete().eq('id', n.id); load() } }
  return (
    <div className="mx-auto max-w-xl">
      <h1 className="mb-4 text-[30px]">Little notes 🫶</h1>
      {items === null ? <Spinner /> : items.length === 0 ? <Empty emoji="💌">No notes yet. They'll show up here.</Empty> : (
        <ul className="space-y-3">{items.map((n) => (
          <li key={n.id} className={`rounded-[12px] p-4 shadow-soft ring-1 ring-brown/10 ${n.is_read ? 'bg-white/60' : 'bg-butter-soft'}`}>
            <p className="hand text-[22px] leading-tight text-brown-soft">{n.prompt}</p>
            <p className="msg-text mt-2 text-[17px] leading-relaxed">{n.body}</p>
            <p className="mt-2 text-[13px] text-brown-soft">{n.display_name ? `— ${n.display_name}` : '— someone'} · {timeAgo(n.created_at)}</p>
            <div className="mt-3 flex gap-2"><button className="btn-soft btn-sm" onClick={() => toggle(n)}>{n.is_read ? 'Mark unread' : 'Mark read'}</button><button className="btn-ghost btn-sm" onClick={() => del(n)}>Delete</button></div>
          </li>))}</ul>
      )}
    </div>
  )
}
