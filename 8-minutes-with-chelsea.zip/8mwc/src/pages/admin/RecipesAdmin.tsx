import { useEffect, useRef, useState } from 'react'
import { supabase } from '../../lib/supabase'
import { prepareImage } from '../../lib/image'
import { recipeImageUrl, uploadRecipeImage } from '../../lib/upload'
import { CATEGORIES } from '../../lib/cooking'
import { Empty, ErrorNote, Spinner } from '../../components/Bits'
import type { Recipe, Ingredient } from '../../lib/types'

const ingToText = (i: Ingredient[]) => i.map((x) => [x.name, x.qty ?? '', x.staple ? 'pantry' : ''].join(' | ').replace(/( \| )+$/, '')).join('\n')
const textToIng = (t: string): Ingredient[] => t.split('\n').map((l) => l.trim()).filter(Boolean).map((l) => {
  const [name, qty, flag] = l.split('|').map((s) => s.trim())
  return { name, ...(qty ? { qty } : {}), ...(flag?.toLowerCase() === 'pantry' ? { staple: true } : {}) }
})

const blank = { id: '', name: '', description: '', ingredients: '', steps: '', minutes: 20, difficulty: 'easy', category: 'Rice', tags: '', image_path: '' as string | null, is_published: true }

export default function RecipesAdmin() {
  const [list, setList] = useState<Recipe[] | null>(null)
  const [f, setF] = useState<typeof blank | null>(null)
  const [busy, setBusy] = useState(false); const [err, setErr] = useState<string | null>(null)
  const fileRef = useRef<HTMLInputElement>(null)
  const load = () => supabase.from('recipes').select('*').order('created_at', { ascending: false }).then(({ data }) => setList((data ?? []) as Recipe[]))
  useEffect(() => { load() }, [])

  const edit = (r: Recipe) => setF({ id: r.id, name: r.name, description: r.description, ingredients: ingToText(r.ingredients), steps: r.steps.join('\n'), minutes: r.minutes, difficulty: r.difficulty, category: r.category, tags: r.tags.join(', '), image_path: r.image_path, is_published: r.is_published })

  async function pickImage(file?: File) {
    if (!file || !f) return
    try { setErr(null); setBusy(true); const p = await prepareImage(file, 1200, 0.8); const path = await uploadRecipeImage(p.blob); setF({ ...f, image_path: path }) }
    catch (e: any) { setErr(e.message ?? 'Image upload failed') } finally { setBusy(false) }
  }
  async function save(e: React.FormEvent) {
    e.preventDefault(); if (!f) return
    const ingredients = textToIng(f.ingredients); const steps = f.steps.split('\n').map((s) => s.trim()).filter(Boolean)
    if (!f.name.trim()) return setErr('Give the recipe a name.')
    if (!ingredients.length) return setErr('Add at least one ingredient (one per line).')
    if (!steps.length) return setErr('Add at least one step (one per line).')
    setBusy(true); setErr(null)
    const row = { name: f.name.trim(), description: f.description.trim(), ingredients, steps, minutes: Number(f.minutes) || 20, difficulty: f.difficulty, category: f.category, tags: f.tags.split(',').map((t) => t.trim().toLowerCase()).filter(Boolean), image_path: f.image_path || null, is_published: f.is_published }
    const { error } = f.id ? await supabase.from('recipes').update(row).eq('id', f.id) : await supabase.from('recipes').insert(row)
    setBusy(false)
    if (error) return setErr(error.message)
    setF(null); load()
  }
  async function del(r: Recipe) { if (!confirm(`Delete "${r.name}"?`)) return; await supabase.from('recipes').delete().eq('id', r.id); load() }

  if (f) return (
    <form onSubmit={save} className="mx-auto max-w-xl space-y-4">
      <h1 className="text-[28px]">{f.id ? 'Edit recipe' : 'New recipe'}</h1>
      <div><label className="label" htmlFor="r-name">Name</label><input id="r-name" className="field" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></div>
      <div><label className="label" htmlFor="r-desc">Description</label><textarea id="r-desc" className="field min-h-[80px]" value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} /></div>
      <div className="grid grid-cols-2 gap-3">
        <div><label className="label" htmlFor="r-cat">Category</label><select id="r-cat" className="field" value={f.category} onChange={(e) => setF({ ...f, category: e.target.value })}>{CATEGORIES.map((c) => <option key={c}>{c}</option>)}</select></div>
        <div><label className="label" htmlFor="r-diff">Difficulty</label><select id="r-diff" className="field" value={f.difficulty} onChange={(e) => setF({ ...f, difficulty: e.target.value })}><option>easy</option><option>medium</option><option>a bit extra</option></select></div>
        <div><label className="label" htmlFor="r-min">Cooking time (min)</label><input id="r-min" className="field" type="number" inputMode="numeric" min={1} value={f.minutes} onChange={(e) => setF({ ...f, minutes: Number(e.target.value) })} /></div>
        <div><label className="label" htmlFor="r-tags">Tags</label><input id="r-tags" className="field" placeholder="quick, party" value={f.tags} onChange={(e) => setF({ ...f, tags: e.target.value })} /></div>
      </div>
      <div><label className="label" htmlFor="r-ing">Ingredients (one per line: name | amount | pantry)</label>
        <textarea id="r-ing" className="field min-h-[140px] font-mono text-[15px]" placeholder={'rice | 2 cups\ntomato | 4 big\noil | 1/3 cup | pantry'} value={f.ingredients} onChange={(e) => setF({ ...f, ingredients: e.target.value })} />
        <p className="mt-1 text-[13px] text-brown-soft">Add "| pantry" for things most kitchens have (salt, oil). They're ignored when matching.</p></div>
      <div><label className="label" htmlFor="r-steps">Instructions (one step per line)</label><textarea id="r-steps" className="field min-h-[160px]" value={f.steps} onChange={(e) => setF({ ...f, steps: e.target.value })} /></div>
      <div>
        <span className="label">Image</span>
        {f.image_path && <img src={recipeImageUrl(f.image_path)!} alt="" className="mb-2 h-40 w-full rounded-2xl object-cover" />}
        <input ref={fileRef} type="file" accept="image/*,.heic,.heif" className="hidden" onChange={(e) => { pickImage(e.target.files?.[0]); e.target.value = '' }} />
        <button type="button" className="btn-soft btn-sm" onClick={() => fileRef.current?.click()} disabled={busy}>{f.image_path ? 'Replace image' : '🖼️ Add image'}</button>
      </div>
      <label className="flex min-h-[48px] items-center gap-3"><input type="checkbox" className="h-6 w-6 accent-[#55735A]" checked={f.is_published} onChange={(e) => setF({ ...f, is_published: e.target.checked })} /> Published (visible on the site)</label>
      {err && <ErrorNote>{err}</ErrorNote>}
      <div className="flex gap-3"><button className="btn-primary flex-1" disabled={busy}>{busy ? 'Saving…' : 'Save recipe'}</button><button type="button" className="btn-ghost" onClick={() => { setF(null); setErr(null) }}>Cancel</button></div>
    </form>
  )

  return (
    <div>
      <div className="mb-4 flex items-center justify-between"><h1 className="text-[30px]">Recipes</h1><button className="btn-primary btn-sm" onClick={() => setF({ ...blank })}>+ New recipe</button></div>
      {list === null ? <Spinner /> : list.length === 0 ? <Empty emoji="🍳">No recipes yet. Add your first one.</Empty> : (
        <ul className="grid gap-3 md:grid-cols-2">{list.map((r) => (
          <li key={r.id} className="card !p-4"><div className="flex items-start justify-between gap-2"><div><b className="text-[17px]">{r.name}</b><p className="text-[14px] text-brown-soft">{r.category} · {r.minutes} min · {r.difficulty}{!r.is_published && ' · hidden'}</p></div></div>
            <div className="mt-3 flex gap-2"><button className="btn-soft btn-sm" onClick={() => edit(r)}>Edit</button><button className="btn-ghost btn-sm" onClick={() => del(r)}>Delete</button></div></li>
        ))}</ul>
      )}
    </div>
  )
}
