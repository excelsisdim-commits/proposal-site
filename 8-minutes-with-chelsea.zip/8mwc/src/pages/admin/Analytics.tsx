import { useEffect, useState } from 'react'
import { supabase } from '../../lib/supabase'
import { Empty, Spinner } from '../../components/Bits'
import { TYPE_LABEL } from '../../lib/services'
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, AreaChart, Area, PieChart, Pie, Cell, CartesianGrid } from 'recharts'

const COLORS = ['#55735A', '#46657F', '#E0C262', '#8A7563', '#A9BDA5', '#9DB5C8', '#A44A42', '#2B2A27']
const Tile = ({ n, l }: { n: string | number; l: string }) => <div className="rounded-[22px] bg-white/80 p-4 shadow-soft ring-1 ring-brown/10"><div className="font-display text-[30px] leading-none">{n}</div><div className="mt-1 text-[13px] text-brown-soft">{l}</div></div>
const Panel = ({ t, children }: { t: string; children: React.ReactNode }) => <section className="card"><h2 className="mb-3 text-[18px]">{t}</h2><div className="h-56">{children}</div></section>

export default function Analytics() {
  const [a, setA] = useState<any>(null)
  const [err, setErr] = useState(false)
  useEffect(() => { supabase.rpc('admin_analytics').then(({ data, error }) => (error ? setErr(true) : setA(data))) }, [])
  if (err) return <Empty emoji="🔌">Couldn't load analytics.</Empty>
  if (!a) return <Spinner />

  const type = Object.entries(a.by_type as Record<string, number>).map(([k, v]) => ({ name: TYPE_LABEL[k] ?? k, value: v })).sort((x, y) => y.value - x.value)
  const method = Object.entries(a.by_method as Record<string, number>).map(([k, v]) => ({ name: k === 'web' ? 'Website chat' : k === 'snapchat' ? 'Snapchat' : 'WhatsApp', value: v }))
  const anon = [{ name: 'Anonymous', value: a.anonymous }, { name: 'Identified', value: a.identified }]
  const outcomes = [{ name: 'Confirmed', value: a.confirmed + a.completed }, { name: 'Declined', value: a.declined }, { name: 'Pending', value: a.pending }]
  const top = type[0]
  const t = (k: string) => a.by_type[k] ?? 0
  const axis = { stroke: '#8A7563', fontSize: 12 }

  const donut = (data: { name: string; value: number }[]) => (
    <ResponsiveContainer><PieChart><Pie data={data} dataKey="value" nameKey="name" innerRadius={45} outerRadius={80} paddingAngle={2} label={({ name, value }) => (value ? `${name} ${value}` : '')}>
      {data.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}</Pie><Tooltip /></PieChart></ResponsiveContainer>
  )

  return (
    <div className="space-y-6">
      <h1 className="text-[30px]">Stats</h1>
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <Tile n={a.total} l="Total requests" /><Tile n={a.week} l="This week" /><Tile n={a.month} l="Last 30 days" />
        <Tile n={top ? top.name : '—'} l="Most requested" />
        <Tile n={t('midnight')} l="Midnight requests" /><Tile n={a.cook_searches} l="Cooking searches" />
        <Tile n={t('outfit')} l="Outfit requests" /><Tile n={t('advice')} l="Advice requests" />
        <Tile n={t('chat') + t('talk')} l="Chat + talk requests" />
        <Tile n={a.avg_response_minutes == null ? '—' : a.avg_response_minutes < 90 ? `${a.avg_response_minutes} min` : `${Math.round(a.avg_response_minutes / 60)} h`} l="Avg response time" />
        <Tile n={`${a.confirmed + a.completed}/${a.declined}`} l="Confirmed / declined" />
        <Tile n={a.little_things_unread} l="Unread little notes" />
      </div>
      <div className="grid gap-4 md:grid-cols-2">
        <Panel t="Requests, last 14 days">
          <ResponsiveContainer><AreaChart data={a.daily}><CartesianGrid strokeDasharray="3 3" stroke="#E9DEC9" /><XAxis dataKey="day" {...axis} interval={2} /><YAxis allowDecimals={false} {...axis} width={28} /><Tooltip />
            <Area type="monotone" dataKey="n" name="Requests" stroke="#55735A" fill="#A9BDA5" fillOpacity={0.5} /></AreaChart></ResponsiveContainer>
        </Panel>
        <Panel t="By service">
          {type.length ? <ResponsiveContainer><BarChart data={type} layout="vertical" margin={{ left: 20 }}><XAxis type="number" allowDecimals={false} {...axis} /><YAxis type="category" dataKey="name" width={110} {...axis} /><Tooltip /><Bar dataKey="value" name="Requests" fill="#46657F" radius={[0, 8, 8, 0]} /></BarChart></ResponsiveContainer> : <Empty emoji="📊">No data yet.</Empty>}
        </Panel>
        <Panel t="Anonymous vs identified">{donut(anon)}</Panel>
        <Panel t="How they want to connect">{method.length ? donut(method) : <Empty emoji="📊">No data yet.</Empty>}</Panel>
        <Panel t="Confirmed vs declined vs pending">{donut(outcomes)}</Panel>
      </div>
    </div>
  )
}
