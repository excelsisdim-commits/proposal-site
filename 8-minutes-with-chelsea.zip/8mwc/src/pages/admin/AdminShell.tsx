import { FormEvent, useEffect, useState } from 'react'
import { Outlet, useLocation } from 'react-router-dom'
import { supabase } from '../../lib/supabase'
import { useAuth } from '../../hooks/useAuth'
import { useUnread } from '../../hooks/useUnread'
import BottomNav from '../../components/BottomNav'
import { IGrid, IList, IChat, IBars, IMore } from '../../components/Icons'
import { ErrorNote, Spinner } from '../../components/Bits'
import type { AvailabilityStatus } from '../../lib/types'

function Login() {
  const { session, isAdmin } = useAuth()
  const [email, setEmail] = useState(''); const [pw, setPw] = useState('')
  const [busy, setBusy] = useState(false); const [err, setErr] = useState<string | null>(null)
  async function go(e: FormEvent) {
    e.preventDefault(); setBusy(true); setErr(null)
    const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password: pw })
    setBusy(false)
    if (error) setErr("That didn't work. Check your email and password.")
  }
  return (
    <main className="mx-auto grid min-h-[100dvh] max-w-sm place-items-center p-5">
      <form onSubmit={go} className="card w-full space-y-4">
        <h1 className="text-[28px]">Dashboard</h1>
        <p className="text-[15px] text-brown-soft">Private. This page is only for Chelsea.</p>
        {session && !isAdmin && <ErrorNote>This account isn't set up as the admin account. Sign in with the admin email.</ErrorNote>}
        <div><label htmlFor="a-email" className="label">Email</label><input id="a-email" className="field" type="email" autoComplete="username" value={email} onChange={(e) => setEmail(e.target.value)} required /></div>
        <div><label htmlFor="a-pw" className="label">Password</label><input id="a-pw" className="field" type="password" autoComplete="current-password" value={pw} onChange={(e) => setPw(e.target.value)} required /></div>
        {err && <ErrorNote>{err}</ErrorNote>}
        <button className="btn-primary w-full" disabled={busy}>{busy ? 'Signing in…' : 'Sign in'}</button>
      </form>
    </main>
  )
}

const STATUSES: { v: AvailabilityStatus; l: string }[] = [
  { v: 'available', l: '🟢 Available' }, { v: 'busy', l: '🟠 Busy' }, { v: 'away', l: '🌙 Away' }, { v: 'offline', l: '⚪ Offline' },
]
export function StatusPicker() {
  const [v, setV] = useState<AvailabilityStatus>('available')
  useEffect(() => { supabase.from('availability').select('status').eq('id', 1).maybeSingle().then(({ data }) => data && setV(data.status as AvailabilityStatus)) }, [])
  async function set(n: AvailabilityStatus) {
    const prev = v; setV(n)
    const { error } = await supabase.from('availability').update({ status: n, updated_at: new Date().toISOString() }).eq('id', 1)
    if (error) setV(prev)
  }
  return (
    <div role="radiogroup" aria-label="My status" className="grid grid-cols-2 gap-2 sm:grid-cols-4">
      {STATUSES.map((s) => (
        <button key={s.v} role="radio" aria-checked={v === s.v} onClick={() => set(s.v)}
          className={`min-h-[48px] rounded-2xl px-3 text-[15px] font-semibold ring-2 transition ${v === s.v ? 'bg-ink text-paper ring-ink' : 'bg-white/70 ring-sand'}`}>{s.l}</button>
      ))}
    </div>
  )
}

export default function AdminShell() {
  const { ready, isAdmin, session } = useAuth()
  const unread = useUnread()
  const { pathname } = useLocation()

  // broadcast "Chelsea is connected" so guests can see 🟢 online (manual status can still override)
  useEffect(() => {
    if (!isAdmin) return
    const ch = supabase.channel('lobby', { config: { presence: { key: 'admin' } } })
    ch.subscribe((s) => { if (s === 'SUBSCRIBED') ch.track({ role: 'admin', at: Date.now() }) })
    return () => { supabase.removeChannel(ch) }
  }, [isAdmin])

  if (!ready) return <Spinner />
  if (!session || !isAdmin) return <Login />

  const inChat = /^\/chelsea\/inbox\/.+/.test(pathname)
  const items = [
    { to: '/chelsea', label: 'Overview', icon: <IGrid />, end: true },
    { to: '/chelsea/requests', label: 'Requests', icon: <IList /> },
    { to: '/chelsea/inbox', label: 'Inbox', icon: <IChat />, badge: unread },
    { to: '/chelsea/analytics', label: 'Stats', icon: <IBars /> },
    { to: '/chelsea/more', label: 'More', icon: <IMore /> },
  ]
  return (
    <div className="min-h-[100dvh]">
      <main className="mx-auto w-full max-w-6xl px-4 pb-32 pt-5 md:pb-16 md:pt-24"><Outlet /></main>
      {!inChat && <BottomNav items={items} />}
      {inChat && <div className="hidden md:block"><BottomNav items={items} /></div>}
    </div>
  )
}
