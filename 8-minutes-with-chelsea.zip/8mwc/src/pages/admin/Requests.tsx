import { useCallback, useEffect, useState } from 'react'
import { supabase } from '../../lib/supabase'
import RequestCard from '../../components/RequestCard'
import { Empty, Spinner } from '../../components/Bits'
import { STATUS_COPY } from '../../lib/services'
import { cx } from '../../lib/util'
import type { AdminRequest } from '../../lib/types'

const FILTERS = ['ALL', 'PENDING', 'CONFIRMED', 'ALTERNATIVE_TIME', 'DECLINED', 'COMPLETED']

export default function Requests() {
  const [rows, setRows] = useState<AdminRequest[] | null>(null)
  const [f, setF] = useState('ALL')
  const [err, setErr] = useState(false)
  const load = useCallback(async () => {
    const { data, error } = await supabase.rpc('admin_requests')
    if (error) return setErr(true)
    setErr(false); setRows((data ?? []) as AdminRequest[])
  }, [])
  useEffect(() => {
    load()
    const ch = supabase.channel('admin-requests').on('postgres_changes', { event: '*', schema: 'public', table: 'requests' }, load).subscribe()
    return () => { supabase.removeChannel(ch) }
  }, [load])

  const shown = (rows ?? []).filter((r) => f === 'ALL' || r.status === f)
  const count = (s: string) => (rows ?? []).filter((r) => s === 'ALL' || r.status === s).length
  return (
    <div>
      <h1 className="mb-4 text-[30px]">Requests</h1>
      <div className="-mx-4 mb-4 flex gap-2 overflow-x-auto px-4 pb-2" role="group" aria-label="Filter by status">
        {FILTERS.map((s) => <button key={s} onClick={() => setF(s)} aria-pressed={f === s} className={cx('chip shrink-0', f === s && 'chip-on')}>{s === 'ALL' ? 'All' : STATUS_COPY[s].label} ({count(s)})</button>)}
      </div>
      {err ? <Empty emoji="🔌">Couldn't load requests. Refresh and try again.</Empty> : rows === null ? <Spinner /> : shown.length === 0 ? (
        <Empty emoji="💧">No one needs you just yet. Go drink some water 😭</Empty>
      ) : <ul className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">{shown.map((r) => <li key={r.id}><RequestCard req={r} admin onChange={load} /></li>)}</ul>}
    </div>
  )
}
