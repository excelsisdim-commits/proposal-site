import { useCallback, useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from '../../lib/supabase'
import { StatusPicker } from './AdminShell'
import RequestCard from '../../components/RequestCard'
import { Empty, Spinner } from '../../components/Bits'
import type { AdminRequest } from '../../lib/types'

const Stat = ({ n, l, to, tone = 'bg-white/80' }: { n: number | string; l: string; to?: string; tone?: string }) => {
  const inner = <><div className="font-display text-[34px] leading-none">{n}</div><div className="mt-1 text-[14px] text-brown-soft">{l}</div></>
  return to ? <Link to={to} className={`rounded-[24px] p-4 shadow-soft ring-1 ring-brown/10 ${tone}`}>{inner}</Link> : <div className={`rounded-[24px] p-4 shadow-soft ring-1 ring-brown/10 ${tone}`}>{inner}</div>
}

export default function Overview() {
  const [a, setA] = useState<any>(null)
  const [reqs, setReqs] = useState<AdminRequest[]>([])
  const [err, setErr] = useState(false)
  const load = useCallback(async () => {
    const [x, y] = await Promise.all([supabase.rpc('admin_analytics'), supabase.rpc('admin_requests')])
    if (x.error || y.error) { setErr(true); return }
    setErr(false); setA(x.data); setReqs((y.data ?? []) as AdminRequest[])
  }, [])
  useEffect(() => {
    load()
    const ch = supabase.channel('admin-overview')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'requests' }, load)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'conversations' }, load)
      .subscribe()
    return () => { supabase.removeChannel(ch) }
  }, [load])

  if (err) return <Empty emoji="🔌">Couldn't load the dashboard. Check the connection and refresh.</Empty>
  if (!a) return <Spinner />
  const upcoming = reqs.filter((r) => r.status === 'CONFIRMED' && r.preferred_at && new Date(r.preferred_at) > new Date()).sort((x, y) => +new Date(x.preferred_at!) - +new Date(y.preferred_at!)).slice(0, 5)
  const fresh = reqs.filter((r) => r.status === 'PENDING').slice(0, 5)

  return (
    <div className="space-y-8">
      <header><h1 className="text-[32px]">Hi Chelsea 🤍</h1><p className="hand mt-1 text-[26px]">Here's who's been looking for you.</p></header>
      <section aria-labelledby="st"><h2 id="st" className="mb-3 text-[20px]">My status</h2><StatusPicker /><p className="mt-2 text-[13px] text-brown-soft">This overrides your usual work hours. "Available" shows 🟢 only while this dashboard is open.</p></section>

      <section className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <Stat n={a.pending} l="Pending requests" to="/chelsea/requests" tone="bg-butter-soft" />
        <Stat n={a.unread_messages} l="Unread messages" to="/chelsea/inbox" tone="bg-dusty-soft" />
        <Stat n={a.confirmed} l="Confirmed" />
        <Stat n={a.upcoming} l="Upcoming" />
        <Stat n={a.active_conversations} l="Active chats (7d)" to="/chelsea/inbox" />
        <Stat n={a.week} l="Requests this week" />
        <Stat n={a.anonymous} l="Anonymous requests" />
        <Stat n={a.little_things_unread} l="Unread little notes" to="/chelsea/notes" tone="bg-sage-soft" />
      </section>

      <section><h2 className="mb-3 text-[22px]">Needs an answer</h2>
        {fresh.length ? <ul className="grid gap-3 md:grid-cols-2">{fresh.map((r) => <li key={r.id}><RequestCard req={r} admin onChange={load} /></li>)}</ul>
          : <Empty emoji="💧">No one needs you just yet. Go drink some water 😭</Empty>}
      </section>
      {upcoming.length > 0 && <section><h2 className="mb-3 text-[22px]">Coming up</h2><ul className="grid gap-3 md:grid-cols-2">{upcoming.map((r) => <li key={r.id}><RequestCard req={r} admin onChange={load} /></li>)}</ul></section>}
    </div>
  )
}
