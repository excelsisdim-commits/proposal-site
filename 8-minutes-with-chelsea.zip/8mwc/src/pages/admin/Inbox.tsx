import { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { supabase } from '../../lib/supabase'
import ChatView from '../../components/ChatView'
import RequestPanel from '../../components/RequestPanel'
import { Empty, Spinner } from '../../components/Bits'
import { TYPE_EMOJI, TYPE_LABEL } from '../../lib/services'
import { cx, timeAgo } from '../../lib/util'
import type { Conversation } from '../../lib/types'

function useWide() {
  const [w, setW] = useState(window.matchMedia('(min-width: 768px)').matches)
  useEffect(() => { const m = window.matchMedia('(min-width: 768px)'); const h = () => setW(m.matches); m.addEventListener('change', h); return () => m.removeEventListener('change', h) }, [])
  return w
}

function Top({ conv }: { conv: Conversation }) {
  const [email, setEmail] = useState<string | null>(null)
  useEffect(() => { supabase.rpc('admin_contact', { p_conv: conv.id }).then(({ data }) => setEmail((data as string) ?? null)) }, [conv.id])
  return (
    <>
      <p className="border-b border-brown/10 bg-paper px-4 py-1.5 text-[13px] text-brown-soft">
        {conv.is_anonymous ? '🕵🏽‍♀️ Anonymous. Contact details are hidden.' : email ? `✉️ ${email}` : 'No email provided'}
      </p>
      <RequestPanel conversationId={conv.id} admin />
    </>
  )
}

export default function Inbox() {
  const { id } = useParams()
  const wide = useWide()
  const [list, setList] = useState<Conversation[] | null>(null)
  const [err, setErr] = useState(false)

  useEffect(() => {
    const load = async () => {
      const { data, error } = await supabase.from('conversations').select('*, requests(status)').order('last_message_at', { ascending: false })
      if (error) return setErr(true)
      setList((data ?? []) as Conversation[])
    }
    load()
    const ch = supabase.channel('admin-inbox').on('postgres_changes', { event: '*', schema: 'public', table: 'conversations' }, load).subscribe()
    return () => { supabase.removeChannel(ch) }
  }, [])

  const current = list?.find((c) => c.id === id)
  const listEl = (
    <div className="space-y-2">
      {err ? <Empty emoji="🔌">Couldn't load your inbox.</Empty> : list === null ? <Spinner /> : list.length === 0 ? (
        <Empty emoji="💧">No one needs you just yet. Go drink some water 😭</Empty>
      ) : list.map((c) => (
        <Link key={c.id} to={`/chelsea/inbox/${c.id}`} className={cx('flex min-h-[68px] items-center gap-3 rounded-2xl p-3 ring-1 ring-brown/10 transition active:scale-[.98]', c.id === id ? 'bg-sage-soft' : 'bg-white/80')}>
          <span className="text-2xl" aria-hidden>{c.is_anonymous ? '🕵🏽‍♀️' : TYPE_EMOJI[c.topic]}</span>
          <span className="min-w-0 flex-1"><b className="block truncate">{c.display_name}</b><span className="block truncate text-[13px] text-brown-soft">{TYPE_LABEL[c.topic]} · {timeAgo(c.last_message_at)}</span></span>
          {c.unread_admin > 0 && <span aria-label={`${c.unread_admin} unread`} className="grid h-6 min-w-[24px] place-items-center rounded-full bg-brick px-1.5 text-[12px] font-bold text-white">{c.unread_admin}</span>}
        </Link>
      ))}
    </div>
  )

  const chat = id && current ? (
    <ChatView key={id} conversationId={id} role="admin" peerName={current.display_name} title={current.display_name}
      status={(here) => (here ? '🟢 In the chat right now' : '⚪ Not in the chat')}
      backTo={wide ? false : '/chelsea/inbox'} embedded={wide} topSlot={<Top conv={current} />} />
  ) : null

  if (!wide) {
    if (id) return list === null ? <Spinner /> : current ? chat : <Empty emoji="🔒">That conversation isn't available.</Empty>
    return <div><h1 className="mb-4 text-[30px]">Inbox</h1>{listEl}</div>
  }
  return (
    <div>
      <h1 className="mb-4 text-[30px]">Inbox</h1>
      <div className="grid grid-cols-[320px,1fr] gap-4" style={{ height: 'calc(100dvh - 11rem)' }}>
        <div className="overflow-y-auto pr-1">{listEl}</div>
        <div className="min-h-0">{chat ?? <Empty emoji="💬">Pick a conversation to open it.</Empty>}</div>
      </div>
    </div>
  )
}
