import { useEffect, useRef, useState } from 'react'
import { Link } from 'react-router-dom'
import { PageHeader } from '../components/Bits'

const QUESTIONS = [
  "What's a smell that instantly takes you back to being a kid?", "If you could only eat one meal for a month, what is it?",
  "What's the most unnecessary thing you own that you'd never get rid of?", "What song do you secretly know every word to?",
  "What's a tiny thing that always makes your day better?", "Which fictional place would you live in?",
  "What's your most irrational fear?", "If your life had a theme song right now, what would it be?",
  "What's the best compliment you've ever received?", "What would your perfect lazy Sunday look like?",
  "What's a hill you will absolutely die on?", "What's the funniest thing that's happened to you this month?",
]
const WYR: [string, string][] = [
  ['Never have to cook again', 'Never have to do laundry again'], ['Always be 10 minutes late', 'Always be 20 minutes early'],
  ['Only whisper', 'Only shout'], ['Know how you die', 'Know when you die'], ['Have no phone for a month', 'Have no music for a month'],
  ['Eat jollof every day', 'Eat pasta every day'], ['Never feel cold again', 'Never feel hungry again'], ['Be able to talk to animals', 'Speak every language'],
]
const CHALLENGES = [
  'Drink a full glass of water. Right now. I will wait.', 'Text someone you love one nice thing about them.', 'Do 10 shoulder rolls and unclench your jaw.',
  'Put on your favourite song and dance for exactly one chorus.', 'Write down 3 things that went okay today. Small counts.', 'Take 5 slow breaths. In through the nose, out through the mouth.',
  'Stand up and stretch like a cat for 30 seconds.', 'Tidy one tiny thing within arm’s reach.',
]
const pick = <T,>(a: T[], not?: T) => { let x: T; do { x = a[Math.floor(Math.random() * a.length)] } while (a.length > 1 && x === not); return x }

function Reaction() {
  const [state, setState] = useState<'idle' | 'wait' | 'go' | 'early' | 'done'>('idle')
  const [ms, setMs] = useState<number | null>(null)
  const [best, setBest] = useState<number | null>(null)
  const t0 = useRef(0); const timer = useRef<number>()
  useEffect(() => () => window.clearTimeout(timer.current), [])
  function start() { setState('wait'); setMs(null); timer.current = window.setTimeout(() => { t0.current = performance.now(); setState('go') }, 1200 + Math.random() * 2500) }
  function tap() {
    if (state === 'wait') { window.clearTimeout(timer.current); setState('early') }
    else if (state === 'go') { const r = Math.round(performance.now() - t0.current); setMs(r); setBest((b) => (b === null ? r : Math.min(b, r))); setState('done') }
    else start()
  }
  const label = { idle: 'Tap to start', wait: 'Wait for green…', go: 'TAP!', early: 'Too early 😭 Tap to retry', done: `${ms} ms. Tap to go again` }[state]
  return (
    <div>
      <button onClick={tap} className={`grid min-h-[140px] w-full place-items-center rounded-[26px] text-[22px] font-bold transition ${state === 'go' ? 'bg-sage-deep text-white' : state === 'wait' ? 'bg-brick/80 text-white' : 'bg-white text-ink ring-2 ring-sand'}`}>{label}</button>
      {best !== null && <p className="mt-2 text-center text-[14px] opacity-75">Your best: {best} ms</p>}
    </div>
  )
}

export default function Distract() {
  const [q, setQ] = useState(() => pick(QUESTIONS))
  const [w, setW] = useState(() => pick(WYR))
  const [c, setC] = useState(() => pick(CHALLENGES))
  const [choice, setChoice] = useState<number | null>(null)
  return (
    <div className="mx-auto max-w-xl space-y-6">
      <PageHeader title="Distract me" emoji="😂" hand="Fine. Let's think about literally anything else." back="/decide" />

      <section className="card">
        <h2 className="text-[20px]">Random question</h2>
        <p className="mt-3 min-h-[3.5rem] text-[20px] leading-snug" aria-live="polite">{q}</p>
        <button className="btn-soft btn-sm mt-3" onClick={() => setQ(pick(QUESTIONS, q))}>Another one</button>
      </section>

      <section className="card">
        <h2 className="text-[20px]">Would you rather…</h2>
        <div className="mt-3 grid gap-2" aria-live="polite">
          {w.map((o, i) => (
            <button key={o} onClick={() => setChoice(i)} className={`min-h-[56px] rounded-2xl px-4 text-left text-[17px] font-semibold ring-2 transition ${choice === i ? 'bg-ink text-paper ring-ink' : 'bg-white ring-sand'}`}>{o}</button>
          ))}
        </div>
        {choice !== null && <p className="hand mt-3 text-[26px]">Bold choice. We need to talk about it.</p>}
        <button className="btn-soft btn-sm mt-3" onClick={() => { setW(pick(WYR, w)); setChoice(null) }}>Next one</button>
      </section>

      <section className="card">
        <h2 className="text-[20px]">Tiny challenge</h2>
        <p className="mt-3 text-[19px] leading-snug" aria-live="polite">{c}</p>
        <button className="btn-soft btn-sm mt-3" onClick={() => setC(pick(CHALLENGES, c))}>Give me a different one</button>
      </section>

      <section className="card">
        <h2 className="mb-3 text-[20px]">Mini game: reaction time</h2>
        <Reaction />
      </section>

      <section className="rounded-[28px] bg-sage-soft p-5 text-center">
        <p className="text-[18px]">Want a real person to distract you?</p>
        <Link to="/s/chat" className="btn-primary mt-3 w-full">Come chat with me ☕</Link>
      </section>
    </div>
  )
}
