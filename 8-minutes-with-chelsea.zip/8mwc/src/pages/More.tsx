import { Link } from 'react-router-dom'
import { PageHeader, Disclaimer } from '../components/Bits'
import { useAuth } from '../hooks/useAuth'
import { useUnread } from '../hooks/useUnread'
import { usePwaInstall, useNotificationPermission } from '../hooks/usePwa'

export default function More() {
  const { isAdmin } = useAuth()
  const unread = useUnread()
  const pwa = usePwaInstall()
  const notif = useNotificationPermission()
  const rows = [
    { to: '/c', e: '💬', t: 'My chats', d: 'Pick up where we left off', badge: unread },
    { to: '/midnight', e: '🌙', t: "It's one of those nights", d: 'For when it’s late and loud in your head' },
    { to: '/little-things', e: '🫶', t: 'Little Things', d: 'Leave me a small note' },
    { to: '/distract', e: '😂', t: 'Distract me', d: 'Games, questions and silly challenges' },
    { to: '/about', e: '☁️', t: 'About Chelsea', d: 'What this little corner is' },
    { to: '/privacy', e: '🔒', t: 'Help & privacy', d: 'How your stuff is kept' },
  ]
  return (
    <div className="mx-auto max-w-xl">
      <PageHeader title="More" back={false} hand="Everything else, in one place." />
      <ul className="space-y-3">
        {rows.map((r) => (
          <li key={r.to}><Link to={r.to} className="card flex min-h-[72px] items-center gap-4 !p-4 transition active:scale-[.98]">
            <span className="text-3xl" aria-hidden>{r.e}</span><span className="flex-1"><b className="block text-[17px]">{r.t}</b><span className="text-[14px] text-brown-soft">{r.d}</span></span>
            {!!r.badge && <span className="grid h-6 min-w-[24px] place-items-center rounded-full bg-brick px-1.5 text-[12px] font-bold text-white" aria-label={`${r.badge} unread`}>{r.badge}</span>}
          </Link></li>
        ))}
        {isAdmin && <li><Link to="/chelsea" className="card flex min-h-[72px] items-center gap-4 !bg-ink !p-4 text-paper"><span className="text-3xl" aria-hidden>🗝️</span><b className="text-[17px]">Dashboard</b></Link></li>}
      </ul>

      <section className="mt-8 space-y-3">
        <h2 className="text-[20px]">Make it feel like an app</h2>
        {pwa.installed ? <p className="text-[15px] text-brown-soft">Already on your home screen 🎉</p>
          : pwa.canInstall ? <button className="btn-primary w-full" onClick={pwa.install}>Add to home screen 📲</button>
          : <p className="text-[15px] text-brown">{pwa.isIOS ? <>On iPhone: tap <b>Share</b> in Safari, then <b>Add to Home Screen</b>.</> : <>Open your browser menu and choose <b>Add to Home screen</b> or <b>Install app</b>.</>}</p>}
        {notif.supported && notif.perm === 'default' && <button className="btn-soft w-full" onClick={notif.ask}>🔔 Turn on notifications</button>}
        {notif.supported && notif.perm === 'granted' && <p className="text-[15px] text-brown-soft">🔔 Notifications are on. Email is still the backup.</p>}
        {notif.supported && notif.perm === 'denied' && <p className="text-[15px] text-brown-soft">Notifications are blocked in your browser settings. Email will still reach you.</p>}
      </section>
      <Disclaimer className="mt-10" />
    </div>
  )
}
