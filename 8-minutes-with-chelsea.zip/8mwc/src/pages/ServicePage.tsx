import { Navigate, useParams } from 'react-router-dom'
import SessionForm from '../components/SessionForm'
import { Disclaimer, PageHeader } from '../components/Bits'
import { SERVICES, ServiceKey } from '../lib/services'
import { Stars, Moon } from '../components/Doodles'
import { useState } from 'react'

const HYPE = [
  "You've survived 100% of your worst days so far. That's a perfect record.",
  "Okay but you actually are that girl/guy/person. Don't make me say it twice.",
  "Whatever's coming, you've already shown you can figure things out.",
  "You're allowed to be proud of yourself today. Even for the small stuff.",
  "The version of you that's scared and doing it anyway? Iconic.",
  "You are easier to love than your brain is telling you right now.",
  "Drink water, fix your posture, and walk in like you own the place.",
  "Nobody else has your exact brain. That's the whole flex.",
]
function HypeNow() {
  const [i, setI] = useState<number | null>(null)
  return (
    <div className="card mb-8 text-center">
      <p className="text-[15px] text-brown-soft">Need one right this second?</p>
      {i !== null && <p className="my-3 font-display text-[22px] leading-snug" aria-live="polite">{HYPE[i]}</p>}
      <button className="btn-soft btn-sm" onClick={() => setI((p) => { let n; do { n = Math.floor(Math.random() * HYPE.length) } while (n === p); return n })}>
        {i === null ? 'Hype me right now 🎀' : 'Another one'}
      </button>
    </div>
  )
}

export default function ServicePage({ forced }: { forced?: ServiceKey }) {
  const params = useParams()
  const key = (forced ?? params.service) as ServiceKey
  const s = SERVICES[key]
  if (!s) return <Navigate to="/talk" replace />
  return (
    <div className="mx-auto max-w-xl">
      <PageHeader title={s.title} emoji={s.emoji} hand={s.tagline} back={key === 'outfit' || key === 'decide' ? '/decide' : '/talk'} />
      {key === 'hype' && <HypeNow />}
      <SessionForm service={s} />
      <Disclaimer className="mt-10" />
    </div>
  )
}

export function MidnightPage() {
  const s = SERVICES.midnight
  return (
    <div className="relative mx-auto max-w-xl">
      <Stars n={22} />
      <div className="relative">
        <Moon className="mb-3 text-butter" size={40} />
        <h1 className="text-[34px] leading-tight">It's one of those nights?</h1>
        <div className="mt-5 space-y-1 text-[20px] leading-snug opacity-95" style={{ fontFamily: 'inherit' }}>
          <p>It's late.</p><p>You're overthinking.</p><p>You want to cry.</p>
          <p>You don't need advice.</p><p>You just need somebody there.</p>
        </div>
        <p className="hand mt-6 text-[30px] text-butter">Come sit with me.</p>
        <p className="mt-2 text-[16px] opacity-75">You don't have to explain everything. 🤍</p>
        <div className="mt-8"><SessionForm service={s} /></div>
        <p className="mt-10 text-[13px] leading-relaxed opacity-70">
          I'm here to listen, chat and give my two cents when you want it. I'm not a therapist or emergency service. If you're in immediate danger or need urgent professional help, please contact someone who can help you right away.
        </p>
      </div>
    </div>
  )
}
