import { lazy, Suspense, useEffect } from 'react'
import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom'
import { AuthProvider } from './hooks/useAuth'
import { configured } from './lib/supabase'
import SetupNeeded from './components/SetupNeeded'
import Layout from './components/Layout'
import { Spinner } from './components/Bits'
import Home from './pages/Home'
import { TalkHub, DecideHub } from './pages/Hubs'
import ServicePage, { MidnightPage } from './pages/ServicePage'
import Conversation from './pages/Conversation'
import MyChats from './pages/MyChats'
import More from './pages/More'
import About from './pages/About'
import Privacy from './pages/Privacy'
import AdminShell from './pages/admin/AdminShell'
import Overview from './pages/admin/Overview'
import Requests from './pages/admin/Requests'
import Inbox from './pages/admin/Inbox'
import Notes from './pages/admin/Notes'
import Settings, { AdminMore } from './pages/admin/Settings'

// heavier pages load only when visited (keeps the first load small on slow connections)
const Cook = lazy(() => import('./pages/Cook'))
const Recipe = lazy(() => import('./pages/Recipe'))
const Distract = lazy(() => import('./pages/Distract'))
const LittleThings = lazy(() => import('./pages/LittleThings'))
const Analytics = lazy(() => import('./pages/admin/Analytics'))
const RecipesAdmin = lazy(() => import('./pages/admin/RecipesAdmin'))

export default function App() {
  useEffect(() => { if ('serviceWorker' in navigator && import.meta.env.PROD) navigator.serviceWorker.register('/sw.js').catch(() => {}) }, [])
  if (!configured) return <SetupNeeded />
  return (
    <AuthProvider>
      <BrowserRouter>
        <Suspense fallback={<Spinner />}>
          <Routes>
            <Route element={<Layout />}>
              <Route index element={<Home />} />
              <Route path="talk" element={<TalkHub />} />
              <Route path="decide" element={<DecideHub />} />
              <Route path="s/:service" element={<ServicePage />} />
              <Route path="midnight" element={<MidnightPage />} />
              <Route path="distract" element={<Distract />} />
              <Route path="cook" element={<Cook />} />
              <Route path="cook/:id" element={<Recipe />} />
              <Route path="little-things" element={<LittleThings />} />
              <Route path="c" element={<MyChats />} />
              <Route path="more" element={<More />} />
              <Route path="about" element={<About />} />
              <Route path="privacy" element={<Privacy />} />
            </Route>
            {/* full-screen chat: no bottom nav */}
            <Route path="c/:id" element={<Conversation />} />
            {/* Chelsea only: the UI gates it, Postgres row-level security enforces it */}
            <Route path="chelsea" element={<AdminShell />}>
              <Route index element={<Overview />} />
              <Route path="requests" element={<Requests />} />
              <Route path="inbox" element={<Inbox />} />
              <Route path="inbox/:id" element={<Inbox />} />
              <Route path="analytics" element={<Analytics />} />
              <Route path="recipes" element={<RecipesAdmin />} />
              <Route path="notes" element={<Notes />} />
              <Route path="settings" element={<Settings />} />
              <Route path="more" element={<AdminMore />} />
            </Route>
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </Suspense>
      </BrowserRouter>
    </AuthProvider>
  )
}
