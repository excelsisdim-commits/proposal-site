export type ServiceKey = 'talk' | 'advice' | 'outfit' | 'decide' | 'hype' | 'distract' | 'chat' | 'midnight'

export interface Service {
  key: ServiceKey
  emoji: string
  title: string
  tagline: string
  intro?: string
  subtypeLabel?: string
  subtypes: string[]
  allowCalls: boolean
  allowImages: boolean
  maxImages: number
  placeholder: string
  loading: string
  tint: string
}

export const LINKS = {
  snapchat: 'https://snapchat.com/t/fZAWO8e2',
  whatsapp: 'https://wa.link/uear6v',
}

export const DISCLAIMER =
  "I'm here to listen, chat and give my two cents when you want it. I'm not a therapist or emergency service. If you're in immediate danger or need urgent professional help, please contact someone who can help you right away."

export const SERVICES: Record<ServiceKey, Service> = {
  talk: {
    key: 'talk', emoji: '🫂', title: 'I need to talk', tint: 'bg-sage-soft',
    tagline: "You don't have to make it make sense. Just tell me.",
    subtypeLabel: 'What kind of talk?',
    subtypes: ['I need to vent', 'I need someone to listen', 'I had a bad day', "I'm overwhelmed", 'Just sit with me for a bit'],
    allowCalls: true, allowImages: false, maxImages: 0,
    placeholder: "Start anywhere. It doesn't have to be in order.", loading: "waittt, I'm coming 😭",
  },
  advice: {
    key: 'advice', emoji: '💗', title: 'I need advice', tint: 'bg-butter-soft',
    tagline: 'Okay. Tell me EVERYTHING.',
    subtypeLabel: 'What is it about?',
    subtypes: ['Relationship advice', 'Friendship problems', 'Family situations', 'School', 'Work', 'Life decisions', 'General advice', "I genuinely don't know what to do"],
    allowCalls: true, allowImages: false, maxImages: 0,
    placeholder: 'Give me the full story. Who, what, and how you feel about it.', loading: "waittt, I'm coming 😭",
  },
  outfit: {
    key: 'outfit', emoji: '👗', title: 'Pick my outfit', tint: 'bg-dusty-soft',
    tagline: 'Handing this over to the fashion department...',
    subtypeLabel: 'Where are you going?',
    subtypes: ['Going out', 'Class or work', 'A date', 'An event', 'Just everyday'],
    allowCalls: true, allowImages: true, maxImages: 6,
    placeholder: 'Tell me the vibe, the weather, who will be there. Which options are you torn between?', loading: 'Handing this over to the fashion department...',
  },
  decide: {
    key: 'decide', emoji: '💄', title: 'Help me decide', tint: 'bg-sand',
    tagline: "Can't choose? Good. That's my job.",
    subtypeLabel: 'What are we deciding?',
    subtypes: ['Hair', 'Makeup', 'Nails', 'Perfume', 'Outfit', 'Which photo to post', 'What to eat', 'What to buy', 'What to watch', 'Something else'],
    allowCalls: false, allowImages: true, maxImages: 6,
    placeholder: 'What are your options? Tell me what you like and don’t like about each one.', loading: 'Let me look properly...',
  },
  hype: {
    key: 'hype', emoji: '🎀', title: 'Hype me up', tint: 'bg-butter-soft',
    tagline: "Okay. I'm getting the pom-poms.",
    subtypeLabel: 'What do you need?',
    subtypes: ['Hype me up', 'I need motivation', 'I need confidence', 'Tell me something nice', 'I had a horrible day', 'I need encouragement'],
    allowCalls: false, allowImages: false, maxImages: 0,
    placeholder: "What's coming up, or what happened? Give me something to work with.", loading: 'Warming up the pom-poms...',
  },
  distract: {
    key: 'distract', emoji: '😂', title: 'Distract me', tint: 'bg-sage-soft',
    tagline: 'Fine. Let’s think about literally anything else.',
    subtypes: [], allowCalls: false, allowImages: false, maxImages: 0,
    placeholder: 'Tell me what you want to be distracted from, or just say hi.', loading: 'Finding something silly...',
  },
  chat: {
    key: 'chat', emoji: '☕', title: 'Just chat', tint: 'bg-dusty-soft',
    tagline: "You don't need a reason. Come talk to me.",
    intro: "You don't know what you need? That's okay.",
    subtypes: [], allowCalls: true, allowImages: false, maxImages: 0,
    placeholder: 'Say hi. Or tell me about your day. Or anything.', loading: "waittt, I'm coming 😭",
  },
  midnight: {
    key: 'midnight', emoji: '🌙', title: "It's one of those nights", tint: 'bg-night',
    tagline: "You don't have to explain everything. 🤍",
    subtypeLabel: 'What do you need tonight?',
    subtypes: ['I need someone to listen', 'I need to get something off my chest', 'I just want to cry', 'I want advice', "I don't even know"],
    allowCalls: true, allowImages: false, maxImages: 0,
    placeholder: 'You can type it all out, even if it’s messy. I’ll read every word.', loading: "I'm here. One second.",
  },
}

export const TYPE_LABEL: Record<string, string> = Object.fromEntries(Object.values(SERVICES).map((s) => [s.key, s.title]))
export const TYPE_EMOJI: Record<string, string> = Object.fromEntries(Object.values(SERVICES).map((s) => [s.key, s.emoji]))

export const METHOD_LABEL = { web: '💬 Website chat', snapchat: '👻 Snapchat', whatsapp: '💚 WhatsApp' } as const

export const STATUS_COPY: Record<string, { label: string; icon: string; tone: string }> = {
  PENDING: { label: 'Pending', icon: '⏳', tone: 'bg-butter-soft text-brown' },
  CONFIRMED: { label: 'Confirmed', icon: '✅', tone: 'bg-sage-soft text-sage-deep' },
  ALTERNATIVE_TIME: { label: 'Other time suggested', icon: '🕐', tone: 'bg-dusty-soft text-dusty-deep' },
  DECLINED: { label: 'Declined', icon: '🚫', tone: 'bg-sand text-brown' },
  COMPLETED: { label: 'Completed', icon: '🤍', tone: 'bg-white text-brown ring-1 ring-brown/15' },
}
