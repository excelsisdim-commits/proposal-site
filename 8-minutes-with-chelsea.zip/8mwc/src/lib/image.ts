// Phone-friendly image prep: HEIC → JPEG, honour EXIF rotation, shrink to ~1600px, compress.
export const MAX_RAW_BYTES = 30 * 1024 * 1024
const OK = ['image/jpeg', 'image/png', 'image/webp', 'image/heic', 'image/heif']

export interface PreparedImage { id: string; blob: Blob; url: string; name: string }

export async function prepareImage(file: File, maxEdge = 1600, quality = 0.82): Promise<PreparedImage> {
  const isHeic = /heic|heif/i.test(file.type) || /\.hei[cf]$/i.test(file.name)
  if (!isHeic && !OK.includes(file.type)) throw new Error('That file type is not supported. Use a JPEG, PNG, WebP or HEIC photo.')
  if (file.size > MAX_RAW_BYTES) throw new Error('That photo is too big (30 MB max).')

  let source: Blob = file
  if (isHeic) {
    try {
      const mod: any = await import('heic2any')
      const out = await (mod.default ?? mod)({ blob: file, toType: 'image/jpeg', quality: 0.9 })
      source = Array.isArray(out) ? out[0] : out
    } catch {
      throw new Error("Couldn't read that HEIC photo. Try taking a screenshot of it, or switch your camera to 'Most Compatible'.")
    }
  }

  const bmp = await loadBitmap(source)
  const scale = Math.min(1, maxEdge / Math.max(bmp.w, bmp.h))
  const w = Math.round(bmp.w * scale), h = Math.round(bmp.h * scale)
  const canvas = document.createElement('canvas')
  canvas.width = w; canvas.height = h
  const ctx = canvas.getContext('2d')!
  ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, w, h)
  ctx.drawImage(bmp.src as CanvasImageSource, 0, 0, w, h)
  ;(bmp.src as any).close?.()
  const blob: Blob = await new Promise((res, rej) => canvas.toBlob((b) => (b ? res(b) : rej(new Error('compress failed'))), 'image/jpeg', quality))
  if (blob.size > 5 * 1024 * 1024) throw new Error('That photo is still too large after shrinking. Try a different one.')
  return { id: Math.random().toString(36).slice(2), blob, url: URL.createObjectURL(blob), name: file.name.replace(/\.[^.]+$/, '') + '.jpg' }
}

async function loadBitmap(blob: Blob): Promise<{ src: ImageBitmap | HTMLImageElement; w: number; h: number }> {
  if ('createImageBitmap' in window) {
    try {
      const b = await createImageBitmap(blob, { imageOrientation: 'from-image' } as any)
      return { src: b, w: b.width, h: b.height }
    } catch { /* fall through */ }
  }
  const url = URL.createObjectURL(blob)
  try {
    const img = await new Promise<HTMLImageElement>((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = () => rej(new Error('Could not read that image.')); i.src = url })
    return { src: img, w: img.naturalWidth, h: img.naturalHeight }
  } finally { URL.revokeObjectURL(url) }
}
