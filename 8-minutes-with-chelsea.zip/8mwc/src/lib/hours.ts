import { supabase } from './supabase'

export interface WorkHour { weekday: number; start_time: string; end_time: string }

// mirrors the seed in the database; the live table (editable) wins when it loads
export const DEFAULT_HOURS: WorkHour[] = [
  { weekday: 1, start_time: '08:00', end_time: '18:00' },
  { weekday: 2, start_time: '08:00', end_time: '18:00' },
  { weekday: 3, start_time: '06:00', end_time: '12:00' },
  { weekday: 4, start_time: '08:00', end_time: '18:00' },
]
const TZ = 'Africa/Lagos'
const DAYS: Record<string, number> = { Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6, Sun: 7 }
const mins = (t: string) => { const [h, m] = t.split(':'); return +h * 60 + +m }

export function inWorkHours(d: Date, hours: WorkHour[] = DEFAULT_HOURS) {
  const parts = new Intl.DateTimeFormat('en-GB', { timeZone: TZ, weekday: 'short', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).formatToParts(d)
  const get = (t: string) => parts.find((p) => p.type === t)?.value ?? ''
  const day = DAYS[get('weekday')]
  const now = +get('hour') * 60 + +get('minute')
  return hours.some((h) => h.weekday === day && now >= mins(h.start_time) && now < mins(h.end_time))
}

let cache: WorkHour[] | null = null
export async function loadWorkHours(): Promise<WorkHour[]> {
  if (cache) return cache
  try {
    const { data } = await supabase.from('work_hours').select('*')
    if (data && data.length) cache = data as WorkHour[]
  } catch { /* fall back to defaults */ }
  return cache ?? DEFAULT_HOURS
}
