export type Role = 'guest' | 'admin'
export type Sender = 'guest' | 'chelsea'
export type RequestStatus = 'PENDING' | 'CONFIRMED' | 'ALTERNATIVE_TIME' | 'DECLINED' | 'COMPLETED'
export type Method = 'web' | 'snapchat' | 'whatsapp'

export interface Conversation {
  id: string
  guest_id: string
  display_name: string
  is_anonymous: boolean
  topic: string
  status: 'open' | 'closed'
  last_message_at: string
  unread_admin: number
  unread_guest: number
  created_at: string
  requests?: RequestRow[]
}
export interface Message {
  id: string
  conversation_id: string
  sender: Sender
  body: string
  attachment_paths: string[]
  client_id: string | null
  created_at: string
  delivered_at: string | null
  read_at: string | null
  _status?: 'sending' | 'failed'
}
export interface RequestRow {
  id: string
  ref: string
  conversation_id: string
  type: string
  subtype: string | null
  contact_method: Method
  preferred_at: string | null
  status: RequestStatus
  suggested_at: string | null
  message: string
  in_work_hours: boolean
  created_at: string
  responded_at: string | null
}
export interface AdminRequest extends RequestRow {
  display_name: string
  is_anonymous: boolean
  unread_admin: number
  email: string | null
}
export interface Ingredient { name: string; qty?: string; staple?: boolean }
export interface Recipe {
  id: string
  name: string
  description: string
  ingredients: Ingredient[]
  steps: string[]
  minutes: number
  difficulty: 'easy' | 'medium' | 'a bit extra'
  category: string
  image_path: string | null
  tags: string[]
  is_published: boolean
}
export interface LittleThing { id: string; prompt: string; body: string; display_name: string | null; is_read: boolean; created_at: string }
export type AvailabilityStatus = 'available' | 'busy' | 'away' | 'offline'
