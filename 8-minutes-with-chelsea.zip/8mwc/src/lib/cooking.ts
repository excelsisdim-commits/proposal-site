import type { Recipe } from './types'

const SYNONYMS: Record<string, string> = {
  indomie: 'noodles', noodle: 'noodles', ramen: 'noodles',
  spaghetti: 'pasta', macaroni: 'pasta', penne: 'pasta',
  tomatoes: 'tomato', tomatoe: 'tomato', 'tomato paste': 'tomato',
  eggs: 'egg', onions: 'onion', peppers: 'pepper', 'scotch bonnet': 'pepper', ata: 'pepper', 'bell pepper': 'pepper', tatashe: 'pepper',
  bananas: 'banana', plantains: 'plantain', 'chicken breast': 'chicken', 'chicken thigh': 'chicken', 'chicken wings': 'chicken',
  'peanut-butter': 'peanut butter', 'cocoa powder': 'cocoa', milo: 'cocoa',
  garlics: 'garlic', 'baking soda': 'baking powder',
}

export function normalize(raw: string): string {
  let s = raw.toLowerCase().replace(/[^a-z\s-]/g, ' ').replace(/\s+/g, ' ').trim()
  if (SYNONYMS[s]) return SYNONYMS[s]
  if (s.endsWith('oes')) s = s.slice(0, -2)
  else if (s.length > 3 && s.endsWith('s') && !s.endsWith('ss')) s = s.slice(0, -1)
  return SYNONYMS[s] ?? s
}

export function parseIngredients(input: string): string[] {
  return Array.from(new Set(input.split(/[,\n;]+|\band\b/i).map(normalize).filter(Boolean)))
}

const STAPLES = ['salt', 'oil', 'water', 'seasoning cube', 'stock cube', 'black pepper', 'vegetable oil', 'curry', 'thyme']

export interface Match { recipe: Recipe; have: string[]; missing: string[]; ratio: number }

export function matchRecipes(recipes: Recipe[], have: string[]): Match[] {
  const mine = have.map(normalize)
  const out: Match[] = []
  for (const r of recipes) {
    const needed = (r.ingredients ?? []).filter((i) => !i.staple && !STAPLES.includes(normalize(i.name)))
    if (!needed.length) continue
    const h: string[] = [], m: string[] = []
    for (const i of needed) {
      const n = normalize(i.name)
      const ok = mine.some((x) => x === n || (x.length > 2 && (n.includes(x) || x.includes(n))))
      ;(ok ? h : m).push(i.name)
    }
    if (h.length) out.push({ recipe: r, have: h, missing: m, ratio: h.length / needed.length })
  }
  return out.sort((a, b) => b.ratio - a.ratio || a.missing.length - b.missing.length || a.recipe.minutes - b.recipe.minutes)
}

export const COMMON_CHIPS = ['chicken', 'rice', 'eggs', 'tomato', 'onion', 'pasta', 'noodles', 'bread', 'plantain', 'cheese', 'garlic', 'milk']
export const CATEGORIES = ['Rice', 'Chicken', 'Pasta', 'Noodles', 'Breakfast', 'Snacks', 'Baking', 'Lazy meals', 'Midnight cravings']
export const CATEGORY_EMOJI: Record<string, string> = {
  Rice: '🍚', Chicken: '🍗', Pasta: '🍝', Noodles: '🍜', Breakfast: '🍳', Snacks: '🥟', Baking: '🍞', 'Lazy meals': '🛋️', 'Midnight cravings': '🌙',
}
