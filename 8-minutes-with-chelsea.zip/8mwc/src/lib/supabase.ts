import { createClient } from '@supabase/supabase-js'

const url = import.meta.env.VITE_SUPABASE_URL as string | undefined
const key = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined

export const configured = Boolean(url && key)
export const SUPABASE_URL = url || ''
export const SUPABASE_KEY = key || ''

export const supabase = createClient(url || 'http://localhost:54321', key || 'missing-key', {
  auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: false },
  realtime: { params: { eventsPerSecond: 10 } },
})

/** Guests get a silent anonymous session the first time they need one. No password, survives refresh. */
export async function ensureSession() {
  const { data } = await supabase.auth.getSession()
  if (data.session) return data.session
  const { data: d, error } = await supabase.auth.signInAnonymously()
  if (error || !d.session) throw error ?? new Error('Could not start a session')
  return d.session
}
