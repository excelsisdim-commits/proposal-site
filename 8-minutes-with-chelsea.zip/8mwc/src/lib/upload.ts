import { supabase, SUPABASE_URL, SUPABASE_KEY } from './supabase'
import { uuid } from './util'

/** Upload with real progress (fetch can't report upload progress, XHR can). Private bucket, random filename. */
export async function uploadChatImage(conversationId: string, blob: Blob, onProgress?: (pct: number) => void): Promise<string> {
  const { data } = await supabase.auth.getSession()
  const token = data.session?.access_token
  if (!token) throw new Error('Not signed in')
  const path = `${conversationId}/${uuid()}.jpg`
  await new Promise<void>((resolve, reject) => {
    const xhr = new XMLHttpRequest()
    xhr.open('POST', `${SUPABASE_URL}/storage/v1/object/chat-attachments/${path}`)
    xhr.setRequestHeader('Authorization', `Bearer ${token}`)
    xhr.setRequestHeader('apikey', SUPABASE_KEY)
    xhr.setRequestHeader('Content-Type', 'image/jpeg')
    xhr.setRequestHeader('x-upsert', 'false')
    xhr.upload.onprogress = (e) => { if (e.lengthComputable) onProgress?.(Math.round((e.loaded / e.total) * 100)) }
    xhr.onload = () => (xhr.status >= 200 && xhr.status < 300 ? resolve() : reject(new Error(`Upload failed (${xhr.status})`)))
    xhr.onerror = () => reject(new Error('Network error while uploading'))
    xhr.ontimeout = () => reject(new Error('Upload timed out'))
    xhr.timeout = 90_000
    xhr.send(blob)
  })
  onProgress?.(100)
  return path
}

const urlCache = new Map<string, { url: string; exp: number }>()
export async function signedUrl(path: string): Promise<string | null> {
  const hit = urlCache.get(path)
  if (hit && hit.exp > Date.now()) return hit.url
  const { data, error } = await supabase.storage.from('chat-attachments').createSignedUrl(path, 3600)
  if (error || !data) return null
  urlCache.set(path, { url: data.signedUrl, exp: Date.now() + 50 * 60_000 })
  return data.signedUrl
}

export async function uploadRecipeImage(blob: Blob): Promise<string> {
  const path = `${uuid()}.jpg`
  const { error } = await supabase.storage.from('recipe-images').upload(path, blob, { contentType: 'image/jpeg' })
  if (error) throw error
  return path
}
export const recipeImageUrl = (path: string | null) =>
  path ? supabase.storage.from('recipe-images').getPublicUrl(path).data.publicUrl : null
