import { useCallback, useEffect, useRef, useState } from 'react'
import { supabase } from '../lib/supabase'
import { uuid } from '../lib/util'
import type { Message, Role } from '../lib/types'
import { notifyPeerMessage } from './usePwa'

export type Connection = 'connecting' | 'live' | 'reconnecting' | 'offline'
const PAGE = 60

const byTime = (a: Message, b: Message) => +new Date(a.created_at) - +new Date(b.created_at)

/**
 * Real-time chat for one conversation.
 *  - Messages are written to Postgres first, then streamed back by Realtime → persistent, refresh-safe.
 *  - Typing + presence ride on a Realtime channel (ephemeral, never stored).
 *  - Delivered/read are set by server functions that only touch the OTHER person's messages.
 */
export function useChat(conversationId: string, role: Role) {
  const mySender = role === 'admin' ? 'chelsea' : 'guest'
  const [messages, setMessages] = useState<Message[]>([])
  const [loading, setLoading] = useState(true)
  const [loadError, setLoadError] = useState<string | null>(null)
  const [hasMore, setHasMore] = useState(false)
  const [connection, setConnection] = useState<Connection>('connecting')
  const [peerTyping, setPeerTyping] = useState(false)
  const [peerHere, setPeerHere] = useState(false)
  const chRef = useRef<ReturnType<typeof supabase.channel> | null>(null)
  const typingTimer = useRef<number>()
  const lastTypingSent = useRef(0)
  const messagesRef = useRef<Message[]>([])
  messagesRef.current = messages

  const merge = useCallback((incoming: Message[]) => {
    setMessages((prev) => {
      const map = new Map<string, Message>()
      for (const m of prev) map.set(m.client_id ?? m.id, m)
      for (const m of incoming) {
        const k = m.client_id ?? m.id
        map.set(k, { ...(map.get(k) ?? {}), ...m, _status: undefined })
      }
      return Array.from(map.values()).sort(byTime)
    })
  }, [])

  const fetchLatest = useCallback(async () => {
    const { data, error } = await supabase.from('messages').select('*')
      .eq('conversation_id', conversationId).order('created_at', { ascending: false }).limit(PAGE)
    if (error) throw error
    const rows = ((data ?? []) as Message[]).reverse()
    merge(rows)
    return rows
  }, [conversationId, merge])

  // initial load
  useEffect(() => {
    let alive = true
    setLoading(true); setLoadError(null); setMessages([])
    fetchLatest()
      .then((rows) => { if (alive) { setHasMore(rows.length === PAGE); setLoading(false) } })
      .catch(() => { if (alive) { setLoadError("Couldn't load this conversation."); setLoading(false) } })
    return () => { alive = false }
  }, [conversationId, fetchLatest])

  const loadEarlier = useCallback(async () => {
    const first = messagesRef.current.find((m) => !m._status)
    if (!first) return
    const { data } = await supabase.from('messages').select('*').eq('conversation_id', conversationId)
      .lt('created_at', first.created_at).order('created_at', { ascending: false }).limit(PAGE)
    const rows = ((data ?? []) as Message[]).reverse()
    merge(rows)
    setHasMore((data ?? []).length === PAGE)
  }, [conversationId, merge])

  // realtime channel
  useEffect(() => {
    const ch = supabase.channel(`conv:${conversationId}`, { config: { presence: { key: role }, broadcast: { self: false } } })
    chRef.current = ch
    ch.on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages', filter: `conversation_id=eq.${conversationId}` }, (p) => {
      const m = p.new as Message
      merge([m])
      if (m.sender !== mySender) {
        setPeerTyping(false)
        notifyPeerMessage(role === 'admin' ? 'New message 💬' : 'Chelsea replied 💬', location.pathname)
      }
    })
    ch.on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'messages', filter: `conversation_id=eq.${conversationId}` }, (p) => merge([p.new as Message]))
    ch.on('broadcast', { event: 'typing' }, ({ payload }) => {
      if (payload?.role === role) return
      setPeerTyping(true)
      window.clearTimeout(typingTimer.current)
      typingTimer.current = window.setTimeout(() => setPeerTyping(false), 3000)
    })
    ch.on('presence', { event: 'sync' }, () => {
      const keys = Object.keys(ch.presenceState())
      setPeerHere(keys.includes(role === 'admin' ? 'guest' : 'admin'))
    })
    ch.subscribe(async (status) => {
      if (status === 'SUBSCRIBED') {
        setConnection('live')
        await ch.track({ role, at: Date.now() })
        fetchLatest().catch(() => {})   // catch up on anything missed while disconnected
      } else if (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT') setConnection('reconnecting')
      else if (status === 'CLOSED') setConnection(navigator.onLine ? 'reconnecting' : 'offline')
    })
    const goOffline = () => setConnection('offline')
    const goOnline = () => setConnection('reconnecting')
    window.addEventListener('offline', goOffline); window.addEventListener('online', goOnline)
    return () => {
      window.removeEventListener('offline', goOffline); window.removeEventListener('online', goOnline)
      window.clearTimeout(typingTimer.current)
      supabase.removeChannel(ch); chRef.current = null
    }
  }, [conversationId, role, mySender, merge, fetchLatest])

  // delivered + read receipts
  const receiptTimer = useRef<number>()
  const syncReceipts = useCallback(() => {
    const incoming = messagesRef.current.filter((m) => m.sender !== mySender && !m._status)
    if (!incoming.length) return
    if (incoming.some((m) => !m.delivered_at)) supabase.rpc('mark_delivered', { p_conv: conversationId }).then(() => {})
    const visible = document.visibilityState === 'visible' && document.hasFocus()
    if (visible && incoming.some((m) => !m.read_at)) {
      window.clearTimeout(receiptTimer.current)
      receiptTimer.current = window.setTimeout(() => supabase.rpc('mark_read', { p_conv: conversationId }).then(() => {}), 350)
    }
  }, [conversationId, mySender])

  useEffect(() => { syncReceipts() }, [messages, syncReceipts])
  useEffect(() => {
    const h = () => syncReceipts()
    document.addEventListener('visibilitychange', h); window.addEventListener('focus', h)
    return () => { document.removeEventListener('visibilitychange', h); window.removeEventListener('focus', h) }
  }, [syncReceipts])

  // send / retry
  const insert = useCallback(async (m: Message) => {
    const { data, error } = await supabase.from('messages').insert({
      conversation_id: conversationId, sender: mySender, body: m.body, attachment_paths: m.attachment_paths, client_id: m.client_id,
    }).select().single()
    if (error) {
      if ((error as any).code === '23505') { await fetchLatest(); return }   // already saved (retry after flaky network)
      throw error
    }
    merge([data as Message])
  }, [conversationId, mySender, merge, fetchLatest])

  const markFailed = (cid: string) => setMessages((p) => p.map((x) => (x.client_id === cid ? { ...x, _status: 'failed' } : x)))

  const send = useCallback(async (body: string, attachment_paths: string[] = []) => {
    const text = body.trim()
    if (!text && !attachment_paths.length) return
    const client_id = uuid()
    const local: Message = {
      id: client_id, client_id, conversation_id: conversationId, sender: mySender, body: text, attachment_paths,
      created_at: new Date().toISOString(), delivered_at: null, read_at: null, _status: 'sending',
    }
    setMessages((p) => [...p, local].sort(byTime))
    try { await insert(local) } catch { markFailed(client_id) }
  }, [conversationId, mySender, insert])

  const retry = useCallback(async (client_id: string) => {
    const m = messagesRef.current.find((x) => x.client_id === client_id)
    if (!m) return
    setMessages((p) => p.map((x) => (x.client_id === client_id ? { ...x, _status: 'sending' } : x)))
    try { await insert(m) } catch { markFailed(client_id) }
  }, [insert])

  // auto-retry failed messages when the connection comes back
  useEffect(() => {
    const h = () => messagesRef.current.filter((m) => m._status === 'failed').forEach((m) => retry(m.client_id!))
    window.addEventListener('online', h)
    return () => window.removeEventListener('online', h)
  }, [retry])

  const sendTyping = useCallback(() => {
    const now = Date.now()
    if (now - lastTypingSent.current < 1500) return
    lastTypingSent.current = now
    chRef.current?.send({ type: 'broadcast', event: 'typing', payload: { role } })
  }, [role])

  return { messages, loading, loadError, hasMore, loadEarlier, connection, peerTyping, peerHere, send, retry, sendTyping, mySender }
}
