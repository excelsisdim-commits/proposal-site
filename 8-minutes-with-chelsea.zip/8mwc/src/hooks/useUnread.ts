import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'
import { useAuth } from './useAuth'

/** Total unread messages across your conversations (guest) or all conversations (Chelsea). Live. */
export function useUnread(): number {
  const { session, isAdmin, ready } = useAuth()
  const [n, setN] = useState(0)
  useEffect(() => {
    if (!session || !ready) { setN(0); return }
    let alive = true
    const col = isAdmin ? 'unread_admin' : 'unread_guest'
    const load = async () => {
      const { data } = await supabase.from('conversations').select(col)
      if (alive) setN((data ?? []).reduce((a: number, r: any) => a + (r[col] ?? 0), 0))
    }
    load()
    const ch = supabase.channel(`unread-${session.user.id}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'conversations' }, load)
      .subscribe()
    return () => { alive = false; supabase.removeChannel(ch) }
  }, [session?.user.id, isAdmin, ready])
  return n
}
