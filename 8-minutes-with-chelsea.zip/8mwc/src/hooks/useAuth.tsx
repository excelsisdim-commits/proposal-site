import { createContext, useContext, useEffect, useState, ReactNode } from 'react'
import type { Session } from '@supabase/supabase-js'
import { supabase } from '../lib/supabase'
import type { Role } from '../lib/types'

interface Ctx { session: Session | null; role: Role | null; ready: boolean; isAdmin: boolean }
const AuthCtx = createContext<Ctx>({ session: null, role: null, ready: false, isAdmin: false })

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null)
  const [role, setRole] = useState<Role | null>(null)
  const [ready, setReady] = useState(false)

  useEffect(() => {
    let alive = true
    supabase.auth.getSession().then(({ data }) => { if (alive) { setSession(data.session); if (!data.session) setReady(true) } })
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => { setSession(s); if (!s) { setRole(null); setReady(true) } })
    return () => { alive = false; sub.subscription.unsubscribe() }
  }, [])

  useEffect(() => {
    if (!session) return
    let alive = true
    setReady(false)
    supabase.from('profiles').select('role').eq('id', session.user.id).maybeSingle().then(({ data }) => {
      if (!alive) return
      setRole((data?.role as Role) ?? 'guest')
      setReady(true)
    })
    return () => { alive = false }
  }, [session?.user.id])

  return <AuthCtx.Provider value={{ session, role, ready, isAdmin: role === 'admin' }}>{children}</AuthCtx.Provider>
}
export const useAuth = () => useContext(AuthCtx)
