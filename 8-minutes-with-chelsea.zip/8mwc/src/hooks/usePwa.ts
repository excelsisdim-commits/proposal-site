import { useEffect, useState, useCallback } from 'react'

export function usePwaInstall() {
  const [evt, setEvt] = useState<any>(null)
  const [installed, setInstalled] = useState(window.matchMedia?.('(display-mode: standalone)').matches || (navigator as any).standalone === true)
  useEffect(() => {
    const onPrompt = (e: Event) => { e.preventDefault(); setEvt(e) }
    const onInstalled = () => { setInstalled(true); setEvt(null) }
    window.addEventListener('beforeinstallprompt', onPrompt)
    window.addEventListener('appinstalled', onInstalled)
    return () => { window.removeEventListener('beforeinstallprompt', onPrompt); window.removeEventListener('appinstalled', onInstalled) }
  }, [])
  const install = useCallback(async () => { if (!evt) return; evt.prompt(); await evt.userChoice; setEvt(null) }, [evt])
  const isIOS = /iphone|ipad|ipod/i.test(navigator.userAgent)
  return { canInstall: !!evt, install, installed, isIOS }
}

export function useNotificationPermission() {
  const supported = typeof Notification !== 'undefined'
  const [perm, setPerm] = useState<NotificationPermission>(supported ? Notification.permission : 'denied')
  const ask = useCallback(async () => { if (!supported) return; setPerm(await Notification.requestPermission()) }, [supported])
  return { supported, perm, ask }
}

/** Show a quiet system notification when the tab is in the background. Email stays the reliable fallback. */
export async function notifyPeerMessage(title: string, url: string) {
  if (typeof Notification === 'undefined' || Notification.permission !== 'granted' || document.visibilityState === 'visible') return
  try {
    const reg = await navigator.serviceWorker?.getRegistration()
    if (reg) await reg.showNotification(title, { body: 'Open your conversation', icon: '/icon-192.png', tag: url, data: { url } })
    else new Notification(title, { body: 'Open your conversation', icon: '/icon-192.png' })
  } catch { /* ignore */ }
}

/** Keep the chat the size of the *visible* viewport so the mobile keyboard never covers the composer. */
export function useVisualViewportHeight() {
  useEffect(() => {
    const vv = window.visualViewport
    const set = () => {
      const h = vv ? vv.height : window.innerHeight
      document.documentElement.style.setProperty('--vvh', `${h}px`)
      if (vv && vv.offsetTop) window.scrollTo(0, 0)
    }
    set()
    vv?.addEventListener('resize', set)
    vv?.addEventListener('scroll', set)
    window.addEventListener('orientationchange', set)
    return () => {
      vv?.removeEventListener('resize', set); vv?.removeEventListener('scroll', set)
      window.removeEventListener('orientationchange', set)
      document.documentElement.style.setProperty('--vvh', '100dvh')
    }
  }, [])
}

export function useOnline() {
  const [on, setOn] = useState(navigator.onLine)
  useEffect(() => {
    const a = () => setOn(true), b = () => setOn(false)
    window.addEventListener('online', a); window.addEventListener('offline', b)
    return () => { window.removeEventListener('online', a); window.removeEventListener('offline', b) }
  }, [])
  return on
}
