import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'
import type { AvailabilityStatus } from '../lib/types'

export interface ChelseaStatus { icon: string; label: string; online: boolean; manual: AvailabilityStatus }

/** Presence (is she actually connected?) + manual override (Busy/Away/Offline wins). */
export function useChelseaStatus(): ChelseaStatus {
  const [manual, setManual] = useState<AvailabilityStatus>('available')
  const [connected, setConnected] = useState(false)

  useEffect(() => {
    let alive = true
    supabase.from('availability').select('status').eq('id', 1).maybeSingle().then(({ data }) => { if (alive && data) setManual(data.status as AvailabilityStatus) })
    const ch = supabase.channel('lobby')
      .on('presence', { event: 'sync' }, () => {
        const state = ch.presenceState() as Record<string, any[]>
        setConnected(Object.values(state).some((arr) => arr.some((p) => p.role === 'admin')))
      })
      .subscribe()
    const av = supabase.channel('availability-watch')
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'availability' }, (p) => setManual((p.new as any).status))
      .subscribe()
    return () => { alive = false; supabase.removeChannel(ch); supabase.removeChannel(av) }
  }, [])

  if (manual === 'busy') return { icon: '🟠', label: 'Chelsea is busy', online: false, manual }
  if (manual === 'away') return { icon: '🌙', label: 'Chelsea is away', online: false, manual }
  if (manual === 'offline') return { icon: '⚪', label: 'Chelsea is offline', online: false, manual }
  return connected
    ? { icon: '🟢', label: 'Chelsea is online', online: true, manual }
    : { icon: '⚪', label: 'Chelsea is offline', online: false, manual }
}
