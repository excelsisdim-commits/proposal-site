# 8 Minutes With Chelsea

A mobile-first PWA: real-time chat, request scheduling, outfit/decision photo uploads, an ingredient-based recipe finder, a Midnight page, Little Things notes, and a private admin dashboard with analytics.

**Stack:** React + Vite + TypeScript + Tailwind · Supabase (Postgres, Auth, Realtime, Storage, Edge Functions) · Resend (email).

> **Honest status:** this was written without the ability to install packages or run a live Supabase in the environment it was built in. The SQL, Edge Function and TypeScript were syntax-checked, but the app has **not** been run end-to-end. Follow the test checklist at the bottom after setup, and expect to fix a small typo or two.

---

## 1. Create the Supabase project
1. https://supabase.com → New project (free tier is fine).
2. **Project Settings → API**: copy the *Project URL* and the *anon public* key.

## 2. Run the database migrations (in order)
SQL Editor → paste and run each file in `supabase/migrations/`:
`0001_schema.sql` → `0002_functions.sql` → `0003_rls.sql` → `0004_storage.sql` → `0005_seed.sql`
(`0006_config_template.sql` comes later, step 5.)

## 3. Auth settings (Authentication → Sign In / Providers)
- Turn **Anonymous sign-ins ON** (guests use these, no password).
- Recommended: enable CAPTCHA protection (Authentication → Attack Protection) to stop bots creating anonymous users.
- Authentication → URL Configuration: set *Site URL* to your deployed site.

## 4. Create Chelsea's admin account
1. Authentication → Users → **Add user** → her email + a strong password → tick *Auto confirm*.
2. SQL Editor:
```sql
update public.profiles set role = 'admin'
where id = (select id from auth.users where email = 'excelsisdim@gmail.com');
```
3. Sign in at `/chelsea`. Nobody can become admin from the browser: roles can only be changed in SQL like this, and every admin table/function checks it in Postgres.

## 5. Email notifications (Resend + Edge Function)
1. Create an account at https://resend.com and an API key.
   - **Without a verified domain Resend only delivers to your own address.** To email guests, verify a domain in Resend and use e.g. `hello@yourdomain.com` as the sender.
2. Install the Supabase CLI, then:
```bash
supabase login
supabase link --project-ref YOUR-PROJECT-REF
supabase secrets set RESEND_API_KEY=re_xxx \
  FROM_EMAIL="8 Minutes With Chelsea <hello@yourdomain.com>" \
  ADMIN_EMAIL=excelsisdim@gmail.com \
  SITE_URL=https://your-site.com \
  WEBHOOK_SECRET=$(openssl rand -hex 24)
supabase functions deploy notify --no-verify-jwt
```
3. Edit `supabase/migrations/0006_config_template.sql`: your project ref + **the same WEBHOOK_SECRET**, then run it in the SQL editor. (This tells Postgres where to POST when a request/message is created.)
4. Test: submit a request on the site → Chelsea's inbox gets "💌 Someone wants to sit with you". Failures are logged in the `notifications` table (`status = 'failed'`, with the reason).

Emails sent: new request (to Chelsea + confirmation to guest if they gave an email), request confirmed / other time suggested / declined (to guest), new chat message (to Chelsea, **no message content**, throttled to once per 10 min per chat), Chelsea replied (to guest, throttled), new Little Thing (to Chelsea).

## 6. Run locally
```bash
cp .env.example .env     # fill in VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY
npm install
npm run dev
```
Open it on your phone via the LAN URL Vite prints (or deploy and open the real URL).

## 7. Deploy
Vercel or Netlify: import the repo, build command `npm run build`, output `dist`, add the two `VITE_…` env vars. SPA rewrites are already included (`vercel.json`, `public/_redirects`). Only the **anon** key goes in the frontend. The service-role key never leaves Supabase.

---

## Architecture notes
- **Chat:** every message is inserted into Postgres, Realtime streams it to the other side, so it survives refresh. `client_id` makes retries idempotent. Failed sends show *Try again* and auto-retry when the connection returns. Reconnect refetches missed messages.
- **Presence:** the admin dashboard joins a `lobby` presence channel; guests read it. Chelsea's manual status (Busy/Away/Offline) overrides it.
- **Typing:** Realtime broadcast (never stored). **Receipts:** `mark_delivered` / `mark_read` SQL functions; ✓ sent, ✓✓ delivered, ✓✓ blue + "Read".
- **Anonymity:** the guest's email lives in `contact_private`, which no browser can read. The dashboard shows "Anonymous" and hides the email for anonymous requests.
- **Returning from email:** the email button carries a secret one-time-style token; `claim_conversation` attaches the conversation to that device's session.
- **Photos:** private bucket, `conversation_id/random-uuid.jpg`, compressed on-device (~1600px), viewable only via 1-hour signed URLs, enforced by storage RLS.
- **Scheduling:** guest picks exact date/time; request is `PENDING`; only Chelsea confirms. The Snapchat/WhatsApp link appears only after `CONFIRMED`. Work-hours (Mon/Tue/Thu 8–6, Wed 6–12, Lagos time) show a gentle warning, never a block. Editable in Dashboard → More → Settings.
- **Analytics:** a single `admin_analytics()` SQL function; charts are lazy-loaded.

## Known limits (be aware)
- **Push notifications:** only in-browser/PWA notifications while the app is open or backgrounded. True closed-app push needs VAPID keys + a push server; email is the reliable fallback, as you specified.
- **Realtime channels** for typing/presence are public channels named with the unguessable conversation UUID. They carry no message content (messages themselves are protected by RLS).
- **Mobile Enter key:** on phones Enter makes a new line (the ➤ button sends); on desktop Enter sends, Shift+Enter adds a line.
- **Seed recipes** are generic starters. Replace them from Dashboard → More → Recipes.
- The Snapchat/WhatsApp links are in `src/lib/services.ts` (`LINKS`).

## Test checklist
1. Open the site on your phone → homepage loads, bottom nav works.
2. Home → "I need to talk" → send a request with *Right now* → you land in a chat; Chelsea gets the email.
3. Sign in at `/chelsea` on another device → Inbox → reply → message appears instantly on the guest phone; check typing, ✓✓, Read.
4. Refresh both → messages still there. Turn on airplane mode, send → "That didn't send 😭"; turn off → auto-retry.
5. Pick my outfit → add 2 photos → send → photos visible in the chat to both sides only.
6. Request a WhatsApp call for a time → Chelsea confirms in Requests → guest sees "You're all set" + Open WhatsApp.
7. Anonymous request → dashboard shows "Anonymous", email hidden.
8. Cook → "chicken, rice, tomato" → recipes appear. Dashboard → Recipes → add one.
9. Little Things → send note → appears in Dashboard → Little notes.
10. Stats page shows charts.
