/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        paper: '#FBF8F1',
        cream: '#F5EFE3',
        sand: '#E9DEC9',
        sage: { DEFAULT: '#A9BDA5', deep: '#55735A', soft: '#DCE5D8' },
        dusty: { DEFAULT: '#9DB5C8', deep: '#46657F', soft: '#DDE7EF' },
        butter: { DEFAULT: '#F2DC92', soft: '#FAF0C8' },
        brown: { DEFAULT: '#5B4636', soft: '#8A7563' },
        ink: '#2B2A27',
        brick: '#A44A42',
        night: { DEFAULT: '#222A3A', 2: '#2E384C', 3: '#3B4660' },
      },
      fontFamily: {
        display: ['"Young Serif"', 'Georgia', 'serif'],
        hand: ['Caveat', '"Segoe Print"', 'cursive'],
        body: ['ui-sans-serif', 'system-ui', '-apple-system', '"Segoe UI"', 'Roboto', 'sans-serif'],
      },
      borderRadius: { blob: '28px 32px 26px 34px' },
      boxShadow: {
        soft: '0 1px 0 rgba(91,70,54,.06), 0 8px 24px -10px rgba(91,70,54,.25)',
        pop: '0 2px 0 rgba(43,42,39,.9)',
      },
      keyframes: {
        bob: { '0%,100%': { transform: 'translateY(0)' }, '50%': { transform: 'translateY(-4px)' } },
        dot: { '0%,80%,100%': { opacity: '.25' }, '40%': { opacity: '1' } },
        twinkle: { '0%,100%': { opacity: '.3' }, '50%': { opacity: '1' } },
        rise: { from: { opacity: '0', transform: 'translateY(8px)' }, to: { opacity: '1', transform: 'none' } },
      },
      animation: {
        bob: 'bob 4s ease-in-out infinite',
        dot: 'dot 1.2s infinite',
        twinkle: 'twinkle 3s ease-in-out infinite',
        rise: 'rise .35s ease-out both',
      },
    },
  },
  plugins: [],
}
