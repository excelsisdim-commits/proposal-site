// Edge Function: sends transactional email (Resend) when the database tells it something happened.
// Deploy:  supabase functions deploy notify --no-verify-jwt
// (--no-verify-jwt because the caller is Postgres, authenticated by the x-webhook-secret header instead.)
//
// Secrets (supabase secrets set ...):
//   RESEND_API_KEY   from resend.com
//   FROM_EMAIL       e.g. "8 Minutes With Chelsea <hello@yourdomain.com>"  (verified domain in Resend)
//   ADMIN_EMAIL      excelsisdim@gmail.com
//   SITE_URL         https://your-site.com   (no trailing slash)
//   WEBHOOK_SECRET   same value you put in app_config.webhook_secret
// SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY are provided automatically by Supabase.

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const sb = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!, {
  auth: { persistSession: false },
})
const RESEND = Deno.env.get('RESEND_API_KEY') ?? ''
const FROM = Deno.env.get('FROM_EMAIL') ?? '8 Minutes With Chelsea <onboarding@resend.dev>'
const ADMIN = Deno.env.get('ADMIN_EMAIL') ?? 'excelsisdim@gmail.com'
const SITE = (Deno.env.get('SITE_URL') ?? '').replace(/\/$/, '')
const SECRET = Deno.env.get('WEBHOOK_SECRET') ?? ''
const TZ = Deno.env.get('DISPLAY_TZ') ?? 'Africa/Lagos'

const TYPE_LABEL: Record<string, string> = {
  talk: 'I need to talk', advice: 'I need advice', outfit: 'Pick my outfit', decide: 'Help me decide',
  hype: 'Hype me up', distract: 'Distract me', chat: 'Just chat', midnight: "It's one of those nights",
}
const METHOD_LABEL: Record<string, string> = { web: '💬 Website chat', snapchat: '👻 Snapchat', whatsapp: '💚 WhatsApp' }

const esc = (s: unknown) =>
  String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]!))

const when = (iso?: string | null) =>
  iso
    ? new Date(iso).toLocaleString('en-GB', { timeZone: TZ, weekday: 'short', day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit', hour12: true }) + ' (WAT)'
    : 'Whenever / right now'

function layout(title: string, bodyHtml: string, button?: { label: string; href: string }) {
  return `<!doctype html><html><body style="margin:0;background:#F5EFE3;padding:20px 12px;font-family:-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;color:#2B2A27">
  <table role="presentation" width="100%" cellspacing="0" cellpadding="0"><tr><td align="center">
  <table role="presentation" width="100%" style="max-width:480px;background:#FBF8F1;border-radius:24px;padding:28px 24px" cellspacing="0" cellpadding="0"><tr><td>
    <p style="margin:0 0 4px;font-size:13px;color:#8A7563">8 Minutes With Chelsea</p>
    <h1 style="margin:0 0 16px;font-size:24px;line-height:1.25;color:#2B2A27">${esc(title)}</h1>
    <div style="font-size:16px;line-height:1.55">${bodyHtml}</div>
    ${button ? `<p style="margin:26px 0 6px"><a href="${esc(button.href)}" style="display:block;text-align:center;background:#2B2A27;color:#FBF8F1;text-decoration:none;font-weight:600;font-size:17px;padding:16px 20px;border-radius:999px">${esc(button.label)}</a></p>` : ''}
    <p style="margin:22px 0 0;font-size:12px;color:#8A7563;line-height:1.5">Chelsea is a real person, not a therapist or emergency service. If you're in immediate danger, please contact someone who can help right away.</p>
  </td></tr></table></td></tr></table></body></html>`
}

const row = (k: string, v: string) =>
  `<tr><td style="padding:6px 12px 6px 0;color:#8A7563;font-size:14px;vertical-align:top;white-space:nowrap">${esc(k)}</td><td style="padding:6px 0;font-size:15px">${esc(v)}</td></tr>`

async function send(to: string, subject: string, html: string) {
  if (!RESEND) throw new Error('RESEND_API_KEY not set')
  const res = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: { Authorization: `Bearer ${RESEND}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ from: FROM, to: [to], subject, html }),
  })
  if (!res.ok) throw new Error(`Resend ${res.status}: ${await res.text()}`)
}

async function log(kind: string, to_role: 'admin' | 'guest', conversation_id: string | null, request_id: string | null, status: 'sent' | 'skipped' | 'failed', error?: string) {
  await sb.from('notifications').insert({ kind, to_role, conversation_id, request_id, status, error: error ?? null })
}

async function recentlySent(kind: string, conversation_id: string, minutes: number) {
  const since = new Date(Date.now() - minutes * 60_000).toISOString()
  const { count } = await sb.from('notifications').select('id', { count: 'exact', head: true })
    .eq('kind', kind).eq('conversation_id', conversation_id).eq('status', 'sent').gte('created_at', since)
  return (count ?? 0) > 0
}

async function getConv(id: string) {
  const { data: conv } = await sb.from('conversations').select('*').eq('id', id).single()
  const { data: contact } = await sb.from('contact_private').select('email, access_token').eq('conversation_id', id).single()
  return { conv, email: contact?.email as string | null, token: contact?.access_token as string | null }
}

const guestLink = (id: string, token: string | null) => `${SITE}/c/${id}${token ? `?t=${token}` : ''}`

async function attempt(kind: string, role: 'admin' | 'guest', convId: string | null, reqId: string | null, to: string, subject: string, html: string) {
  try { await send(to, subject, html); await log(kind, role, convId, reqId, 'sent') }
  catch (e) { await log(kind, role, convId, reqId, 'failed', String((e as Error).message).slice(0, 400)) }
}

async function onRequestInsert(r: any) {
  const { conv, email, token } = await getConv(r.conversation_id)
  if (!conv) return
  const anon = conv.is_anonymous
  const name = anon ? 'Anonymous' : conv.display_name
  const preview = String(r.message ?? '').slice(0, 160) + (String(r.message ?? '').length > 160 ? '…' : '')
  const table = `<table role="presentation" cellspacing="0" cellpadding="0" style="width:100%">
    ${row('Name', name)}${row('Anonymous', anon ? 'Yes' : 'No')}${row('Email', anon ? 'Hidden (anonymous)' : email ?? 'Not provided')}
    ${row('Type', TYPE_LABEL[r.type] ?? r.type)}${r.subtype ? row('About', r.subtype) : ''}
    ${row('Preferred', when(r.preferred_at))}${row('Connect via', METHOD_LABEL[r.contact_method] ?? r.contact_method)}
    ${row('Request ID', r.ref)}</table>
    ${r.in_work_hours ? '<p style="font-size:14px;color:#8A7563">⚠️ This time falls inside your work hours.</p>' : ''}
    ${preview ? `<p style="background:#F5EFE3;border-radius:16px;padding:14px 16px;margin:14px 0 0;font-size:15px">“${esc(preview)}”</p>` : ''}`
  await attempt('admin_request', 'admin', r.conversation_id, r.id, ADMIN, '💌 Someone wants to sit with you',
    layout('Someone wants to sit with you', table, { label: 'Open Conversation', href: `${SITE}/chelsea/inbox/${r.conversation_id}` }))

  if (email) {
    const body = `<p>Okayyy, your request is with me. 🫶🏽</p>
      <p>${r.preferred_at ? `You asked for <b>${esc(when(r.preferred_at))}</b>. I'll let you know if I can make it.` : "I'll see it soon and reply in your conversation."}</p>
      <p style="color:#8A7563;font-size:14px">Request ID: ${esc(r.ref)}</p>`
    await attempt('guest_request', 'guest', r.conversation_id, r.id, email, '💌 Your request is with Chelsea',
      layout('Your request is with Chelsea', body, { label: 'Open your conversation 💌', href: guestLink(r.conversation_id, token) }))
  }
}

async function onRequestStatus(r: any) {
  const { email, token } = await getConv(r.conversation_id)
  if (!email) { await log('guest_status', 'guest', r.conversation_id, r.id, 'skipped'); return }
  const map: Record<string, [string, string, string]> = {
    CONFIRMED: ['🫶 Chelsea confirmed your time', "You're all set 🫶🏽", `<p>I can make <b>${esc(when(r.preferred_at))}</b> via <b>${esc(METHOD_LABEL[r.contact_method] ?? r.contact_method)}</b>.</p><p>Open your conversation to get the link when it's time.</p>`],
    ALTERNATIVE_TIME: ['🕐 Chelsea suggested another time', 'How about a different time?', `<p>That exact time doesn't work for me, but I could do <b>${esc(when(r.suggested_at))}</b>.</p><p>Open your conversation to say yes, or just message me.</p>`],
    DECLINED: ["💛 About your request", 'Not this time', `<p>I can't make that one, and I'm sorry. You're always welcome to send another request or just message me.</p>`],
  }
  const m = map[r.status]
  if (!m) return
  await attempt('guest_status', 'guest', r.conversation_id, r.id, email, m[0], layout(m[1], m[2], { label: 'Open your conversation 💌', href: guestLink(r.conversation_id, token) }))
}

async function onMessageInsert(m: any) {
  const { conv, email, token } = await getConv(m.conversation_id)
  if (!conv) return
  // skip the opening burst: the request email already covers a brand-new conversation
  if (Date.now() - new Date(conv.created_at).getTime() < 2 * 60_000) return

  if (m.sender === 'guest') {
    if (await recentlySent('admin_message', m.conversation_id, 10)) return
    const name = conv.is_anonymous ? 'Anonymous' : conv.display_name
    await attempt('admin_message', 'admin', m.conversation_id, null, ADMIN, `💬 New message from ${name}`,
      layout(`New message from ${name}`, `<p>You have a new message waiting. For privacy, the message itself isn't shown in this email.</p>`,
        { label: 'Open Conversation', href: `${SITE}/chelsea/inbox/${m.conversation_id}` }))
  } else if (email) {
    if (await recentlySent('guest_reply', m.conversation_id, 10)) return
    await attempt('guest_reply', 'guest', m.conversation_id, null, email, '💬 Chelsea replied',
      layout('Chelsea replied', `<p>There's a new message waiting for you.</p>`, { label: 'Open your conversation 💌', href: guestLink(m.conversation_id, token) }))
  }
}

async function onLittleThing(t: any) {
  await attempt('admin_note', 'admin', null, null, ADMIN, '🫶 A little note for you',
    layout('Someone left you a little note', `<p>Prompt: <i>${esc(t.prompt)}</i></p><p>Open your dashboard to read it.</p>`, { label: 'Open Little Notes', href: `${SITE}/chelsea/notes` }))
}

Deno.serve(async (req) => {
  if (req.method !== 'POST') return new Response('method not allowed', { status: 405 })
  if (!SECRET || req.headers.get('x-webhook-secret') !== SECRET) return new Response('forbidden', { status: 403 })
  try {
    const { type, table, record } = await req.json()
    if (table === 'requests' && type === 'INSERT') await onRequestInsert(record)
    else if (table === 'requests' && type === 'UPDATE') await onRequestStatus(record)
    else if (table === 'messages' && type === 'INSERT') await onMessageInsert(record)
    else if (table === 'little_things' && type === 'INSERT') await onLittleThing(record)
    return new Response('ok')
  } catch (e) {
    console.error(e)
    return new Response('error', { status: 500 })
  }
})
