-- RUN THIS AFTER you deploy the `notify` Edge Function (see README, step 5).
-- 1) replace YOUR-PROJECT-REF  2) replace the secret with a long random string,
--    and set the SAME string as the WEBHOOK_SECRET Edge Function secret.
insert into public.app_config (key, value) values
  ('edge_url', 'https://YOUR-PROJECT-REF.supabase.co/functions/v1/notify'),
  ('webhook_secret', 'CHANGE-ME-to-a-long-random-string')
on conflict (key) do update set value = excluded.value;
