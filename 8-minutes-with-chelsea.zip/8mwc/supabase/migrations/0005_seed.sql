-- Starter content. Chelsea can edit/replace all of this from the dashboard.

insert into public.site_content (key, value) values ('about',
'Hi, I''m Chelsea.

I''m the person people come to when they need to talk, need someone to help them decide, need a little encouragement, or just want somebody around.

So I made a tiny corner of the internet for exactly that.

You don''t have to come here with a big problem.

You can come because you had a weird day.
You need an outfit opinion.
You don''t know what to cook.
You need to rant.
Or it''s midnight and you just want somebody to listen.

Whatever it is...

come talk to me.')
on conflict (key) do nothing;

insert into public.recipes (name, description, ingredients, steps, minutes, difficulty, category, tags) values
('Tomato jollof-style rice', 'Smoky, saucy rice for when you want the whole pot to disappear.',
 '[{"name":"rice","qty":"2 cups"},{"name":"tomato","qty":"4 big"},{"name":"onion","qty":"1"},{"name":"pepper","qty":"to taste"},{"name":"oil","qty":"1/3 cup","staple":true},{"name":"seasoning cube","qty":"2","staple":true}]',
 array['Blend tomato, pepper and half the onion. Boil it down until it thickens and loses the raw smell.','Fry the rest of the onion in oil, add the sauce and seasoning, and fry until the oil floats.','Add washed rice and enough hot water to just cover it. Stir once.','Cover tightly, low heat, 25 minutes. Fluff and leave to rest 5 minutes.'],
 45,'medium','Rice', array['party','one pot']),
('Egg fried rice', 'Leftover rice, eggs, and ten minutes. That is the whole plan.',
 '[{"name":"rice","qty":"2 cups cooked"},{"name":"egg","qty":"2"},{"name":"onion","qty":"1/2"},{"name":"soy sauce","qty":"1 tbsp","staple":true},{"name":"oil","qty":"2 tbsp","staple":true}]',
 array['Scramble the eggs in a hot pan and set aside.','Fry the onion, add cold rice and break up the clumps.','Add soy sauce and eggs, toss for 2 minutes.'],
 15,'easy','Rice', array['leftovers','quick']),
('One-pot chicken and rice', 'Everything cooks together and the rice drinks up the chicken flavour.',
 '[{"name":"chicken","qty":"500g"},{"name":"rice","qty":"2 cups"},{"name":"onion","qty":"1"},{"name":"tomato","qty":"2"},{"name":"seasoning cube","qty":"2","staple":true},{"name":"oil","qty":"3 tbsp","staple":true}]',
 array['Season the chicken and brown it in oil. Set aside.','Fry onion and chopped tomato until soft.','Add rice, chicken, and hot water to cover.','Cover and cook on low for 25 minutes until the rice is done.'],
 40,'easy','Chicken', array['one pot']),
('Garlic butter chicken', 'Crispy edges, buttery garlic sauce. Eat it with anything.',
 '[{"name":"chicken","qty":"4 pieces"},{"name":"garlic","qty":"5 cloves"},{"name":"butter","qty":"3 tbsp"},{"name":"salt","staple":true},{"name":"pepper","qty":"1 tsp","staple":true}]',
 array['Season chicken with salt and pepper.','Pan-fry until golden and cooked through, about 6 minutes a side.','Lower the heat, add butter and garlic, spoon it over the chicken for 1 minute.'],
 25,'easy','Chicken', array['dinner']),
('Creamy tomato pasta', 'Comfort in a bowl. Milk makes it creamy if you have no cream.',
 '[{"name":"pasta","qty":"250g"},{"name":"tomato","qty":"3"},{"name":"onion","qty":"1"},{"name":"garlic","qty":"2 cloves"},{"name":"milk","qty":"1/2 cup"},{"name":"oil","qty":"2 tbsp","staple":true},{"name":"salt","staple":true}]',
 array['Boil the pasta in salted water. Save a cup of the water.','Fry onion and garlic, add blended tomato and simmer 10 minutes.','Stir in milk, then pasta and a splash of pasta water.'],
 25,'easy','Pasta', array['comfort']),
('Midnight egg spaghetti', 'For when it is 12:47 AM and you are suddenly starving.',
 '[{"name":"pasta","qty":"1 handful"},{"name":"egg","qty":"2"},{"name":"cheese","qty":"optional"},{"name":"pepper","qty":"a lot","staple":true},{"name":"salt","staple":true}]',
 array['Boil the pasta until just done and drain, keeping a spoon of the water.','Beat eggs with cheese and pepper.','Toss the hot pasta with the eggs off the heat so it turns silky, not scrambled.'],
 12,'easy','Midnight cravings', array['quick','late night']),
('Indomie, but make it a meal', 'Instant noodles with egg, tomato and onion so you feel looked after.',
 '[{"name":"noodles","qty":"1 pack"},{"name":"egg","qty":"1"},{"name":"tomato","qty":"1"},{"name":"onion","qty":"1/2"},{"name":"oil","qty":"1 tbsp","staple":true}]',
 array['Fry onion and tomato for 2 minutes.','Add water, bring to a boil, add noodles and the seasoning.','Crack in the egg, cover for 2 minutes, and serve.'],
 10,'easy','Noodles', array['quick','lazy']),
('Peanut butter noodles', 'Salty, nutty, a bit spicy. Dangerous because it is so fast.',
 '[{"name":"noodles","qty":"1 pack"},{"name":"peanut butter","qty":"2 tbsp"},{"name":"soy sauce","qty":"1 tbsp","staple":true},{"name":"garlic","qty":"1 clove"}]',
 array['Cook the noodles and keep a splash of the water.','Whisk peanut butter, soy sauce, garlic and noodle water into a sauce.','Toss with the noodles.'],
 12,'easy','Noodles', array['quick']),
('Fluffy pancakes', 'Thick, soft, Sunday-morning pancakes.',
 '[{"name":"flour","qty":"1 1/2 cups"},{"name":"egg","qty":"1"},{"name":"milk","qty":"1 1/4 cups"},{"name":"sugar","qty":"2 tbsp"},{"name":"baking powder","qty":"3 tsp"},{"name":"butter","qty":"3 tbsp melted"}]',
 array['Whisk the dry ingredients, then mix in milk, egg and butter. Do not over-mix.','Rest the batter 5 minutes.','Cook small ladles on a medium pan until bubbles show, flip, and cook 1 more minute.'],
 25,'easy','Breakfast', array['sweet']),
('Egg sauce', 'The classic. Great with bread, boiled yam or plantain.',
 '[{"name":"egg","qty":"4"},{"name":"tomato","qty":"3"},{"name":"onion","qty":"1"},{"name":"pepper","qty":"to taste"},{"name":"oil","qty":"3 tbsp","staple":true},{"name":"seasoning cube","qty":"1","staple":true}]',
 array['Fry chopped onion in oil until soft.','Add blended tomato and pepper and cook down until thick.','Pour in beaten eggs, stir gently, and cook until set.'],
 20,'easy','Breakfast', array['classic']),
('Fried plantain and eggs', 'Sweet, salty, done in 15 minutes.',
 '[{"name":"plantain","qty":"2 ripe"},{"name":"egg","qty":"2"},{"name":"oil","qty":"for frying","staple":true},{"name":"salt","staple":true}]',
 array['Slice plantain on the diagonal and fry until golden both sides.','Fry or scramble the eggs with a pinch of salt.','Serve together.'],
 15,'easy','Snacks', array['quick']),
('Puff-puff', 'Soft, golden, slightly chewy. Make more than you think.',
 '[{"name":"flour","qty":"3 cups"},{"name":"sugar","qty":"1/2 cup"},{"name":"yeast","qty":"2 tsp"},{"name":"water","qty":"warm","staple":true},{"name":"oil","qty":"for frying","staple":true}]',
 array['Mix flour, sugar and yeast, then add warm water to make a thick, stretchy batter.','Cover and let rise for 1 hour.','Drop spoonfuls into medium-hot oil and fry until golden, turning often.'],
 90,'medium','Snacks', array['party']),
('Banana bread', 'Use the bananas that are almost too far gone.',
 '[{"name":"banana","qty":"3 ripe"},{"name":"flour","qty":"1 3/4 cups"},{"name":"egg","qty":"1"},{"name":"sugar","qty":"3/4 cup"},{"name":"butter","qty":"1/3 cup"},{"name":"baking powder","qty":"1 tsp"}]',
 array['Heat the oven to 175°C and grease a loaf tin.','Mash bananas, then mix in melted butter, sugar and egg.','Fold in flour and baking powder.','Bake 55 to 60 minutes until a skewer comes out clean.'],
 70,'medium','Baking', array['sweet']),
('Cheesy toast', 'Crunchy outside, melty inside. A hug with edges.',
 '[{"name":"bread","qty":"2 slices"},{"name":"cheese","qty":"a good handful"},{"name":"butter","qty":"1 tbsp"}]',
 array['Butter the outside of the bread.','Sandwich the cheese and toast in a pan on low heat until golden both sides.'],
 8,'easy','Lazy meals', array['quick','lazy']),
('Two-minute mug cake', 'Chocolate cake for one person and one spoon.',
 '[{"name":"flour","qty":"4 tbsp"},{"name":"sugar","qty":"3 tbsp"},{"name":"cocoa","qty":"2 tbsp"},{"name":"milk","qty":"3 tbsp"},{"name":"oil","qty":"2 tbsp","staple":true}]',
 array['Mix everything in a big mug until smooth.','Microwave 70 to 90 seconds. Let it sit a minute.'],
 5,'easy','Midnight cravings', array['sweet','late night'])
;
