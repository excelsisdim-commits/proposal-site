-- Helper + business-logic functions, triggers.

create or replace function public.can_access_conv(p_conv uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select public.is_admin() or exists (
    select 1 from public.conversations c where c.id = p_conv and c.guest_id = auth.uid()
  )
$$;

-- Is a moment inside Chelsea's normal work hours? (evaluated in Lagos time)
create or replace function public.in_work_hours(ts timestamptz) returns boolean
language sql stable set search_path = public as $$
  select exists (
    select 1 from public.work_hours w
    where w.weekday = extract(isodow from (ts at time zone 'Africa/Lagos'))::int
      and (ts at time zone 'Africa/Lagos')::time >= w.start_time
      and (ts at time zone 'Africa/Lagos')::time <  w.end_time
  )
$$;

-- ───────── messages: sender is decided by the SERVER, never by the client ─────────
create or replace function public.messages_before_insert() returns trigger
language plpgsql security definer set search_path = public as $$
declare p text;
begin
  new.sender := case when public.is_admin() then 'chelsea' else 'guest' end;
  new.created_at := now();
  new.delivered_at := null;
  new.read_at := null;
  if new.attachment_paths is not null then
    foreach p in array new.attachment_paths loop
      if p not like (new.conversation_id::text || '/%') or p like '%..%' then
        raise exception 'invalid attachment path';
      end if;
    end loop;
  end if;
  -- rate limit: 20 messages / minute / conversation / side
  if (select count(*) from public.messages m
        where m.conversation_id = new.conversation_id and m.sender = new.sender
          and m.created_at > now() - interval '1 minute') >= 20 then
    raise exception 'slow_down';
  end if;
  return new;
end $$;
create trigger messages_before_insert before insert on public.messages
  for each row execute function public.messages_before_insert();

create or replace function public.messages_after_insert() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  update public.conversations set
    last_message_at = new.created_at,
    unread_admin = unread_admin + (case when new.sender = 'guest'   then 1 else 0 end),
    unread_guest = unread_guest + (case when new.sender = 'chelsea' then 1 else 0 end)
  where id = new.conversation_id;
  insert into public.attachments (conversation_id, message_id, path)
    select new.conversation_id, new.id, unnest(new.attachment_paths);
  return new;
end $$;
create trigger messages_after_insert after insert on public.messages
  for each row execute function public.messages_after_insert();

-- ───────── delivery + read receipts (only the OTHER side's messages can be marked) ─────────
create or replace function public.mark_delivered(p_conv uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.can_access_conv(p_conv) then raise exception 'forbidden'; end if;
  update public.messages set delivered_at = now()
   where conversation_id = p_conv and delivered_at is null
     and sender = (case when public.is_admin() then 'guest' else 'chelsea' end);
end $$;

create or replace function public.mark_read(p_conv uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.can_access_conv(p_conv) then raise exception 'forbidden'; end if;
  update public.messages set read_at = now(), delivered_at = coalesce(delivered_at, now())
   where conversation_id = p_conv and read_at is null
     and sender = (case when public.is_admin() then 'guest' else 'chelsea' end);
  if public.is_admin() then
    update public.conversations set unread_admin = 0 where id = p_conv and unread_admin <> 0;
  else
    update public.conversations set unread_guest = 0 where id = p_conv and unread_guest <> 0;
  end if;
end $$;

-- ───────── create a request (+ conversation + first message) in one safe call ─────────
create or replace function public.create_request(
  p_name text, p_email text, p_anonymous boolean, p_type text, p_subtype text,
  p_method text, p_preferred timestamptz, p_message text
) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  uid uuid := auth.uid();
  v_name text;
  v_email text;
  v_conv uuid;
  v_req uuid;
  v_ref text;
begin
  if uid is null then raise exception 'not_signed_in'; end if;
  if public.is_admin() then raise exception 'admins_cannot_create_requests'; end if;
  if char_length(coalesce(p_message,'')) > 4000 then raise exception 'message_too_long'; end if;
  if char_length(coalesce(p_name,'')) > 60 then raise exception 'name_too_long'; end if;
  if char_length(coalesce(p_subtype,'')) > 80 then raise exception 'subtype_too_long'; end if;

  v_email := nullif(lower(trim(coalesce(p_email,''))), '');
  if v_email is not null and v_email !~ '^[^@\s]+@[^@\s]+\.[^@\s]+$' then raise exception 'invalid_email'; end if;

  -- rate limit: 6 new conversations per hour per person
  if (select count(*) from public.conversations where guest_id = uid and created_at > now() - interval '1 hour') >= 6 then
    raise exception 'slow_down';
  end if;

  v_name := case when p_anonymous then 'Anonymous'
                 else coalesce(nullif(trim(p_name), ''), 'Friend') end;

  insert into public.conversations (guest_id, display_name, is_anonymous, topic)
    values (uid, v_name, coalesce(p_anonymous,false), p_type)
    returning id into v_conv;

  insert into public.contact_private (conversation_id, email) values (v_conv, v_email);

  insert into public.requests (conversation_id, type, subtype, contact_method, preferred_at, message, in_work_hours)
    values (v_conv, p_type, nullif(trim(coalesce(p_subtype,'')),''), coalesce(p_method,'web'), p_preferred,
            coalesce(p_message,''), case when p_preferred is null then false else public.in_work_hours(p_preferred) end)
    returning id, ref into v_req, v_ref;

  if char_length(trim(coalesce(p_message,''))) > 0 then
    insert into public.messages (conversation_id, body) values (v_conv, p_message);
  end if;

  return jsonb_build_object('conversation_id', v_conv, 'request_id', v_req, 'ref', v_ref);
end $$;

-- Return to a conversation from an email link on any device.
create or replace function public.claim_conversation(p_id uuid, p_token text) returns boolean
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null or public.is_admin() then return false; end if;
  if exists (select 1 from public.contact_private where conversation_id = p_id and access_token = p_token) then
    update public.conversations set guest_id = auth.uid() where id = p_id;
    return true;
  end if;
  return false;
end $$;

-- Guest accepts the alternative time Chelsea suggested.
create or replace function public.accept_suggestion(p_request uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  update public.requests r set status = 'CONFIRMED', preferred_at = r.suggested_at
   where r.id = p_request and r.status = 'ALTERNATIVE_TIME' and r.suggested_at is not null
     and exists (select 1 from public.conversations c where c.id = r.conversation_id and c.guest_id = auth.uid());
end $$;

-- status bookkeeping
create or replace function public.requests_before_update() returns trigger
language plpgsql as $$
begin
  if new.status is distinct from old.status then
    if old.status = 'PENDING' and new.status <> 'PENDING' and new.responded_at is null then new.responded_at := now(); end if;
    if new.status = 'COMPLETED' then new.completed_at := now(); end if;
  end if;
  return new;
end $$;
create trigger requests_before_update before update on public.requests
  for each row execute function public.requests_before_update();

-- little things rate limit: 10 / hour / person
create or replace function public.little_things_before_insert() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if (select count(*) from public.little_things where author_id = new.author_id and created_at > now() - interval '1 hour') >= 10 then
    raise exception 'slow_down';
  end if;
  return new;
end $$;
create trigger little_things_before_insert before insert on public.little_things
  for each row execute function public.little_things_before_insert();

-- ───────── admin-only data access (email hidden when guest chose anonymous) ─────────
create or replace function public.admin_requests() returns jsonb
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'forbidden'; end if;
  return coalesce((
    select jsonb_agg(to_jsonb(q) order by q.created_at desc) from (
      select r.id, r.ref, r.conversation_id, r.type, r.subtype, r.contact_method, r.preferred_at, r.status,
             r.suggested_at, r.message, r.in_work_hours, r.created_at, r.responded_at,
             c.display_name, c.is_anonymous, c.unread_admin,
             case when c.is_anonymous then null else cp.email end as email
        from public.requests r
        join public.conversations c on c.id = r.conversation_id
        left join public.contact_private cp on cp.conversation_id = c.id
    ) q
  ), '[]'::jsonb);
end $$;

create or replace function public.admin_contact(p_conv uuid) returns text
language plpgsql stable security definer set search_path = public as $$
declare v text;
begin
  if not public.is_admin() then raise exception 'forbidden'; end if;
  select case when c.is_anonymous then null else cp.email end into v
    from public.conversations c left join public.contact_private cp on cp.conversation_id = c.id
   where c.id = p_conv;
  return v;
end $$;

create or replace function public.admin_analytics() returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare res jsonb;
begin
  if not public.is_admin() then raise exception 'forbidden'; end if;
  select jsonb_build_object(
    'total',      (select count(*) from public.requests),
    'week',       (select count(*) from public.requests where created_at >= now() - interval '7 days'),
    'month',      (select count(*) from public.requests where created_at >= now() - interval '30 days'),
    'pending',    (select count(*) from public.requests where status = 'PENDING'),
    'confirmed',  (select count(*) from public.requests where status = 'CONFIRMED'),
    'declined',   (select count(*) from public.requests where status = 'DECLINED'),
    'completed',  (select count(*) from public.requests where status = 'COMPLETED'),
    'upcoming',   (select count(*) from public.requests where status = 'CONFIRMED' and preferred_at > now()),
    'active_conversations', (select count(*) from public.conversations where status = 'open' and last_message_at > now() - interval '7 days'),
    'unread_messages',      (select coalesce(sum(unread_admin), 0) from public.conversations),
    'anonymous',  (select count(*) from public.requests r join public.conversations c on c.id = r.conversation_id where c.is_anonymous),
    'identified', (select count(*) from public.requests r join public.conversations c on c.id = r.conversation_id where not c.is_anonymous),
    'by_type',    (select coalesce(jsonb_object_agg(type, n), '{}'::jsonb) from (select type, count(*) n from public.requests group by type) t),
    'by_method',  (select coalesce(jsonb_object_agg(contact_method, n), '{}'::jsonb) from (select contact_method, count(*) n from public.requests group by contact_method) t),
    'cook_searches', (select count(*) from public.cook_searches),
    'little_things_unread', (select count(*) from public.little_things where not is_read),
    'avg_response_minutes', (select round(avg(extract(epoch from (responded_at - created_at))) / 60)::int from public.requests where responded_at is not null),
    'daily', (
      select coalesce(jsonb_agg(jsonb_build_object('day', to_char(d, 'Mon DD'), 'n', coalesce(x.n, 0)) order by d), '[]'::jsonb)
        from generate_series((current_date - 13)::timestamp, current_date::timestamp, interval '1 day') d
        left join (select created_at::date as day, count(*) n from public.requests group by 1) x on x.day = d::date
    )
  ) into res;
  return res;
end $$;

-- ───────── email notifications: DB → Edge Function (secret header) ─────────
create or replace function public.notify_edge() returns trigger
language plpgsql security definer set search_path = public, extensions as $$
declare v_url text; v_secret text;
begin
  select value into v_url    from public.app_config where key = 'edge_url';
  select value into v_secret from public.app_config where key = 'webhook_secret';
  if v_url is null or v_secret is null then return new; end if;   -- not configured yet: stay silent
  perform net.http_post(
    url := v_url,
    headers := jsonb_build_object('Content-Type', 'application/json', 'x-webhook-secret', v_secret),
    body := jsonb_build_object(
      'type', TG_OP, 'table', TG_TABLE_NAME, 'record', to_jsonb(new),
      'old_record', case when TG_OP = 'UPDATE' then to_jsonb(old) else null end)
  );
  return new;
exception when others then
  return new;   -- never block a user's request because email failed
end $$;

create trigger notify_requests_insert after insert on public.requests
  for each row execute function public.notify_edge();
create trigger notify_requests_status after update of status on public.requests
  for each row when (old.status is distinct from new.status) execute function public.notify_edge();
create trigger notify_messages_insert after insert on public.messages
  for each row execute function public.notify_edge();
create trigger notify_little_things_insert after insert on public.little_things
  for each row execute function public.notify_edge();

-- lock down who may call what
revoke execute on all functions in schema public from public, anon;
grant execute on function public.is_admin(), public.can_access_conv(uuid), public.in_work_hours(timestamptz) to anon, authenticated;
grant execute on function public.mark_delivered(uuid), public.mark_read(uuid),
  public.create_request(text,text,boolean,text,text,text,timestamptz,text),
  public.claim_conversation(uuid,text), public.accept_suggestion(uuid),
  public.admin_requests(), public.admin_contact(uuid), public.admin_analytics() to authenticated;
