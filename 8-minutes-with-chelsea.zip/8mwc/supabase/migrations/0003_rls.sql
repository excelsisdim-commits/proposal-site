-- Row Level Security: the REAL security boundary. Hiding buttons in the UI is not security.

alter table public.profiles       enable row level security;
alter table public.conversations  enable row level security;
alter table public.contact_private enable row level security;  -- no policies on purpose
alter table public.messages       enable row level security;
alter table public.requests       enable row level security;
alter table public.availability   enable row level security;
alter table public.work_hours     enable row level security;
alter table public.little_things  enable row level security;
alter table public.recipes        enable row level security;
alter table public.site_content   enable row level security;
alter table public.cook_searches  enable row level security;
alter table public.attachments    enable row level security;
alter table public.notifications  enable row level security;
alter table public.app_config     enable row level security;          -- no policies on purpose

-- profiles: read your own row. Nobody can write roles from the browser.
create policy "profiles: read own" on public.profiles for select to authenticated using (id = auth.uid());

-- conversations: guests see only their own; Chelsea sees all.
create policy "conversations: read" on public.conversations for select to authenticated
  using (guest_id = auth.uid() or public.is_admin());
create policy "conversations: admin update" on public.conversations for update to authenticated
  using (public.is_admin()) with check (public.is_admin());

-- messages: read/write only inside conversations you can access. (sender is forced by trigger)
create policy "messages: read" on public.messages for select to authenticated using (public.can_access_conv(conversation_id));
create policy "messages: insert" on public.messages for insert to authenticated with check (public.can_access_conv(conversation_id));

-- requests: read your own; only Chelsea changes status.
create policy "requests: read" on public.requests for select to authenticated using (public.can_access_conv(conversation_id));
create policy "requests: admin update" on public.requests for update to authenticated
  using (public.is_admin()) with check (public.is_admin());

-- availability + work hours: everyone reads, Chelsea writes.
create policy "availability: read" on public.availability for select to anon, authenticated using (true);
create policy "availability: admin write" on public.availability for update to authenticated
  using (public.is_admin()) with check (public.is_admin());
create policy "work_hours: read" on public.work_hours for select to anon, authenticated using (true);
create policy "work_hours: admin write" on public.work_hours for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

-- little things: anyone signed in can leave one; only Chelsea reads.
create policy "little_things: insert" on public.little_things for insert to authenticated with check (author_id = auth.uid());
create policy "little_things: admin read" on public.little_things for select to authenticated using (public.is_admin());
create policy "little_things: admin update" on public.little_things for update to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "little_things: admin delete" on public.little_things for delete to authenticated using (public.is_admin());

-- recipes + site content
create policy "recipes: read published" on public.recipes for select to anon, authenticated using (is_published or public.is_admin());
create policy "recipes: admin write" on public.recipes for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "site_content: read" on public.site_content for select to anon, authenticated using (true);
create policy "site_content: admin write" on public.site_content for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- cook searches: write-only for guests, read for Chelsea.
create policy "cook_searches: insert" on public.cook_searches for insert to authenticated with check (author_id = auth.uid());
create policy "cook_searches: admin read" on public.cook_searches for select to authenticated using (public.is_admin());

-- attachments + notifications logs
create policy "attachments: read" on public.attachments for select to authenticated using (public.can_access_conv(conversation_id));
create policy "notifications: admin read" on public.notifications for select to authenticated using (public.is_admin());

-- Realtime: stream changes (RLS still applies to what each client receives)
do $$ begin
  begin alter publication supabase_realtime add table public.messages;      exception when duplicate_object then null; end;
  begin alter publication supabase_realtime add table public.conversations; exception when duplicate_object then null; end;
  begin alter publication supabase_realtime add table public.requests;      exception when duplicate_object then null; end;
  begin alter publication supabase_realtime add table public.availability;  exception when duplicate_object then null; end;
  begin alter publication supabase_realtime add table public.little_things; exception when duplicate_object then null; end;
end $$;
