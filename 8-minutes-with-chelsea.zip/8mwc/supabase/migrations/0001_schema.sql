-- 8 Minutes With Chelsea — schema
-- Run migrations in order (0001 → 0005) in the Supabase SQL editor, or with `supabase db push`.

create extension if not exists pgcrypto;
create extension if not exists pg_net;

-- ───────── profiles (role lives here; users can NEVER edit it) ─────────
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  role text not null default 'guest' check (role in ('guest','admin')),
  created_at timestamptz not null default now()
);

create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, role) values (new.id, 'guest') on conflict do nothing;
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles where id = auth.uid() and role = 'admin')
$$;

-- ───────── conversations ─────────
create table public.conversations (
  id uuid primary key default gen_random_uuid(),
  guest_id uuid not null references auth.users(id) on delete cascade,
  display_name text not null default 'Anonymous',
  is_anonymous boolean not null default false,
  topic text not null,
  status text not null default 'open' check (status in ('open','closed')),
  last_message_at timestamptz not null default now(),
  unread_admin int not null default 0,
  unread_guest int not null default 0,
  created_at timestamptz not null default now()
);
create index conversations_guest_idx on public.conversations (guest_id);
create index conversations_last_idx on public.conversations (last_message_at desc);

-- Private contact info. RLS on, NO policies → unreadable by any browser client.
-- Only Edge Functions (service role) and SECURITY DEFINER functions can touch it.
create table public.contact_private (
  conversation_id uuid primary key references public.conversations(id) on delete cascade,
  email text,
  access_token text not null default encode(gen_random_bytes(24), 'hex'),
  created_at timestamptz not null default now()
);

-- ───────── messages ─────────
create table public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  sender text not null check (sender in ('guest','chelsea')),
  body text not null default '' check (char_length(body) <= 4000),
  attachment_paths text[] not null default '{}',
  client_id uuid,
  created_at timestamptz not null default now(),
  delivered_at timestamptz,
  read_at timestamptz,
  constraint messages_not_empty check (char_length(trim(body)) > 0 or cardinality(attachment_paths) > 0),
  constraint messages_max_attachments check (cardinality(attachment_paths) <= 8),
  unique (conversation_id, client_id)
);
create index messages_conv_created_idx on public.messages (conversation_id, created_at);
create index messages_unread_idx on public.messages (conversation_id) where read_at is null;

-- ───────── requests ─────────
create table public.requests (
  id uuid primary key default gen_random_uuid(),
  ref text not null unique default ('CH-' || upper(substr(md5(random()::text || clock_timestamp()::text), 1, 6))),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  type text not null check (type in ('talk','advice','outfit','decide','hype','distract','chat','midnight')),
  subtype text,
  contact_method text not null default 'web' check (contact_method in ('web','snapchat','whatsapp')),
  preferred_at timestamptz,                 -- null = "whenever / right now"
  status text not null default 'PENDING' check (status in ('PENDING','CONFIRMED','ALTERNATIVE_TIME','DECLINED','COMPLETED')),
  suggested_at timestamptz,
  message text not null default '',
  in_work_hours boolean not null default false,
  created_at timestamptz not null default now(),
  responded_at timestamptz,
  completed_at timestamptz
);
create index requests_status_idx on public.requests (status);
create index requests_preferred_idx on public.requests (preferred_at);
create index requests_conv_idx on public.requests (conversation_id);
create index requests_created_idx on public.requests (created_at desc);

-- ───────── availability + work hours ─────────
create table public.availability (
  id int primary key default 1 check (id = 1),
  status text not null default 'available' check (status in ('available','busy','away','offline')),
  note text,
  updated_at timestamptz not null default now()
);
insert into public.availability (id, status) values (1, 'available') on conflict do nothing;

create table public.work_hours (
  weekday int primary key check (weekday between 1 and 7),  -- 1 = Monday … 7 = Sunday
  start_time time not null,
  end_time time not null
);
insert into public.work_hours values
  (1, '08:00', '18:00'),
  (2, '08:00', '18:00'),
  (3, '06:00', '12:00'),
  (4, '08:00', '18:00')
on conflict do nothing;

-- ───────── little things ─────────
create table public.little_things (
  id uuid primary key default gen_random_uuid(),
  author_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  prompt text not null,
  body text not null check (char_length(trim(body)) between 1 and 1500),
  display_name text check (char_length(display_name) <= 60),
  is_read boolean not null default false,
  created_at timestamptz not null default now()
);
create index little_things_created_idx on public.little_things (created_at desc);

-- ───────── recipes + site content ─────────
create table public.recipes (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 1 and 120),
  description text not null default '',
  ingredients jsonb not null default '[]',   -- [{ "name": "rice", "qty": "2 cups", "staple": false }]
  steps text[] not null default '{}',
  minutes int not null default 20 check (minutes between 1 and 1440),
  difficulty text not null default 'easy' check (difficulty in ('easy','medium','a bit extra')),
  category text not null check (category in ('Rice','Chicken','Pasta','Noodles','Breakfast','Snacks','Baking','Lazy meals','Midnight cravings')),
  image_path text,
  tags text[] not null default '{}',
  is_published boolean not null default true,
  created_at timestamptz not null default now()
);
create index recipes_category_idx on public.recipes (category);
create index recipes_tags_idx on public.recipes using gin (tags);
create index recipes_ingredients_idx on public.recipes using gin (ingredients);

create table public.site_content (
  key text primary key,
  value text not null,
  updated_at timestamptz not null default now()
);

-- anonymous analytics for the cooking section (no identity stored beyond the session id)
create table public.cook_searches (
  id uuid primary key default gen_random_uuid(),
  author_id uuid default auth.uid() references auth.users(id) on delete set null,
  ingredients text[] not null default '{}',
  created_at timestamptz not null default now()
);

-- ───────── attachments + notifications logs ─────────
create table public.attachments (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  message_id uuid not null references public.messages(id) on delete cascade,
  path text not null,
  created_at timestamptz not null default now()
);
create index attachments_conv_idx on public.attachments (conversation_id);

create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  kind text not null,                 -- admin_request, guest_request, admin_message, guest_reply, guest_status, admin_note
  conversation_id uuid references public.conversations(id) on delete cascade,
  request_id uuid references public.requests(id) on delete cascade,
  to_role text not null check (to_role in ('admin','guest')),
  status text not null default 'sent' check (status in ('sent','skipped','failed')),
  error text,
  created_at timestamptz not null default now()
);
create index notifications_conv_kind_idx on public.notifications (conversation_id, kind, created_at desc);

-- edge function wiring (url + shared secret). No policies → private.
create table public.app_config (key text primary key, value text not null);
