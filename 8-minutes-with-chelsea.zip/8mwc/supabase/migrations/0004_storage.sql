-- Private bucket for chat photos (outfits etc.). Files live at  <conversation_id>/<random-uuid>.jpg
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('chat-attachments', 'chat-attachments', false, 5242880, array['image/jpeg','image/png','image/webp'])
on conflict (id) do update set public = false, file_size_limit = 5242880,
  allowed_mime_types = array['image/jpeg','image/png','image/webp'];

-- Chelsea's recipe photos: public bucket, random filenames, only Chelsea can write.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('recipe-images', 'recipe-images', true, 3145728, array['image/jpeg','image/png','image/webp'])
on conflict (id) do nothing;

create policy "chat files: read own conversation" on storage.objects for select to authenticated
  using (bucket_id = 'chat-attachments' and exists (select 1 from public.conversations c where c.id::text = (storage.foldername(name))[1] and (c.guest_id = auth.uid() or public.is_admin())));
create policy "chat files: upload to own conversation" on storage.objects for insert to authenticated
  with check (bucket_id = 'chat-attachments' and exists (select 1 from public.conversations c where c.id::text = (storage.foldername(name))[1] and (c.guest_id = auth.uid() or public.is_admin())));

create policy "recipe images: admin write" on storage.objects for insert to authenticated
  with check (bucket_id = 'recipe-images' and public.is_admin());
create policy "recipe images: admin update" on storage.objects for update to authenticated
  using (bucket_id = 'recipe-images' and public.is_admin());
create policy "recipe images: admin delete" on storage.objects for delete to authenticated
  using (bucket_id = 'recipe-images' and public.is_admin());
